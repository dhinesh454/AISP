const { getGroupsAzureId } = require('#utils/db-ad.helper');

describe('Azure AD with DB', () => {
  test('get azure role id from db', async () => {
    const role = await getGroupsAzureId('supplier');
    expect(role).toBe();
  });
});

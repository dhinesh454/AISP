const { hash, verify } = require('../../utils/password');

describe('password encryption', () => {
  test('what encrypts decrypts as well', async () => {
    const hashed = await hash('123456');
    const verified = await verify('123456', hashed);
    expect(verified).toBe(true);
  });
  test('decryption does not match random value', async () => {
    const hashed = await hash('123456');
    const verified = await verify('123457', hashed);
    expect(verified).toBe(false);
  });
});

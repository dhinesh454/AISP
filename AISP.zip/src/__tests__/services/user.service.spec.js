const { resolve } = require('path');
require('dotenv').config({ path: resolve('env', '.env') });
const {
  createUser,
  generateUserPrincipleName
} = require('../../api/components/user/user.service');

describe('create user', () => {
  test('environment to be test', () => {
    expect(process.env.NODE_ENV).toBe('test');
  });

  test('generate mailnickname and user principle name with init number', () => {
    const { userPrincipalName, mailNickName } = generateUserPrincipleName(
      'Soumyadeep Dutta',
      'VOB10001'
    );
    expect(userPrincipalName).toEqual(
      'soum_vob10001' + process.env.EMAIL_DOMAIN
    );
    expect(mailNickName).toEqual('soumyadeepdutta');
  });
});

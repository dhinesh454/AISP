exports.createNestedPermissions = (data) => {
  const result = {};
  data.forEach((item) => {
    const keys = item.rowKey.split('.');
    let currentLevel = result;
    keys.slice(0, -1).forEach((key, index) => {
      if (!currentLevel[key]) {
        currentLevel[key] = {};
      }
      currentLevel = currentLevel[key];
      // eslint-disable-next-line dot-notation
      currentLevel['description'] = item.role_module;
    });
    currentLevel[keys[keys.length - 1]] = item.role_perm_status;
    // eslint-disable-next-line dot-notation
    currentLevel['description'] = item.field_description;
  });
  return result;
};

exports.flattenNestedPermissions = (permissions) => {
  const flattened = [];

  // Recursive function to process each level
  function processNode(prefix, node) {
    Object.keys(node).forEach((key) => {
      const item = node[key];
      // Check if the item has properties like Create, Delete, etc.
      if (item.Create || item.Delete || item.Edit || item.Read) {
        ['Create', 'Delete', 'Edit', 'Read'].forEach((action) => {
          if (item[action]) {
            flattened.push({
              id: `${prefix}.${key}.${action}`,
              status: item[action]
            });
          }
        });
      }
    });
  }

  // Start processing each top-level key (e.g., Onboarding, UserManage)
  Object.keys(permissions).forEach((topLevelKey) => {
    processNode(topLevelKey, permissions[topLevelKey]);
  });

  return flattened;
};

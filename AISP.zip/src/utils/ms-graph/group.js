const client = require('./auth');

exports.createGroup = async (groupDetails) => {
  const group = await client.api('/groups').post(groupDetails);
  return group;
};

exports.getGroup = async (groupId) => {
  const group = await client.api(`/groups/${groupId}`).get();
  return group;
};

exports.listGroups = async () => {
  const groups = await client.api('/groups').get();
  return groups.value;
};

exports.checkGroupExists = async (groupName) => {
  const result = await client
    .api('/groups')
    .filter(`displayName eq '${groupName}' or mailNickname eq '${groupName}'`)
    .get();
  return result.value.length > 0;
};

exports.listMembersOfGroup = async (groupId) => {
  const members = await client.api(`/groups/${groupId}/members`).get();
  return members.value;
};

exports.addMemberToGroup = async (groupId, memberId) => {
  try {
    // check if the member already exists in the group
    const existingMembers = await client
      .api(`/groups/${groupId}/members`)
      .get();

    const memberAlreadyExists = existingMembers.value.some(
      (member) => member.id === memberId
    );

    if (!memberAlreadyExists) {
      // if member does not exist
      await client.api(`/groups/${groupId}/members/$ref`).post({
        '@odata.id': `https://graph.microsoft.com/v1.0/directoryObjects/${memberId}`
      });

      console.log(
        `Member with ID ${memberId} added to group with ID ${groupId}.`
      );
    } else {
      console.log(
        `Member with ID ${memberId} already exists in group with ID ${groupId}.`
      );
    }
  } catch (error) {
    console.error('Error adding member to group:', error);
    throw error;
  }
};

const { Client } = require('@microsoft/microsoft-graph-client');
const { ClientSecretCredential } = require('@azure/identity');

// Your tenant ID, client ID, and client secret
const tenantId = process.env.TENANT_ID;
const clientId = process.env.CLIENT_ID;
const clientSecret = process.env.CLIENT_SECRET;

const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);

// Initialize the Graph client
const client = Client.init({
  authProvider: (done) => {
    credential
      .getToken('https://graph.microsoft.com/.default')
      .then((tokenResponse) => {
        done(null, tokenResponse.token);
      })
      .catch((error) => {
        done(error, null);
      });
  }
});

module.exports = client;

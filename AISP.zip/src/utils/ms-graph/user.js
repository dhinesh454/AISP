const { ServiceError } = require('#errors');
const { generateSupplierPassword } = require('#utils/password');
const client = require('./auth');

exports.createMSUser = async (userDetails) => {
  try {
    const result = await client.api('/users').post(userDetails);
    console.log('User created successfully:', result);
    return result;
  } catch (error) {
    console.error('Failed to create user:', error);
    throw error;
  }
};

exports.checkUserExists = async (userPrincipalName) => {
  try {
    const result = await client
      .api(`/users?$filter=userPrincipalName eq '${userPrincipalName}'`)
      .get();
    if (result && result.value && result.value.length > 0) {
      console.log('User exists:', result.value[0]);
      return true; // User exists
    } else {
      console.log('User does not exist.');
      return false; // User does not exist
    }
  } catch (error) {
    console.error('Error searching for user:', error);
    throw error;
  }
};

exports.listMSUsers = async () => {
  try {
    const result = await client.api('/users').get();
    console.log('Users retrieved successfully:', result);
    return result;
  } catch (error) {
    console.error('Failed to retrieve users:', error);
    throw error; // Re-throw the error if you need further error handling up the chain
  }
};

exports.createUserOnRequest = async (
  name,
  email,
  initNumber,
  password1 = ''
) => {
  const username = name.trim().split(' ').join('').toLowerCase();
  const contactPersonName = `${username}_${initNumber.toLowerCase()}`;

  const principleName = `${username.slice(0, 4)}_${initNumber.toLowerCase()}${
    process.env.EMAIL_DOMAIN
  }`;
  const password = password1 || generateSupplierPassword();

  const msUserPayload = {
    accountEnabled: true,
    displayName: contactPersonName,
    mailNickname: contactPersonName,
    userPrincipalName: principleName,
    passwordProfile: {
      password,
      forceChangePasswordNextSignIn: true
    },
    mail: email
  };

  try {
    const customerAdmin = await exports.createUser(msUserPayload);
    if (customerAdmin.error) {
      const errorMessage =
        customerAdmin?.error?.message || 'Unable to create user in Azure AD';
      throw new ServiceError(errorMessage);
    }
    // await addUserToGroup(process.env.SUPPLIER_GROUP, customerAdmin.id);
    return { principleName, password, customerAdmin };
  } catch (error) {
    console.error(error);
    throw new ServiceError(error.message || 'Unable to create user on request');
  }
};

exports.getUserIdByUPN = async (upn) => {
  try {
    const user = await client
      .api('/users')
      .filter(`userPrincipalName eq '${upn}'`)
      .select('id')
      .get();
    if (user && user.value && user.value.length > 0) {
      return user.value[0].id; // Return the ID of the user
    } else {
      console.log('No user found with that UPN');
      return null;
    }
  } catch (error) {
    console.error('Error retrieving user by UPN:', error);
    return null;
  }
};
exports.deleteUserByUPN = async (upn) => {
  const userId = await exports.getUserIdByUPN(upn);
  if (userId) {
    try {
      await client.api(`/users/${userId}`).delete();
      console.log('User deleted successfully');
    } catch (error) {
      console.error('Failed to delete user:', error);
    }
  } else {
    console.log('User not found or error occurred');
  }
};

exports.updateMSUserDetails = async (userPrincipalName, data) => {
  const userDetails = {
    ...data,
    displayName: data.FullName,
    accountEnabled: data.Status === 'Active'
  };

  try {
    const userId = await this.getUserIdByUPN(userPrincipalName);
    // Use userPrincipalName in the API endpoint
    await client.api(`/users/${userId}`).patch(userDetails);
    console.log('User details updated successfully.');
  } catch (error) {
    console.error(`Error updating user details: ${error.message}`);
  }
};

const axios = require('axios');

/**
 * get x-csrf-token for calling save suppier to sap
 * @returns string
 */
async function getCSRFToken() {
  return new Promise((resolve, reject) => {
    const config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'http://airdithana.airditsoftware.com:8010/sap/opu/odata/sap/API_BUSINESS_PARTNER/A_BusinessPartner?$format=json',
      headers: {
        'x-csrf-token': 'fetch',
        Authorization: 'Basic YXp1cmU6YWlyZGl0QDEyMw=='
      }
    };

    axios
      .request(config)
      .then((response) => {
        return resolve({
          xCsrfToken: response.headers['x-csrf-token'],
          cookie: response.headers['set-cookie']
        });
        // console.log(response.headers);
      })
      .catch((error) => {
        console.log(error);
        reject(error);
      });
  });
}

/**
 * Save supplier data into sap
 * @param {Object} data supplier data
 * @returns
 */
async function saveSupplier(data) {
  const { xCsrfToken, cookie } = await getCSRFToken();
  return new Promise((resolve, reject) => {
    const config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'http://airdithana.airditsoftware.com:8010/sap/opu/odata/sap/API_BUSINESS_PARTNER/A_BusinessPartner',
      headers: {
        'x-csrf-token': xCsrfToken,
        'Content-Type': 'application/json',
        Cookie: JSON.stringify(cookie.map((a) => a.split(' ')[0]).join('')),
        Authorization: 'Basic YXp1cmU6YWlyZGl0QDEyMw=='
      },
      data
    };

    axios
      .request(config)
      .then((response) => {
        // console.log(JSON.stringify(response.data));
        resolve(response);
      })
      .catch((error) => {
        // console.log(error);
        reject(error);
      });
  });
}

module.exports = { saveSupplier };

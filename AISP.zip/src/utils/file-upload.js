const multer = require('multer');
const { BlobServiceClient } = require('@azure/storage-blob');
const successResponse = require('#response');
const { BadRequestError } = require('#errors');

const connectionString = process.env.AZURE_STORAGE_CONN; // replace with your storage account connection string
const containerName = process.env.AZURE_STORAGE_CONTAINER; // replace with your container name

const multerMiddleware = multer({
  dest: './uploads',
  limits: { fileSize: 100000 * 1024, files: 1 }
}).single('file');

/** @type {import("express").RequestHandler} */
const handleUpload = async (req, res) => {
  if (!req.file) throw new BadRequestError('Unable to detect file');
  const blobName =
    req.authInfo.preferred_username + '/' + req.file.originalname; // replace with your blob name
  const filePath = req.file.path; // replace with the path to the file you want to upload

  //   Create a blob service client
  const blobServiceClient =
    BlobServiceClient.fromConnectionString(connectionString);

  // Get a reference to a container
  const containerClient = blobServiceClient.getContainerClient(containerName);

  // Get a block blob client
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);

  if (await blockBlobClient.exists())
    throw new BadRequestError('Same filename already exists for this user');

  // Upload the blob
  const uploadBlobResponse = await blockBlobClient.uploadFile(filePath, {
    // onProgress: (ev) => {
    //   const uploadedBytes = ev.loadedBytes;
    //   //   console.log(`Uploaded: ${uploadedBytes} bytes of ${req.file.size} bytes`);
    //   console.log(
    //     `Uploaded ${Math.round((uploadedBytes / req.file.size) * 100)}%`
    //   );
    // }
  });
  return res.send(
    successResponse(
      { filename: blobName },
      `Upload file ${blobName} successfully of ${Math.ceil(
        req.file.size / 1024
      )}KB, Request Id: ${uploadBlobResponse.requestId}`
    )
  );
};

/** @type {import("express").RequestHandler} */
const handleDownload = async (req, res) => {
  const blobStream = await handleDownloadFunc(
    decodeURIComponent(req.query.name)
  );

  // Set the proper headers for the file
  res.setHeader(
    'Content-Disposition',
    'attachment; filename=' +
      decodeURIComponent(req.query.name.split('/').pop())
  );
  // res.setHeader('Content-Type', 'application/octet-stream');

  // Stream the blob to the client
  blobStream.pipe(res);
};

const handleDownloadFunc = async (
  blobName,
  defaultContainerName = containerName
) => {
  const blobServiceClient =
    BlobServiceClient.fromConnectionString(connectionString);
  const containerClient =
    blobServiceClient.getContainerClient(defaultContainerName);
  const blobClient = containerClient.getBlobClient(blobName);
  const downloadBlockBlobResponse = await blobClient.download();
  return downloadBlockBlobResponse.readableStreamBody;
};

module.exports = {
  multerMiddleware,
  handleUpload,
  handleDownload,
  handleDownloadFunc
};

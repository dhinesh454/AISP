const { InvalidInputError } = require('#errors');

/**
 * Validates a request with given schema before passing to requst handler
 * @param {Joi.Schema} bodySchema Joi schema object
 * @param {Joi.Schema} querySchema Joi schema object
 * @returns
 */
function requestValidator(bodySchema, querySchema, paramSchema) {
  /** @type {import("express").RequestHandler} */
  return (req, res, next) => {
    // OPTIMIZE: later
    if (bodySchema) {
      const { value, error } = bodySchema.validate(req.body, {
        abortEarly: false
      });
      if (error)
        throw new InvalidInputError(
          error.message,
          error?.details?.map((err) => {
            return {
              message: err.message,
              key: err?.context?.key || err?.context?.label
            };
          })
        );
      req.body = value;
    }
    if (querySchema) {
      const { value, error } = querySchema.validate(req.query, {
        abortEarly: false
      });
      if (error)
        throw new InvalidInputError(
          error.message,
          error?.details.map((err) => {
            return {
              message: err.message,
              key: err?.context?.key || err?.context?.label
            };
          })
        );
      req.query = value;
    }
    if (paramSchema) {
      const { value, error } = paramSchema.validate(req.params, {
        abortEarly: false
      });
      if (error)
        throw new InvalidInputError(
          error.message,
          error?.details.map((err) => {
            return {
              message: err.message,
              key: err?.context?.key || err?.context?.label
            };
          })
        );
      req.params = value;
    }
    next();
  };
}

module.exports = requestValidator;

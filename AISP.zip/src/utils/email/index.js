const mailer = require('nodemailer');
const { invitation, empanlementRequestRejected } = require('./templates');
const logger = require('#logger');
const { ServiceError } = require('#errors');
const generateQrCode = require('#utils/qrcode');
const { handleDownloadFunc } = require('#utils/file-upload');
const { pipeline } = require('stream/promises');

const sendEmail = async (options) => {
  const transporter = mailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    starttls: {
      enable: true
    },
    // secureConnection: true,
    // secure: true,
    auth: {
      user: process.env.SMTP_EMAIL,
      pass: process.env.SMTP_PASSWORD
    }
  });

  const message = {
    from: `Airdit Vendor Portal Administrator <${process.env.SMTP_EMAIL}>`,
    to: options.email,
    subject: options.subject,
    // text: options.message,
    html: options.html,
    attachments: options.attachments || []
  };
  await transporter.sendMail(message);
};

/**
 * Send invitation mail to supplier
 * @param {string} name supplier name
 * @param {string} email supplier email
 * @param {string} email_cred supplier email credential
 * @param {string} password supplier auto generated password
 * @returns Promise
 */
const inviteSupplier = async (name, email, email_cred, password) => {
  const template = invitation({ name, email_cred, password });

  // console.log(template);
  // return;
  return sendEmail({
    email,
    subject: 'Supplier Invitation - AISP Portal',
    html: template,
    attachments: [
      {
        cid: 'qrcode.png',
        filename: 'qrcode.png',
        content: await generateQrCode(process.env.ORIGIN),
        encoding: 'base64'
      }
    ]
  }).catch((err) => {
    logger.error(err);
    throw new ServiceError();
  });
};

/**
 * Send invitation mail to supplier
 * @param {string} name supplier name
 * @param {string} email supplier email
 * @returns Promise
 */
const empanlementRejected = async (name, email) => {
  const template = empanlementRequestRejected({ name });

  // console.log(template);
  // return;
  return sendEmail({
    email,
    subject: 'Empanelment Request Rejected - AISP Portal',
    html: template
  }).catch((err) => {
    logger.error(err);
    throw new ServiceError();
  });
};

async function streamToString(stream) {
  const chunks = [];
  await pipeline(stream, async function* (source) {
    for await (const chunk of source) {
      chunks.push(chunk);
    }
  });
  return Buffer.concat(chunks).toString('utf8');
}
const sendEmailUsingTemplateId = async (template, replacements) => {
  const template_path = template?.template_path;
  const templateHtmlFileStream = await handleDownloadFunc(
    template_path,
    'email-templates'
  );
  const templateString = await streamToString(templateHtmlFileStream);

  const prefixedReplacements = {};
  for (const key in replacements) {
    prefixedReplacements[`##${key}`] = replacements[key];
  }

  const regex = new RegExp(Object.keys(prefixedReplacements).join('|'), 'g');
  const htmlTemplate = templateString.replace(
    regex,
    (matched) => prefixedReplacements[matched]
  );
  await sendEmail({
    email: replacements.toEmail,
    subject: replacements.subject,
    html: htmlTemplate
  })
    .then(() => {
      // TODO: success log
      console.log('email sent');
    })
    .catch((err) => {
      // TODO: error log
      console.log(err);
    });
};

module.exports = {
  inviteSupplier,
  empanlementRejected,
  sendEmailUsingTemplateId
};

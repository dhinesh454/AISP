/* eslint-disable indent */
const invitation = ({ name, email_cred, password, expIn = 1800 }) => {
  return `<!DOCTYPE html>
    <html>
    <head>
      <title></title>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
      <style>
        body {
          font-family: "Inter", sans-serif;
          color: #141414;
          font-size: 14px;
          word-spacing: 2px;
          margin: 20px;
        }
    
        p {
          font-size: 14px;
        }
    
        .container {
          width: 600px;
          margin: 0 auto;
          border: 1px solid #ccc;
          background-color: #013F86;
        }
    
        .logoimage {
          text-align: center;
          padding: 10px;
          margin-top: 10px;
          background-color: white;
        }
    
        .header {
          background-color: #f2f2f2;
          padding: 10px;
          text-align: center;
          color: white;
          background-image: url("https://aispfiles.blob.core.windows.net/uploads/Bannerbg.png");
          background-repeat: none;
          margin-bottom: -15px;
        }
    
        .welcome {
          font-size: 36px;
          padding: 30px;
        }
    
        .content {
          background-color: white;
          padding: 20px;
          padding-left: 50px;
          padding-right: 50px;
        }
    
        .greetingname {
          font-size: large;
        }
    
        .footer {
          padding: 20px;
          padding-left: 50px;
          padding-right: 50px;
          text-align: left;
          color: white;
          word-spacing: normal;
        }
    
        .footer a {
          color: white;
          text-decoration: none;
        }
      </style>
    </head>
    
    <body>
    
    
      <div class="container">
        <div class="logoimage">
          <img src="https://aispfiles.blob.core.windows.net/uploads/AITDIT_NEW_PNG.png" alt="AirDIT Software Logo" style="max-width: 100%; height: 30px;">
        </div>
        <div class="header">
          <h1 class="welcome">Welcome Onboard!</h1>
        </div>
        <div class="content">
          <p class="greetingname"><b>Hi ${name},</b></p>
          <p><b>Exciting news! 🎉</b></p>
          <p style="font-weight: 600; margin-top: 25px;">You've been selected as a supplier for the AISP Vendor Portal. Here are your login
            credentials:</p>
          <ul style="margin-top: 20px;">
            <li><b>Email:</b> ${email_cred}</li>
            <li><b>Password:</b> ${password}</li>
          </ul>
          <p style="margin-top: 20px;">To access your account, <a href="${process.env.ORIGIN}">click here</a> or scan the accompanying QR Code.</p>
         <div style="text-align: center;">
          <img src="cid:qrcode.png" alt="QR Code" style="max-width: 100px; height: 100px;">
         </div>
          <p>📤 This is an automated notification; replies are not monitored.</p>
          <p style="margin-top: 20px; margin-bottom: 0;">Thank you,</p>
          <p style="margin: 0;">Airdit Vendor Portal</p>
        </div>
        <div class="footer">
          <a href="http://www.airditsoftware.com" style="margin-bottom: 0;">Visit our website</a>
          <p style="font-size: 10px; margin-top: 5px;">www.airditsoftware.com</p>
          <p style="margin-bottom: 0;">Need Help? </p>
          <p style="font-size: 10px; margin-top: 5px;">Reach out to us: Email ID-xyz@gmail.com, Mobile No-+919970899254</p>
        </div>
      </div>
    
    </body>
    
    </html>
    `;
};
const empanlementRequestRejected = ({ name }) => {
  return `<!DOCTYPE html>
  <html>
  
  <head>
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet">
    <style>
      body {
        font-family: "Inter", sans-serif;
        color: #141414;
        font-size: 14px;
        word-spacing: 2px;
        margin: 20px;
      }
  
      p {
        font-size: 15px;
        word-spacing: 4px;
        margin-bottom: 25px;
      }
  
      .container {
        width: 600px;
        margin: 0 auto;
        border: 1px solid #ccc;
        background-color: #F2F5F8;
      }
  
      .logoimage {
        text-align: center;
        padding: 15px;
        margin-top: 10px;
      }
  
      .content {
        background-color: white;
        padding: 20px;
        padding-left: 50px;
        padding-right: 50px;
      }
  
      .greetingname {
          font-size: 15px;
      }
  
      .footer {
        padding: 10px;
        padding-left: 50px;
        padding-right: 50px;
        text-align: left;
      }
      .footer a{
          color: #1F27FA;
      }
  
    </style>
  </head>
  
  <body>
  
  
    <div class="container">
      <div class="logoimage">
        <img src="https://aispfiles.blob.core.windows.net/uploads/AITDIT_NEW_PNG.png" alt="AirDIT Software Logo" style="max-width: 100%; height: 30px;">
      </div>
      <div class="content">
        <p class="greetingname">Dear ${name},</p>
        <p>We appreciate your interest in becoming an empaneled supplier with us and the effort you put into completing the empanelment process. 🙏</p>
        <p>After careful consideration by our vendor portal team, I regret to inform you that your empanelment request has not been approved at this time. 🚫 This decision was made based on our current requirements and procurement strategy.</p>
        <p>Please consider this as a momentary setback, and feel free to reach out for feedback or guidance on your application. Your dedication and interest in collaboration have been duly noted, and we would be open to reconsidering your application in the future as our needs evolve.</p>
        <p>For any feedback or further assistance, please feel free to contact us. 🤝</p>
        <p>🚫 This is a system-generated message; please do not reply.</p>
        <p style="margin-top: 20px; margin-bottom: 0;">Thank you,</p>
        <p style="margin: 0;">Airdit Vendor Portal Team.</p>
      </div>
      <div class="footer">
        <p style="margin-bottom: 0;"><b>Visit our website</b></p>
        <a href="http://www.airditsoftware.com" style="font-size: 10px; margin-top: 5px;">www.airditsoftware.com</a>
        <p style="margin-bottom: 0;">Need Help? </p>
        <p style="font-size: 10px; margin-top: 5px;">Reach out to us: Email ID-<a href="#">xyz@gmail.com,</a> Mobile No-+919970899254</p>
      </div>
    </div>
  
  </body>
  
  </html>
    `;
};

module.exports = { invitation, empanlementRequestRejected };

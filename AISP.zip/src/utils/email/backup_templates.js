/* eslint-disable indent */
const invitation = ({ name, email_cred, password, expIn = 1800 }) => {
  return `<!DOCTYPE html>
  <html>
    <head>
      <meta charset="UTF-8" />
      <title>Invitation Email Template</title>
      <style>
        li {
          display: flex;
          align-items: center;
          gap: 10px;
        }
      </style>
    </head>
    <body>
      <h2>You're Invited!</h2>
      <p>Dear ${name},</p>
      <p>
        We are excited to invite you to as a supplier in AISP Vendor Portal. Below
        are the login details:
      </p>
      <ul>
        <li><strong>Email:</strong> ${email_cred}</li>
        <li>
          <strong>Password:</strong> ${password}
        </li>
      </ul>
      <strong> Credentials are valid for ${
        process.env.TEMP_CRED_EXPIRE_TIME / 60
      } minutes only. </strong>
      <p>
        <a href="${process.env.ORIGIN}">Click here</a> or Scan below
        QR Code to login.
      </p>
      <img src="cid:qrcode.png" alt="QR Code" />
      <p style="color: red">
        This is a system generated message please do not replay.
      </p>
      <p>Thank you</p>
      <p>Airdit Vendor Portal</p>
    </body>
  </html>
  `;
};

module.exports = { invitation };

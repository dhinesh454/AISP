const { QueueServiceClient } = require('@azure/storage-queue');

// Connection string from your Azure Storage Account
const connectionString = process.env.AZURE_QUEUE_ENDPOINT;

async function sendMessageToQueue(message) {
  const queueServiceClient =
    QueueServiceClient.fromConnectionString(connectionString);
  const queueClient = queueServiceClient.getQueueClient(
    process.env.AZURE_QUEUE_NAME
  );

  // Create the queue if it doesn't already exist
  await queueClient.createIfNotExists();

  // Send a message to the queue
  const sendReceipt = await queueClient.sendMessage(
    Buffer.from(message).toString('base64')
  );
  console.log(`Sent message: ${message}`);
  console.log(`Message ID: ${sendReceipt.messageId}`);
  console.log(`Insertion Time: ${sendReceipt.insertedOn}`);
}
module.exports = sendMessageToQueue;

// this is for utility function to bridge DB and Azure AD
const collections = require('#collections');

exports.getGroupsAzureId = async (group) => {
  const groups = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `RowKey eq '${group}'`
    }
  });
  for await (const g of groups) {
    if (g) return g.partitionKey;
  }
};

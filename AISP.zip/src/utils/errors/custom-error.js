class CustomError extends Error {
  statusCode = 500;
  constructor(
    message = 'Something went wrong',
    error_code = 'UNKNOWN_ERROR',
    type = 'System',
    statusCode = 500,
    details = null
  ) {
    super(message);
    this.error_code = error_code;
    this.type = type;
    this.name = 'CustomError';
    this.statusCode = statusCode;
    this.details = details;
  }
}

class BadRequestError extends CustomError {
  constructor(message = 'Bad Request', error_code = 'BAD_REQUEST') {
    super(message, error_code, 'User', 400);
  }
}

class InvalidInputError extends CustomError {
  constructor(
    message = 'Request body contains invalid value',
    details = null,
    error_code = 'INVALID_INPUT'
  ) {
    super(message, error_code, 'User', 400, details);
  }
}

class NotFoundError extends CustomError {
  constructor(
    message = 'Resource you are looking for is not available',
    error_code = 'NOT_FOUND'
  ) {
    super(message, error_code, 'User', 404);
  }
}

class UnauthorizedError extends CustomError {
  constructor(
    message = 'You are unauthorized to access this resource',
    error_code = 'UNAUTHORIZED'
  ) {
    super(message, error_code, 'User', 401);
  }
}

class ForbiddenError extends CustomError {
  constructor(
    message = 'You are forbidden to access this resource',
    error_code = 'FORBIDDEN'
  ) {
    super(message, error_code, 'User', 403);
  }
}

class ServiceError extends CustomError {
  constructor(
    message = 'Service is not working currently. Try after some time.',
    error_code = 'SERVICE_ERROR'
  ) {
    super(message, error_code, 'System', 500);
    // appInsightClient.trackException({ exception: new Error(message) });
  }
}

class ConflictError extends CustomError {
  constructor(
    message = 'The request could not be completed due to a conflict',
    error_code = 'CONFLICT'
  ) {
    super(message, error_code, 'User', 409);
  }
}

module.exports = {
  CustomError,
  BadRequestError,
  NotFoundError,
  UnauthorizedError,
  ForbiddenError,
  ServiceError,
  ConflictError,
  InvalidInputError
};

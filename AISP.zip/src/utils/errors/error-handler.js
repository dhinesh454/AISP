// const { CustomError } = require('#errors');
// const logger = require('#logger');

/**
 * Custom error handler middleware
 * @param {CustomError} err
 * @param {Express.Request} req
 * @param {Express.Response} res
 * @param {Express.Response} next
 * @returns
 */
const errorHandling = (err, req, res, next) => {
  // console.log(err);
  // if (!(err instanceof CustomError)) {
  //   logger.log('error', err.message);
  // }
  return res.status(err.statusCode || 500).json({
    message:
      process.env.NODE_ENV === 'production' && err.statusCode > 499
        ? 'Something went wrong in server'
        : err.message,
    success: false
  });
};

module.exports = errorHandling;

const { TableClient, AzureNamedKeyCredential } = require('@azure/data-tables');

const endpoint = process.env.AZURE_STORAGE_ENDPOINT;
const credential = new AzureNamedKeyCredential(
  process.env.AZURE_STORAGE_DB,
  process.env.AZURE_STORAGE_KEY
);

exports.UT_FIELD_OPTIONS = new TableClient(
  endpoint,
  'utFieldOptions',
  credential
);
exports.TC_GEN_NUMBER = new TableClient(endpoint, 'tcGenNumber', credential);
exports.TT_VOB_REQUEST = new TableClient(endpoint, 'ttVOBRequest', credential);
exports.TT_EMPANELMENT_FORM = new TableClient(
  endpoint,
  'ttEmpanelmentForm',
  credential
);
exports.TT_USER_DETAILS = new TableClient(
  endpoint,
  'ttUserDetails',
  credential
);
exports.TT_ROLES = new TableClient(endpoint, 'ttRole', credential);
exports.TT_GROUP_ROLES = new TableClient(endpoint, 'ttGroupRole', credential);
exports.TT_ROLE_ASSIGNMENTS = new TableClient(
  endpoint,
  'ttRoleAssignment',
  credential
);
exports.TT_ROLE_PERMISSIONS = new TableClient(
  endpoint,
  'ttRolePermissions',
  credential
);
exports.TT_EMPANELMENT_APPROVAL = new TableClient(
  endpoint,
  'ttEmpanelmentApproval',
  credential
);
exports.TT_EMPANELMENT_COMMENTS = new TableClient(
  endpoint,
  'ttEmpanelmentComments',
  credential
);
exports.TT_EMAIL_TEMPLATE = new TableClient(
  endpoint,
  'ttEmailTemplate',
  credential
);
exports.TT_EMAIL_LOG = new TableClient(endpoint, 'ttEmailLogs', credential);

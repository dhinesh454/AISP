module.exports = {
  EMPANELMENT_REQUEST_INITIAL: 'Created',
  EMPANELMENT_REQUEST_SUBMITTED: 'UnderReview',
  EMPANELMENT_REQUEST_AUDIT: 'VendorAcknowledged',
  // Concat approval level with this status codes
  EMPANELMENT_REQUEST_APPROVED: 'Approved',
  EMPANELMENT_REQUEST_REJECTED: 'Rejected',
  EMPANELMENT_REQUEST_RETURNED: 'Returned',
  EMPANELMENT_REQUEST_RESUBMITTED: 'ReSubmitted',
  EMPANELMENT_REQUEST_REVIEWED: 'Reviewed', // all approval level completed
  EMPANELMENT_REQUEST_COMPLETED: 'Completed', // SAP vendor created
  SELF_REQUEST_APPROVED: 'BuyerAcknowledged',
  SELF_REQUEST_REJECTED: 'Rejected',
  SELF_REQUEST_INITIAL: 'Created'
};

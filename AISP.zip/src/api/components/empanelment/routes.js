const router = require('express').Router();

const checkAuth = require('#middlewares/check-auth');
const {
  updateEmpanelmentRequestById,
  submitEmpanelmentRequest,
  getMyEmpanelmentRequest
} = require('./controller');

// empanelment form
router.put(
  '/update',
  checkAuth(['Onboarding.EmpanelmentForm.Edit']),
  updateEmpanelmentRequestById
);
router.patch(
  '/submit',
  checkAuth(['Onboarding.EmpanelmentForm.Edit']),
  submitEmpanelmentRequest
);
router.get(
  '/myrequest',
  checkAuth(['Onboarding.EmpanelmentForm.Read']),
  getMyEmpanelmentRequest
);

module.exports = router;

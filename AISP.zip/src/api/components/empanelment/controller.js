const collections = require('#collections');
const {
  EMPANELMENT_REQUEST_INITIAL,
  EMPANELMENT_REQUEST_SUBMITTED,
  EMPANELMENT_REQUEST_AUDIT
} = require('#enums/empanelment-status');
const { BadRequestError } = require('#errors');
const successResponse = require('#response');
const sendMessageToQueue = require('#utils/azure-storage-queqe');
const { generateUUID } = require('#utils/password');
const { myLatestEmpResponse } = require('./services');

/** @type {import("express").RequestHandler} */
exports.updateEmpanelmentRequestById = async (req, res) => {
  const latestEntity = await myLatestEmpResponse(
    req.authInfo.preferred_username
  );
  if (!latestEntity)
    throw new BadRequestError('No Empanelment Response found for this user');

  if (latestEntity.Status === EMPANELMENT_REQUEST_SUBMITTED)
    throw new BadRequestError('Request already submitted');
  // mark as expired
  await collections.TT_EMPANELMENT_FORM.updateEntity({
    ...latestEntity,
    Status: EMPANELMENT_REQUEST_AUDIT
  });
  delete latestEntity.etag;
  delete latestEntity.rowKey;
  delete latestEntity.Status;
  await collections.TT_EMPANELMENT_FORM.createEntity({
    partitionKey: latestEntity.partitionKey,
    rowKey: generateUUID(),
    Status: EMPANELMENT_REQUEST_INITIAL,
    ...latestEntity,
    ...req.body
  });
  return res.send(successResponse('Request Updated'));
};

/** @type {import("express").RequestHandler} */
exports.submitEmpanelmentRequest = async (req, res) => {
  const request = await myLatestEmpResponse(req.authInfo.preferred_username);
  if (!request) throw new BadRequestError('Invalid Request');
  // add validation
  if (request.Status === EMPANELMENT_REQUEST_SUBMITTED)
    throw new BadRequestError('Request already submitted');
  // start workflow
  await sendMessageToQueue(
    JSON.stringify({
      request_id: request.rowKey
    })
  );
  // mark as submitted
  await collections.TT_EMPANELMENT_FORM.updateEntity({
    ...request,
    Status: EMPANELMENT_REQUEST_SUBMITTED
  });
  res.send(successResponse('Request submitted'));
};

/** @type {import("express").RequestHandler} */
exports.getMyEmpanelmentRequest = async (req, res) => {
  const data = await myLatestEmpResponse(req.authInfo.preferred_username);
  if (!data)
    throw new BadRequestError('No Empanelment Response found for this user');
  return res.send(successResponse(data));
};

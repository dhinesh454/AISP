const collections = require('#collections');

exports.myLatestEmpResponse = async (SupplierAzureId) => {
  const entities = collections.TT_EMPANELMENT_FORM.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${SupplierAzureId}'`
    }
  });

  let latestEntity = null;
  for await (const entity of entities) {
    if (!latestEntity || entity.timestamp > latestEntity.timestamp) {
      latestEntity = entity;
    }
  }
  return latestEntity;
};

exports.getEmpResponseByRowKey = async (rowkey) => {
  const entities = collections.TT_EMPANELMENT_FORM.listEntities({
    queryOptions: {
      filter: `RowKey eq '${rowkey}'`
    }
  });

  const latestEntity = [];
  for await (const entity of entities) {
    latestEntity.push(entity);
  }
  const commentsRaw = collections.TT_EMPANELMENT_COMMENTS.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${rowkey}'`
    }
  });
  latestEntity[0] ? (latestEntity[0].comments = []) : null;
  for await (const comment of commentsRaw) {
    latestEntity[0]?.comments?.push(comment);
  }
  return latestEntity[0];
};

exports.latestEmpResponseByRequestId = async (requestId) => {
  const entities = collections.TT_EMPANELMENT_FORM.listEntities({
    queryOptions: {
      filter: `BasicInformation_RequestId eq '${requestId}'`
    }
  });

  let latestEntity = null;
  for await (const entity of entities) {
    if (!latestEntity || entity.timestamp > latestEntity.timestamp) {
      latestEntity = entity;
    }
  }
  return latestEntity;
};

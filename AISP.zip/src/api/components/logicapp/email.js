const successResponse = require('#response');
const collections = require('#collections');
const { sendEmailUsingTemplateId } = require('#utils/email/index');
const { BadRequestError } = require('#errors');
const { generateUUID } = require('#utils/password');

/** @type {import("express").RequestHandler} */
exports.sendEmail = async (req, res) => {
  const template = await collections.TT_EMAIL_TEMPLATE.getEntity(
    'template',
    req.body.templateId || 'invitation001'
  );
  if (!template) throw new BadRequestError('Invalid template id');

  if (!template.validation.split(', ').every((key) => key in req.body)) {
    await collections.TT_EMAIL_LOG.createEntity({
      partitionKey: req.body.toEmail,
      rowKey: generateUUID(),
      status: 'failed',
      toEmail: req.body.toEmail,
      templateId: req.body.templateId,
      data: JSON.stringify(req.body),
      error: JSON.stringify('Not all required params passed')
    });
    throw new BadRequestError('Not all required params passed');
  }
  // TODO: email placeholder replacement validation
  await sendEmailUsingTemplateId(template, {
    ...req.body,
    domain: process.env.ORIGIN
  })
    .then(async () => {
      await collections.TT_EMAIL_LOG.createEntity({
        partitionKey: req.body.toEmail,
        rowKey: generateUUID(),
        status: 'success',
        toEmail: req.body.toEmail,
        templateId: req.body.templateId,
        data: JSON.stringify(req.body)
      });
    })
    .catch(async (err) => {
      await collections.TT_EMAIL_LOG.createEntity({
        partitionKey: req.body.toEmail,
        rowKey: generateUUID(),
        status: 'failed',
        toEmail: req.body.toEmail,
        templateId: req.body.templateId,
        data: JSON.stringify(req.body),
        error: JSON.stringify(err)
      });
    });
  return res.send(successResponse('Email sent'));
};

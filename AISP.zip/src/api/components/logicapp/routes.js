const requestValidator = require('#utils/request-validator');
const { sendEmailV } = require('#validators/logicapp/email');
const { sendEmail } = require('./email');

const router = require('express').Router();

router.post('/sendemail', requestValidator(sendEmailV), sendEmail);

module.exports = router;

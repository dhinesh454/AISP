// const models = require('#models');
const successResponse = require('#response');
const collections = require('#collections');

/** @type {import("express").RequestHandler} */
exports.getDropDowns = async (req, res) => {
  const filters = [];
  if (req.query.type) {
    filters.push(`PartitionKey eq '${req.query.type}'`);
  }
  if (req.query.rowKey) {
    filters.push(`RowKey eq '${req.query.rowKey}'`);
  }

  const dropDownData = collections.UT_FIELD_OPTIONS.listEntities({
    queryOptions: {
      // select: ['id', 'FIELD_DESCRIPTION'],
      filter: filters.join(' and ')
    }
  });
  const filterEntitiesArray = [];
  for await (const entity of dropDownData) {
    filterEntitiesArray.push(entity);
  }
  return res.send(successResponse(filterEntitiesArray, ''));
};

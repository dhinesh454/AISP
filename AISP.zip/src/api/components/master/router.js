const requestValidator = require('#utils/request-validator');
const { createVobRequestV } = require('#validators/client/empanelment');
const { createSelfRequest } = require('../client/controllers/self-req');
const { getDropDowns } = require('./master-data');

const masterRouter = require('express').Router();

masterRouter.get('/data/drop-downs', getDropDowns);
masterRouter.post(
  '/createselfrequest',
  requestValidator(createVobRequestV),
  createSelfRequest
);

module.exports = masterRouter;

const collections = require('#collections');
const successResponse = require('#response');
const { createNestedPermissions } = require('#utils/serializers');

/** @type {import("express").RequestHandler} */
exports.listPermissions = async (req, res) => {
  const data = collections.TT_ROLE_PERMISSIONS.listEntities({
    queryOptions: {
      // eslint-disable-next-line quotes
      filter: "PartitionKey eq 'master'",
      select: [
        'RowKey',
        'action_desc',
        'role_perm_status',
        'nav_desc',
        'field_description',
        'role_module'
      ]
    }
  });
  const finalData = [];
  for await (const item of data) {
    finalData.push(item);
  }
  // const response = createNestedPermissions(finalData);
  return res.send(successResponse(createNestedPermissions(finalData)));
};

const collections = require('#collections');
const { addMemberToGroup } = require('#utils/ms-graph/group');
const { checkUserExists, createMSUser } = require('#utils/ms-graph/user');
const { generateSupplierPassword, generateUUID } = require('#utils/password');

exports.getUserAccess = async (user) => {
  const roleAssignments = collections.TT_ROLE_ASSIGNMENTS.listEntities({
    queryOptions: {
      filter: `RowKey eq '${user}' and status eq 'Active'`,
      select: ['PartitionKey', 'RowKey']
    }
  });
  const roleAssignmentsArr = [];
  for await (const ra of roleAssignments) {
    const ttRolePermissions = collections.TT_ROLE_PERMISSIONS.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${ra.partitionKey}'`,
        select: ['RowKey', 'action_desc', 'nav_code']
      }
    });
    ra.permissions = [];
    for await (const rp of ttRolePermissions) {
      ra.permissions.push(rp);
    }
    roleAssignmentsArr.push(ra);
  }
  return roleAssignmentsArr;
};

exports.getUserByPrincipleName = async (userPrincipleName, active = null) => {
  const userDetails = [];
  const filter = [`PartitionKey eq '${userPrincipleName}'`];
  if (active) {
    filter.push("Status eq 'Active'");
  }
  const data = collections.TT_USER_DETAILS.listEntities({
    queryOptions: {
      filter: filter.join(` and `)
    }
  });
  for await (const user of data) {
    userDetails.push(user);
  }
  return userDetails;
};

/**
 * Generates user principle name based in init number
 * @param {string} fullname user's fullname
 * @param {*} [initNumber] init number
 */
exports.generateUserPrincipleName = (fullname, initNumber) => {
  const mailNickName = fullname.trim().split(' ').join('').toLowerCase();
  let userPrincipalName = mailNickName + process.env.EMAIL_DOMAIN;
  if (initNumber) {
    userPrincipalName =
      `${mailNickName.slice(0, 4)}_${initNumber.toLowerCase()}` +
      process.env.EMAIL_DOMAIN;
  }
  return { mailNickName, userPrincipalName };
};

/**
 * Creates user in db and azure ad
 * @param {Object} user - The object to create user
 * @param {string} user.mailNickName - user mailNickname for azure ad
 * @param {string} user.pricipleName - user priciplename for azure ad
 * @param {string} user.email - user's own email
 * @param {string} user.fullname - user's fullname
 * @param {string} user.company - user's company
 * @param {string} user.mobileNumber - user's mobileNumber
 * @param {string} user.countryCode - user's countryCode
 * @param {string} user.plan - user's plan enterprise, stnadard
 * @param {string} user.userType - user's userType
 * @param {string} createdBy - user createdBy req.authInfo.preferred_username
 */
exports.createUser = async (user, createdBy) => {
  // check if active user exits in ad
  const exist = await checkUserExists(user.pricipleName);
  if (exist) throw new Error('User already exists with same principle name');

  // generate password
  const password = generateSupplierPassword();
  // create user in azure ad
  const msUserPayload = {
    accountEnabled: true,
    displayName: user.fullname,
    mailNickname: user.mailNickName,
    userPrincipalName: user.pricipleName,
    passwordProfile: {
      password,
      forceChangePasswordNextSignIn: true
    },
    mail: user.email
  };
  const azureUser = await createMSUser(msUserPayload).catch((err) => {
    throw err;
  });
  // add user in default group
  await addMemberToGroup(process.env.ORG_AD_CODE, azureUser.id).catch((err) => {
    throw err || 'Unable to add user to default group';
  });
  // create user in db
  await collections.TT_USER_DETAILS.createEntity({
    partitionKey: user.pricipleName,
    rowKey: generateUUID(),
    AzureId: azureUser.id,
    Email: user.email,
    FullName: user.fullname,
    Company: user.company,
    Country: user.countryCode,
    ContactNumber: user.mobileNumber,
    Status: 'Active',
    Plan: user.plan || 'standard',
    UserType: user.userType || 'supplier',
    CreatedBy: createdBy
  });
  // return user details
  return { azureUser, password };
};
exports.updateUser = async (user) => {
  // check if active user exits in db with same email
  // update user in db
  // update user fullname, email, ph number in ad
  // return user details
};
exports.deleteUser = async (user) => {
  // check if active user exits in db with same email
  // set user as inactive user in db
  // delete user in ad
  // return success
};

/**
 * Get list of user permissions
 * @param {object} user req.authInfo
 * @returns list of permission as an array of object
 */
exports.getUserPermissions = async (user) => {
  const data = [];
  const groups = collections.TT_ROLE_ASSIGNMENTS.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${user?.preferred_username}' and Status eq 'Active'`
    }
  });
  for await (const group of groups) {
    const groupPermissions = collections.TT_ROLE_PERMISSIONS.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${group.rowKey}' and role_perm_status eq 'Active'`,
        select: ['RowKey']
      }
    });
    const groupPermissionData = [];
    for await (const gp of groupPermissions) {
      groupPermissionData.push(gp?.rowKey);
    }
    data.push(...groupPermissionData);
  }
  return data;
};

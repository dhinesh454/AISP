const checkAuth = require('#middlewares/check-auth');
const isAuthenticated = require('#middlewares/is-auth');
const successResponse = require('#response');
const requestValidator = require('#utils/request-validator');
const {
  createAssignmentB,
  updateOneAssignmentB,
  updateOneAssignmentP
} = require('#validators/assignment');
const { createGroupValidator } = require('#validators/group');
const { createUserValidator } = require('#validators/user');
const {
  createAssignments,
  listAssignments,
  // getAssignments,
  // updateAssignments,
  deleteAssignment,
  updateAssignments,
  getAssignments
} = require('./assignment.controller');
const {
  listGroups,
  createGroup,
  getGroup,
  updateGroup
} = require('./group.controller');
const { listPermissions } = require('./permission.controller');
const {
  createRole,
  listRoles,
  getRole,
  updateRole,
  deleteRole
} = require('./role.controller');
const {
  listUsers,
  getUser,
  updateUser,
  createUserController,
  getUserAccess
} = require('./user.controller');
const router = require('express').Router();

router.get(
  '/profile',
  isAuthenticated, // check if user is authenticated
  async (req, res) => {
    return res.send(
      successResponse(
        {
          account: req.authInfo
        },
        'Logged in'
      )
    );
  }
);

router.get(
  '/access',
  isAuthenticated, // check if user is authenticated
  getUserAccess
);

// users
router.get('/getusers', checkAuth(['UserManage.User.Read']), listUsers);
router.get('/getusers/:id', checkAuth(['UserManage.User.Read']), getUser);
router.put('/updateuser/:id', checkAuth(['UserManage.User.Edit']), updateUser);
router.post(
  '/createuser',
  checkAuth(['UserManage.User.Create']),
  requestValidator(createUserValidator),
  createUserController
);

// groups
router.get('/getgroups', checkAuth(['UserManage.RoleGroup.Read']), listGroups);
router.post(
  '/creategroup',
  checkAuth(['UserManage.RoleGroup.Create']),
  requestValidator(createGroupValidator),
  createGroup
);
router.get('/getgroup/:id', checkAuth(['UserManage.RoleGroup.Read']), getGroup);
router.patch(
  '/updategroup/:id',
  checkAuth(['UserManage.RoleGroup.Edit']),
  updateGroup
);

// role
router.post(
  '/createrole',
  checkAuth(['UserManage.RolePerm.Create']),
  createRole
);
router.get('/getroles', checkAuth(['UserManage.RolePerm.Read']), listRoles);
router.get('/getrole/:id', checkAuth(['UserManage.RolePerm.Read']), getRole);
router.patch(
  '/updaterole/:id',
  checkAuth(['UserManage.RolePerm.Edit']),
  updateRole
);
router.delete(
  '/deleterole/:id',
  checkAuth(['UserManage.RolePerm.Delete']),
  deleteRole
);

// permissions
router.get('/getpermissions', checkAuth(), listPermissions);

// assignments
router.post(
  '/createassignments',
  checkAuth(
    ['UserManage.RoleAssignment.Create'],
    ['UserManage.RoleAssignment.Edit']
  ),
  requestValidator(createAssignmentB),
  createAssignments
);
router.get(
  '/getassignments',
  checkAuth(['UserManage.RoleAssignment.Read']),
  listAssignments
);
router.get(
  '/getassignments/:userPrincipleName/:roleId',
  checkAuth(['UserManage.RoleAssignment.Read']),
  requestValidator(null, null, updateOneAssignmentP),
  getAssignments
);
router.patch(
  '/updateassignments/:userPrincipleName/:roleId',
  checkAuth(
    ['UserManage.RoleAssignment.Create'],
    ['UserManage.RoleAssignment.Edit']
  ),
  requestValidator(updateOneAssignmentB, null, updateOneAssignmentP),
  updateAssignments
);
router.post(
  '/deleteassignments',
  checkAuth(['UserManage.RoleAssignment.Delete']),
  deleteAssignment
);

module.exports = router;

const { BadRequestError } = require('#errors');
const successResponse = require('#response');
const collections = require('#collections');
const { generateUUID } = require('#utils/password');
const {
  createUser,
  generateUserPrincipleName,
  getUserByPrincipleName
} = require('./user.service');
const { getGroupsAzureId } = require('#utils/db-ad.helper');
const { addMemberToGroup } = require('#utils/ms-graph/group');
const { updateMSUserDetails } = require('#utils/ms-graph/user');
const { numberGeneration } = require('../client/services/vob-request');
const { sendEmailUsingTemplateId } = require('#utils/email/index');

function transformData(data) {
  const userAccess = {
    navigations: [],
    actions: []
  };

  if (!data || !Array.isArray(data)) {
    return userAccess;
  }

  const navigationMap = new Map();

  data.forEach((entries) => {
    if (Array.isArray(entries)) {
      entries.forEach((entry) => {
        const navCodeParts = entry.nav_code.split('.');
        const mainNavCode = navCodeParts[0];

        if (!navigationMap.has(mainNavCode)) {
          navigationMap.set(mainNavCode, {
            code: mainNavCode,
            description: entry.role_module,
            values: []
          });
        }

        if (navCodeParts.length > 1) {
          const subNav = {
            code: navCodeParts[1],
            description: entry.nav_desc
          };

          // Avoid duplicate sub-navigation entries under the same main navigation
          const existingSubNavs = navigationMap.get(mainNavCode).values;
          if (!existingSubNavs.some((sub) => sub.code === subNav.code)) {
            existingSubNavs.push(subNav);
          }
        }

        userAccess.actions.push({
          code: entry.rowKey,
          description: entry.action_desc
        });
      });
    }
  });

  // convert the map to an array
  userAccess.navigations = Array.from(navigationMap.values());

  return userAccess;
}

/** @type {import("express").RequestHandler} */
exports.getUserAccess = async (req, res) => {
  const data = [];
  const groups = collections.TT_ROLE_ASSIGNMENTS.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.authInfo?.preferred_username}' and Status eq 'Active'`
    }
  });
  for await (const group of groups) {
    const groupPermissions = collections.TT_ROLE_PERMISSIONS.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${group.rowKey}' and role_perm_status eq 'Active'`
      }
    });
    const groupPermissionData = [];
    for await (const gp of groupPermissions) {
      groupPermissionData.push(gp);
    }
    data.push(groupPermissionData);
  }
  return res.send(
    successResponse({
      userAccess: {
        code: 'user_access',
        description: 'User Access Permissions',
        userPrincipalName: req.authInfo?.preferred_username,
        ...transformData(data)
      }
    })
  );
};

exports.listUsers = async (req, res) => {
  let continuationToken = req.query.nextToken || null;
  const combinedResults = [];

  const filters = [];

  if (req.query.status) {
    filters.push(`Status eq '${req.query.status}'`);
  } else {
    // eslint-disable-next-line quotes
    filters.push("Status ne 'Expired'");
  }

  if (req.query?.userType) {
    switch (req.query?.userType) {
      case 'supplier':
        filters.push("UserType eq 'supplier'");
        break;

      case 'buyer':
        filters.push("UserType ne 'supplier'");
        break;

      default:
        filters.push(`UserType eq '${req.query.userType}'`);
        break;
    }
  }

  if (req.query.searchGlobal) {
    const searchFilters = [
      `FullName eq '${req.query.searchGlobal}'`,
      `Email eq '${req.query.searchGlobal}'`,
      `ContactNumber eq '${req.query.searchGlobal}'`
    ];

    // Join the search filters with 'or' to allow any match
    filters.push(`(${searchFilters.join(' or ')})`);
  }

  // Setting up the options for pagination
  const options = {
    queryOptions: {
      filter: filters.join(' and ')
    },
    orderBy: {
      timestamp: 'desc' // Order by timestamp in descending order
    }
  };
  // console.log(filters);
  // Fetching the data with pagination control
  const pagedIterator = collections.TT_USER_DETAILS.listEntities(
    options
  ).byPage({
    maxPageSize: req.query.pageSize ? parseInt(req.query.pageSize) : 10,
    continuationToken
  });

  // Retrieve the first page
  const page = await pagedIterator.next();

  // Checking if the page has results and handling them
  if (!page.done) {
    combinedResults.push(...page.value);
    // Continuation token for the next page
    continuationToken = page.value.continuationToken;
  }
  return res.send({
    data: combinedResults,
    nextToken: continuationToken,
    success: true
  });
};

/** @type {import("express").RequestHandler} */
exports.getUser = async (req, res) => {
  // const data = await collections.TT_USER_DETAILS.getEntity(req.query.id)
  const data = await getUserByPrincipleName(req.params.id);
  if (data.length < 1) throw new BadRequestError('Invalid UserId');
  return res.send(successResponse(data[0]));
};

/** @type {import("express").RequestHandler} */
exports.createUserController = async (req, res) => {
  // generate unique number
  const initNumber = await numberGeneration({
    APP_NAME: 'INT_USER',
    PartitionKey: 'type_InternalUser'
  });
  const { userPrincipalName, mailNickName } = generateUserPrincipleName(
    req.body.FullName,
    initNumber
  );
  const { azureUser, password } = await createUser(
    {
      pricipleName: userPrincipalName,
      mailNickName,
      fullname: req.body.FullName,
      email: req.body.Email,
      company: req.body.Company,
      countryCode: req.body.Country,
      mobileNumber: req.body.ContactNumber,
      plan: req.body.Plan,
      userType: req.body.UserType
    },
    req.authInfo.preferred_username
  ).catch((err) => {
    throw new BadRequestError(err.message || 'Unable to create user');
  });

  await sendEmailUsingTemplateId('invitation001', {
    toEmail: req.body.Email,
    subject: 'Internal User Invitation',
    name: req.body.FullName,
    user_type: 'an internal user',
    email_cred: userPrincipalName,
    password
  }).catch((err) => {});
  // Uncomment later if required
  // const groupId = await getGroupsAzureId(req.body.UserType);
  // await addMemberToGroup(groupId, azureUser.id).catch((err) => {
  //   throw new BadRequestError(
  //     err.message || 'Unable to add member to group ' + req.body.UserType
  //   );
  // });
  return res.status(201).send(successResponse(azureUser, 'User created'));
};

/** @type {import("express").RequestHandler} */
exports.updateUser = async (req, res) => {
  const data = await getUserByPrincipleName(req.params.id);
  if (data.length < 1) throw new BadRequestError('Invalid UserId');
  // if there are no updates also mark old entity as inactive - to track update log
  await collections.TT_USER_DETAILS.updateEntity(
    {
      ...data[0],
      Status: req.body.Status === 'Inactive' ? 'Inactive' : 'Expired'
    },
    'Merge'
  );
  // FIXME: update in azure ad not working
  await updateMSUserDetails(req.params.id, req.body).catch((err) => {
    throw new BadRequestError(err.message || 'Unable to update user on AD');
  });
  if (req.body.Status === 'Inactive') {
    return res.send(successResponse('User details updated'));
  }
  delete data[0].etag;
  delete data[0].rowKey;
  delete data[0].Status;
  await collections.TT_USER_DETAILS.createEntity({
    partitionKey: data[0].partitionKey,
    rowKey: generateUUID(),
    ...data[0],
    ...req.body,
    CreatedBy: req.authInfo.preferred_username,
    Status: 'Active'
  });
  return res.send(successResponse('User details updated'));
};

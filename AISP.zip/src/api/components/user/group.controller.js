const collections = require('#collections');
const { BadRequestError } = require('#errors');
const successResponse = require('#response');
const { createGroup } = require('#utils/ms-graph/group');

/** @type {import("express").RequestHandler} */
exports.listGroups = async (req, res) => {
  const filters = [];
  // eslint-disable-next-line quotes
  filters.push("role_type eq 'group'");

  if (req.query.status) {
    filters.push(`status eq '${req.query.status}'`);
  } else {
    // eslint-disable-next-line quotes
    filters.push("status ne 'Deleted'");
  }

  if (req.query.searchGlobal) {
    const searchFilters = [
      `role_name eq '${req.query.searchGlobal}'`
      // `ContactPersonName eq '${req.query.searchGlobal}'`
    ];

    // Join the search filters with 'or' to allow any match
    filters.push(`(${searchFilters.join(' or ')})`);
  }
  const groups = collections.TT_ROLES.listEntities({
    queryOptions: { filter: filters.join(' and ') }
  });
  const groupDetails = [];
  for await (const group of groups) {
    groupDetails.push(group);
  }
  return res.send(successResponse(groupDetails));
};

/** @type {import("express").RequestHandler} */
exports.createGroup = async (req, res) => {
  const group_name = req.body.name.toLowerCase().split(' ').join('_');
  // Group data to be created
  const newGroup = {
    displayName: process.env.ORG_CODE + '_' + group_name,
    description:
      'Description of the ' + process.env.ORG_CODE + '_' + group_name,
    groupTypes: ['Unified'],
    mailEnabled: false,
    mailNickname: process.env.ORG_CODE + '_' + group_name,
    securityEnabled: true
  };
  const groupAz = await createGroup(newGroup).catch((err) => {
    throw new BadRequestError(err.message || 'Unable to create group');
  });
  await collections.TT_ROLES.createEntity({
    partitionKey: groupAz.id, // azure ad group id
    rowKey: group_name,
    role_name: req.body.name,
    created_by: req.authInfo.preferred_username,
    azure_ad_group: groupAz.displayName,
    status: 'Active',
    role_type: 'group'
  });
  for (const roleId of req.body.roleIds) {
    await collections.TT_GROUP_ROLES.createEntity({
      partitionKey: groupAz.id,
      rowKey: roleId
    }).catch((err) => {});
  }
  return res.status(201).send(successResponse(groupAz, 'Group created'));
};

/** @type {import("express").RequestHandler} */
exports.getGroup = async (req, res) => {
  const data = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}' and role_type eq 'group'`
    }
  });
  const group = [];
  for await (const d of data) {
    group.push(d);
  }
  if (group.length < 1) throw new BadRequestError('Invalid group id');
  const rolesRaw = collections.TT_GROUP_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${group[0].partitionKey}' and status eq 'Active'`
    }
  });
  group[0].roles = [];
  for await (const role of rolesRaw) {
    const roleDetailsRaw = collections.TT_ROLES.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${role.rowKey}'`,
        select: ['role_name', 'role_type']
      }
    });
    let latestRoleDetails = null;
    for await (const roleDetials of roleDetailsRaw) {
      latestRoleDetails = { ...role, ...roleDetials };
    }
    group[0].roles.push(latestRoleDetails);
  }
  return res.send(successResponse(group[0]));
};

/** @type {import("express").RequestHandler} */
exports.updateGroup = async (req, res) => {
  const data = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}' and role_type eq 'group'`
    }
  });
  const group = [];
  for await (const d of data) {
    group.push(d);
  }
  if (group.length < 1) throw new BadRequestError('Invalid role id');
  // update group details
  await collections.TT_ROLES.updateEntity({
    ...group[0],
    role_name: req.body.name,
    status: req.body?.status || group[0].status
  });
  // create group:role mapping, if exists it will throw error
  for (const roleId of req.body.roleIds) {
    await collections.TT_GROUP_ROLES.updateEntity({
      partitionKey: req.params.id,
      rowKey: roleId,
      status: 'Active'
    }).catch((err) => {});
    await collections.TT_GROUP_ROLES.createEntity({
      partitionKey: req.params.id,
      rowKey: roleId,
      status: 'Active'
    }).catch((err) => {
      console.log(
        err.message || `unable to add ${roleId} role to group ${req.params.id}`
      );
    });
  }
  // deactive which are not present in req.body.roleIds
  const currentGroupRolesRaw = collections.TT_GROUP_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}'`,
      select: ['rowKey']
    }
  });
  const currentGroupRoles = [];
  for await (const gr of currentGroupRolesRaw) {
    currentGroupRoles.push(gr);
  }
  for (const cgr of currentGroupRoles) {
    if (!req.body.roleIds.includes(cgr.rowKey)) {
      await collections.TT_GROUP_ROLES.updateEntity({
        partitionKey: req.params.id,
        rowKey: cgr.rowKey,
        status: 'Inactive'
      }).catch((err) => {});
    }
  }
  return res.send(successResponse('Group Details Updated'));
};

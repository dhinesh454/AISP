const collections = require('#collections');
const { BadRequestError } = require('#errors');
const successResponse = require('#response');
const { getUserByPrincipleName } = require('./user.service');

/** @type {import("express").RequestHandler} */
exports.createAssignments = async (req, res) => {
  const userPrincipleName = req.body.userPrincipleName;
  const user = await getUserByPrincipleName(userPrincipleName);
  if (user[0].user_type == 'supplier')
    throw new BadRequestError(
      'Assignments can be created/updated for supplier users'
    );
  //TODO: for internal users supplier roles can not be assigned
  for (const roleAzureId of req.body.roleIds) {
    // get single role
    const roleRaw = collections.TT_ROLES.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${roleAzureId}'` // and Status eq 'Active' - is not needed
      }
    });
    const role = [];
    for await (const r of roleRaw) {
      role.push(r);
    }
    if (!role[0]) throw new BadRequestError('Invalid Role Id:' + roleAzureId);

    await collections.TT_ROLE_ASSIGNMENTS.updateEntity({
      partitionKey: userPrincipleName,
      rowKey: roleAzureId,
      status: 'Active'
    }).catch((err) => {});
    await collections.TT_ROLE_ASSIGNMENTS.createEntity({
      partitionKey: req.body.userPrincipleName,
      rowKey: roleAzureId,
      Status: 'Active'
    }).catch((err) => {});
    // If needed to Inactive roles which are not passed in req.body.roleIds
    // const roleAssignmentsRaw = collections.TT_ROLE_ASSIGNMENTS.listEntities({
    //   queryOptions: {
    //     filter: `PartitionKey eq '${userPrincipleName}'`
    //   }
    // });
    // const roleAssignments = [];
    // for await (const ra of roleAssignmentsRaw) {
    //   roleAssignments.push(ra);
    // }
    // for (const cra of roleAssignments) {
    //   if (!req.body.roleIds.includes(cra.rowKey)) {
    //     await collections.TT_ROLE_ASSIGNMENTS.updateEntity({
    //       partitionKey: userPrincipleName,
    //       rowKey: cra.rowKey,
    //       Status: 'Inactive'
    //     });
    //   }
    // }
  }
  return res.send(successResponse('Role attached to user'));
};

/** @type {import("express").RequestHandler} */
exports.listAssignments = async (req, res) => {
  const filters = [];
  if (req.query.userPrincipleName) {
    filters.push(`PartitionKey eq '${req.query.userPrincipleName}'`);
  }
  if (req.query.roleId) {
    filters.push(`RowKey eq '${req.query.roleId}'`);
  }
  const assignmentsRaw = collections.TT_ROLE_ASSIGNMENTS.listEntities({
    queryOptions: { filter: filters.join(' and ') }
  });
  const assignments = [];
  for await (const assignment of assignmentsRaw) {
    const assignmentsRaw = collections.TT_ROLES.listEntities({
      queryOptions: {
        filter: `PartitionKey eq '${assignment.rowKey}'`,
        select: ['role_name', 'role_type']
      }
    });
    let latestAssignmentDetails = null;
    for await (const assignmentDetails of assignmentsRaw) {
      latestAssignmentDetails = assignmentDetails;
    }
    assignment.details = latestAssignmentDetails;
    // TODO: implement valid to and valid from
    // assignment.valid_from = new Date();
    // assignment.valid_to = new Date();
    assignments.push(assignment);
  }
  return res.send(successResponse(assignments, 'List assignments'));
};

/** @type {import("express").RequestHandler} */
exports.getAssignments = async (req, res) => {
  const data = await collections.TT_ROLE_ASSIGNMENTS.getEntity(
    req.params.userPrincipleName,
    req.params.roleId
  );
  if (!data) throw new BadRequestError('No Assignment Found');
  const assignmentsRaw = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${data.rowKey}'`,
      select: ['role_name', 'role_type']
    }
  });
  let latestAssignmentDetails = null;
  for await (const assignmentDetails of assignmentsRaw) {
    latestAssignmentDetails = assignmentDetails;
  }
  data.details = latestAssignmentDetails;
  return res.send(successResponse(data));
};

/** @type {import("express").RequestHandler} */
exports.updateAssignments = async (req, res) => {
  const data = await collections.TT_ROLE_ASSIGNMENTS.getEntity(
    req.params.userPrincipleName,
    req.params.roleId
  );
  if (!data) throw new BadRequestError('No Assignment Found');
  collections.TT_ROLE_ASSIGNMENTS.updateEntity({
    partitionKey: req.params.userPrincipleName,
    rowKey: req.params.roleId,
    Status: req.body.Status,
    ...req.body
  })
    .then((data) => {
      return res.send(successResponse(data, 'Assignment updated'));
    })
    .catch((err) => {
      console.log(err);
      throw new BadRequestError('Unable to update assignment');
    });
};

/** @type {import("express").RequestHandler} */
exports.deleteAssignment = async (req, res) => {
  if (!req.body.assignmentId || !req.body.userPrincipleName)
    throw new BadRequestError(
      'assignmentId and userPrincipleName required in request body'
    );
  await collections.TT_ROLE_ASSIGNMENTS.updateEntity({
    partitionKey: req.body.assignmentId,
    rowKey: req.body.userPrincipleName,
    Status: 'Inactive'
  }).catch((err) => {
    console.log(err);
  });
  return res.send(successResponse('Assignment Modified'));
};

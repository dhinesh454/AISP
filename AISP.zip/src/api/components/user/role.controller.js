const collections = require('#collections');
const { BadRequestError } = require('#errors');
const successResponse = require('#response');
const { createGroup } = require('#utils/ms-graph/group');
const {
  createNestedPermissions,
  flattenNestedPermissions
} = require('#utils/serializers');

// function flattenObject(obj, prefix = '', result = {}) {
//   for (const [key, value] of Object.entries(obj)) {
//     const newKey = prefix ? `${prefix}.${key}` : key;
//     if (typeof value === 'object' && value !== null) {
//       flattenObject(value, newKey, result);
//     } else {
//       result[newKey] = value;
//     }
//   }
//   return result;
// }

/** @type {import("express").RequestHandler} */
exports.listRoles = async (req, res) => {
  const combinedResults = [];
  let continuationToken = req.query.nextToken || null;

  const filters = [];
  // eslint-disable-next-line quotes
  filters.push("role_type eq 'single'");

  if (req.query.status) {
    filters.push(`status eq '${req.query.status}'`);
  } else {
    // eslint-disable-next-line quotes
    filters.push("status ne 'Deleted'");
  }

  if (req.query.searchGlobal) {
    // Assuming 'PhoneNumber', 'Name', and 'RequestID' are the column names
    const searchFilters = [
      `role_name eq '${req.query.searchGlobal}'`
      // `ContactPersonName eq '${req.query.searchGlobal}'`
    ];

    // Join the search filters with 'or' to allow any match
    filters.push(`(${searchFilters.join(' or ')})`);
  }

  // Setting up the options for pagination
  const options = {
    queryOptions: {
      filter: filters.join(' and ')
    }
  };

  // Fetching the data with pagination control
  const pagedIterator = collections.TT_ROLES.listEntities(options).byPage({
    maxPageSize: req.query.pageSize ? parseInt(req.query.pageSize) : 10,
    continuationToken
  });

  // Retrieve the first page
  const page = await pagedIterator.next();

  // Checking if the page has results and handling them
  if (!page.done) {
    combinedResults.push(...page.value);
    // Continuation token for the next page
    continuationToken = page.value.continuationToken;
  }

  // Return the results and the next page continuation toke
  return res.send({
    data: combinedResults,
    nextToken: continuationToken,
    success: true
  });
};

/** @type {import("express").RequestHandler} */
exports.createRole = async (req, res) => {
  const group_name = req.body.name.toLowerCase().split(' ').join('_');
  // return res.send(flattenNestedPermissions(req.body.permissions))
  // Group data to be created
  const newGroup = {
    displayName: process.env.ORG_CODE + '_' + group_name,
    description:
      'Description of the ' + process.env.ORG_CODE + '_' + group_name,
    groupTypes: ['Unified'],
    mailEnabled: false,
    mailNickname: process.env.ORG_CODE + '_' + group_name,
    securityEnabled: true
  };
  const groupAz = await createGroup(newGroup).catch((err) => {
    throw new BadRequestError(err.message || 'Unable to create group in AD');
  });
  const groupDb = await collections.TT_ROLES.createEntity({
    partitionKey: groupAz.id, // azure ad group id
    rowKey: group_name,
    role_name: req.body.name,
    created_by: req.authInfo.preferred_username,
    azure_ad_group: groupAz.displayName,
    status: 'Active',
    role_type: 'single'
  });
  for (const permission of flattenNestedPermissions(req.body.permissions)) {
    const entity = await collections.TT_ROLE_PERMISSIONS.getEntity(
      'master',
      permission.id
    ).catch((err) => {});
    if (!entity) continue;
    delete entity.partitionKey;
    delete entity.rowKey;
    delete entity.created_by;
    delete entity.role_perm_status;
    delete entity.role_permission_type;
    const existing = await collections.TT_ROLE_PERMISSIONS.getEntity(
      groupAz.id,
      permission.id
    ).catch((err) => {
      console.log(err);
    });
    if (existing) {
      await collections.TT_ROLE_PERMISSIONS.updateEntity({
        ...existing,
        role_perm_status: permission.status
      });
      continue;
    }
    await collections.TT_ROLE_PERMISSIONS.createEntity({
      partitionKey: groupAz.id,
      rowKey: permission.id,
      role_perm_status: permission.status,
      ...entity,
      created_by: req.authInfo.preferred_username
    });
  }
  return res.status(201).send(successResponse(groupDb, 'Role created'));
};

/** @type {import("express").RequestHandler} */
exports.getRole = async (req, res) => {
  const data = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}' and role_type eq 'single'`
    }
  });
  const role = [];
  for await (const d of data) {
    role.push(d);
  }
  if (role.length < 1) throw new BadRequestError('Invalid role id');
  const permissions = collections.TT_ROLE_PERMISSIONS.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${role[0].partitionKey}'`,
      select: [
        'RowKey',
        'role_perm_status',
        'action_desc',
        'nav_desc',
        'field_description',
        'role_module'
      ]
    }
  });
  role[0].permissions = [];
  for await (const perm of permissions) {
    role[0].permissions.push(perm);
  }
  role[0].permissions = createNestedPermissions(role[0].permissions);

  return res.send(successResponse(role[0]));
};

/** @type {import("express").RequestHandler} */
exports.updateRole = async (req, res) => {
  const data = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}' and role_type eq 'single' and status ne 'Deleted'`
    }
  });
  const role = [];
  for await (const d of data) {
    role.push(d);
  }
  if (role.length < 1) throw new BadRequestError('Invalid role id');
  // system roles can not be updated
  if (role[0].created_by == 'system')
    throw new BadRequestError('System roles can not be updated');
  await collections.TT_ROLES.updateEntity(
    {
      ...role[0],
      role_name: req.body.name || role[0].role_name,
      status: req.body.status
    },
    'Merge'
  );
  if (req.body.permissions) {
    for (const permission of flattenNestedPermissions(req.body?.permissions)) {
      const entity = await collections.TT_ROLE_PERMISSIONS.getEntity(
        'master',
        permission.id
      ).catch((err) => {});
      if (!entity) continue;
      delete entity.partitionKey;
      delete entity.rowKey;
      delete entity.created_by;
      delete entity.role_permission_type;
      delete entity.role_perm_status;
      const existing = await collections.TT_ROLE_PERMISSIONS.getEntity(
        role[0].partitionKey,
        permission.id
      ).catch((err) => {});
      if (existing) {
        await collections.TT_ROLE_PERMISSIONS.updateEntity({
          ...existing,
          role_perm_status: permission.status
        });
        continue;
      }
      await collections.TT_ROLE_PERMISSIONS.createEntity({
        partitionKey: role[0].partitionKey,
        rowKey: permission.id,
        ...entity,
        role_perm_status: permission.status,
        created_by: req.authInfo.preferred_username
      });
    }
  }
  return res.send(successResponse(role));
};

/** @type {import("express").RequestHandler} */
exports.deleteRole = async (req, res) => {
  const data = collections.TT_ROLES.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${req.params.id}' and role_type eq 'single' and status ne 'Deleted'`
    }
  });
  const role = [];
  for await (const d of data) {
    role.push(d);
  }
  if (role.length < 1) throw new BadRequestError('Invalid role id');
  await collections.TT_ROLES.updateEntity({
    ...role[0],
    status: 'Deleted',
    deleted_by: req.authInfo.preferred_username
  });
  return res.send(successResponse(role, 'Role deleted.'));
};

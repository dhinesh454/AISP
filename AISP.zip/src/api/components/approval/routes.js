const router = require('express').Router();

const checkAuth = require('#middlewares/check-auth');
const setApprovalLevel = require('#middlewares/set-approvalLevel');
const requestValidator = require('#utils/request-validator');
const { createCommentB } = require('#validators/empanelment');
const {
  listOfApprovals,
  getApprovalDetails,
  approvalAction,
  // bulkApprove,
  // bulkReject,
  // getApprovalLog,
  listComments,
  addComment,
  addAttachment,
  listAttachments,
  checkExistance
} = require('./approval.controller');

// approval process
router.get(
  '/getapprovals',
  // checkAuth([
  //   'Onboarding.VendorApproveL1.Read',
  //   'Onboarding.VendorApproveL2.Read'
  // ]),
  setApprovalLevel,
  listOfApprovals
);
router.get(
  '/getapproval/:id',
  checkAuth([
    'Onboarding.VendorApproveL1.Read',
    'Onboarding.VendorApproveL2.Read'
  ]),
  getApprovalDetails
);
router.patch(
  '/action',
  checkAuth([
    'Onboarding.VendorApproveL1.Create',
    'Onboarding.VendorApproveL2.Create'
  ]),
  approvalAction
);
// router.patch('/bulkapprove', checkAuth(), bulkApprove);
// router.patch('/bulkreject', checkAuth(), bulkReject);
// router.get('/approvallog/:id', checkAuth(), getApprovalLog);
router.get(
  '/comments/:id',
  checkAuth([
    'Onboarding.VendorApproveL1.Create',
    'Onboarding.VendorApproveL2.Create',
    // 'Onboarding.VendorApproveL1.Read',
    // 'Onboarding.VendorApproveL2.Read',
    'Onboarding.VendorApproveL1.Edit',
    'Onboarding.VendorApproveL2.Edit'
    // supplier user type check
  ]),
  listComments
);
router.post(
  '/comments/',
  checkAuth([
    // 'Onboarding.VendorApproveL1.Create',
    // 'Onboarding.VendorApproveL2.Create',
    // 'Onboarding.VendorApproveL1.Read',
    // 'Onboarding.VendorApproveL2.Read',
    // 'Onboarding.VendorApproveL1.Edit',
    // 'Onboarding.VendorApproveL2.Edit'
  ]),
  requestValidator(createCommentB),
  addComment
);
router.get(
  '/attachments/:id',
  checkAuth([
    'Onboarding.VendorApproveL1.Create',
    'Onboarding.VendorApproveL2.Create',
    'Onboarding.VendorApproveL1.Read',
    'Onboarding.VendorApproveL2.Read',
    'Onboarding.VendorApproveL1.Edit',
    'Onboarding.VendorApproveL2.Edit'
  ]),
  listAttachments
);
router.post(
  '/attachments/:id',
  checkAuth([
    'Onboarding.VendorApproveL1.Create',
    'Onboarding.VendorApproveL2.Create',
    // 'Onboarding.VendorApproveL1.Read',
    // 'Onboarding.VendorApproveL2.Read',
    'Onboarding.VendorApproveL1.Edit',
    'Onboarding.VendorApproveL2.Edit'
  ]),
  addAttachment
);
router.get('/IsExistingApprovals', checkAuth(), checkExistance);

module.exports = router;

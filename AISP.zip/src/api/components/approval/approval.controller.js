const successResponse = require('#response');
const collections = require('#collections');
const { BadRequestError } = require('#errors');
const { default: axios } = require('axios');
const { generateUUID } = require('#utils/password');
const { getEmpResponseByRowKey } = require('../empanelment/services');
const {
  EMPANELMENT_REQUEST_SUBMITTED,
  EMPANELMENT_REQUEST_APPROVED,
  EMPANELMENT_REQUEST_REJECTED,
  EMPANELMENT_REQUEST_RETURNED,
  EMPANELMENT_REQUEST_RESUBMITTED,
  EMPANELMENT_REQUEST_REVIEWED,
  EMPANELMENT_REQUEST_COMPLETED
} = require('#enums/empanelment-status');
// const { getUserAccess } = require('../user/services');

// function findUsersWithPermission(permissionKey, access) {
//   const usersWithPermission = [];
//   access.forEach((user) => {
//     const { rowKey, permissions } = user;
//     const hasPermission = permissions.some(
//       (permission) => permission.rowKey === permissionKey
//     );
//     if (hasPermission) {
//       usersWithPermission.push(rowKey);
//     }
//   });
//   return usersWithPermission;
// }

// TODO: move this function to utils
async function callLogicAppApprovalApi(url, data) {
  const params = new URLSearchParams();
  Object.keys(data).forEach((key) => params.append(key, data[key]));

  try {
    const response = await axios.post(url, params, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
    console.log('Approval API Response:', response.data);
  } catch (error) {
    console.error('Approval API Error:', error.response);
    throw new Error(error.response?.data?.error?.message);
  }
}
/**
 *
 * @param {Object} obj object
 * @returns
 */
function nestify(obj) {
  const result = {};

  for (const key in obj) {
    // eslint-disable-next-line no-prototype-builtins
    if (obj.hasOwnProperty(key)) {
      const parts = key.split('_');
      let current = result;

      // Iterate over parts of the key to build nested objects
      for (let i = 0; i < parts.length - 1; i++) {
        if (!current[parts[i]]) {
          current[parts[i]] = {};
        }
        current = current[parts[i]];
      }

      // Set the final part of the key to the original value
      current[parts[parts.length - 1]] = obj[key];
    }
  }

  return result;
}
/** @type {import("express").RequestHandler} */
exports.listOfApprovals = async (req, res) => {
  // fetch list of approvals from collection
  const approvalLevel = req.authInfo.approvalLevel
    .map((level) => `CurrentApprovalLevel eq ${level - 1}`)
    .join(' or ');
  const data = collections.TT_EMPANELMENT_APPROVAL.listEntities({
    queryOptions: {
      filter: approvalLevel, // + "and CurrentApprovalStatus eq 'Started'",
      select: [
        'rowKey',
        'partitionKey',
        'CurrentApprovalLevel',
        'CurrentApprovalStatus',
        'timestamp'
      ]
    }
  });
  const latestEntries = [];

  for await (const entry of data) {
    const data = await getEmpResponseByRowKey(entry.partitionKey).catch(
      (err) => {
        console.log(err);
        console.log('entry', entry);
      }
    );
    // Assume there's a 'timestamp' or 'updatedAt' field in each entry
    // if (
    //   !latestEntries[partitionKey] ||
    //   latestEntries[partitionKey].Timestamp < entry.Timestamp
    // ) {
    //   latestEntries[partitionKey] = entry;
    // }
    entry.data = nestify(data);
    latestEntries.push(entry);
  }

  // Convert the object to an array containing the latest entries
  // const entries = Object.values(latestEntries);
  return res.send(successResponse(latestEntries, 'listOfApprovals'));
};

/** @type {import("express").RequestHandler} */
exports.getApprovalDetails = async (req, res) => {
  // fetch approval details from ttEmpanelmentForm collection
  const data = collections.TT_EMPANELMENT_FORM.listEntities({
    queryOptions: {
      filter: `RowKey eq '${req.params.id}'`
    }
  });
  const entries = [];
  for await (const i of data) {
    entries.push(i);
  }
  return res.send(successResponse(entries));
};

/** @type {import("express").RequestHandler} */
exports.approvalAction = async (req, res) => {
  // approve an approval with approval id
  const approvalRow = collections.TT_EMPANELMENT_APPROVAL.listEntities({
    queryOptions: {
      filter: `RowKey eq '${req.body.id}'`
    }
  });
  const approvals = [];
  for await (const approval of approvalRow) {
    approvals.push(approval);
  }
  if (approvals.length < 1) throw new BadRequestError('Invalid approval id');
  // check if action already taken on this
  if (approvals[0].CurrentApprovalStatus !== 'Started')
    throw new BadRequestError('Action already taken on this request');
  // call approval api
  await callLogicAppApprovalApi(approvals[0].CalbackUrl, {
    Approver_Action: req.body.action
  }).catch((err) => {
    throw new BadRequestError(err);
  });
  // update cuurentApprovalLevel to completed
  await collections.TT_EMPANELMENT_APPROVAL.updateEntity({
    ...approvals[0],
    CurrentApprovalStatus: 'Completed_' + req.body.action,
    ActionTakenBy: req.authInfo?.preferred_username
  });

  // update ttEmpanelmentForm table
  const data = collections.TT_EMPANELMENT_FORM.listEntities({
    queryOptions: {
      filter: `RowKey eq '${approvals[0].partitionKey}'`
    }
  });
  const entries = [];
  for await (const i of data) {
    entries.push(i);
  }
  const currentApprovalStatus = entries[0]?.ApprovalStatus;
  const currentApprovalLevel = approvals[0].CurrentApprovalLevel;
  let updatedApprovalStatus = EMPANELMENT_REQUEST_SUBMITTED;
  let updatedEmpanelmentFormStatus = EMPANELMENT_REQUEST_SUBMITTED;

  switch (currentApprovalStatus) {
    case 'Started':
    case EMPANELMENT_REQUEST_APPROVED + (currentApprovalLevel - 1):
      // if last level is accepted, entire request is accepted
      if (
        EMPANELMENT_REQUEST_APPROVED + (currentApprovalLevel - 1) ==
        process.env.MAX_LEVEL_APPROVAL
      ) {
        updatedEmpanelmentFormStatus = EMPANELMENT_REQUEST_COMPLETED;
      }
      updatedApprovalStatus =
        EMPANELMENT_REQUEST_APPROVED + currentApprovalLevel;
      break;

    case EMPANELMENT_REQUEST_REJECTED + currentApprovalLevel:
      // if the first level of approval is reected, entire request is rejected
      if (currentApprovalLevel == 0) {
        updatedEmpanelmentFormStatus = EMPANELMENT_REQUEST_REJECTED;
      }
      updatedApprovalStatus =
        EMPANELMENT_REQUEST_REJECTED + currentApprovalLevel;
      break;

    // case EMPANELMENT_REQUEST_RETURNED + currentApprovalLevel:
    //   updatedStatus = EMPANELMENT_REQUEST_RETURNED + currentApprovalLevel;
    //   break;

    // case EMPANELMENT_REQUEST_RESUBMITTED + currentApprovalLevel:
    //   updatedStatus = EMPANELMENT_REQUEST_RESUBMITTED + currentApprovalLevel;
    //   break;

    // check maximum approval level
    // case EMPANELMENT_REQUEST_APPROVED + approvals[0].CurrentApprovalLevel:
    //   updatedStatus = EMPANELMENT_REQUEST_REVIEWED;
    //   TRIGGER SAP API
    //   break;

    default:
      break;
  }

  await collections.TT_EMPANELMENT_FORM.updateEntity({
    ...entries[0],
    Status: updatedEmpanelmentFormStatus,
    ApprovalStatus: updatedApprovalStatus
  }).catch((err) => {});

  return res.send(successResponse('Approval: ' + req.body.action));
  // send mail and other activities
};

exports.reject = async (req, res) => {
  // reject an approval with approval id
  // send mail and other activities
};

/** @type {import("express").RequestHandler} */
exports.bulkApprove = async (req, res) => {
  // approve approval with array of approval ids
};

/** @type {import("express").RequestHandler} */
exports.bulkReject = async (req, res) => {
  // reject approval with array of approval ids
};

/** @type {import("express").RequestHandler} */
exports.getApprovalLog = async (req, res) => {
  // fetch approval log from azure
};

/** @type {import("express").RequestHandler} */
exports.addComment = async (req, res) => {
  // add comment in approval
  await collections.TT_EMPANELMENT_COMMENTS.createEntity({
    partitionKey: req.body.empId, // empanelment id
    rowKey: generateUUID(),
    CommentText: req.body.comment,
    CreatedBy: req.authInfo.preferred_username
  }).catch((err) => {
    console.log(err);
    throw new BadRequestError('Unable to add comment');
  });
  return res.status(201).send(successResponse('Comment added'));
};

/** @type {import("express").RequestHandler} */
exports.listComments = async (req, res) => {
  // get all comments
};

/** @type {import("express").RequestHandler} */
exports.addAttachment = async (req, res) => {
  // add attachment in approval
};

/** @type {import("express").RequestHandler} */
exports.listAttachments = async (req, res) => {
  // get all attachments
};

/** @type {import("express").RequestHandler} */
exports.checkExistance = async (req, res) => {
  const requestId = req.query.requestId;
  if (!requestId)
    throw new BadRequestError('requestId is required in query params');
  const approvalList = collections.TT_EMPANELMENT_APPROVAL.listEntities({
    queryOptions: {
      filter: `PartitionKey eq '${requestId}'`
    }
  });
  const data = [];
  for await (const a of approvalList) {
    data.push(a);
  }
  if (data.length < 1) {
    return res.status(200).send(successResponse({ recordExists: false }));
  }
  return res.status(400).send(successResponse({ recordExists: true }));
};

const successResponse = require('#response');
const collections = require('#collections');
const { BadRequestError, ServiceError } = require('#errors');
const {
  EMPANELMENT_REQUEST_INITIAL,
  EMPANELMENT_REQUEST_AUDIT
} = require('#enums/empanelment-status');
const { inviteSupplier } = require('#utils/email/index');
const { deleteUserByUPN } = require('#utils/ms-graph/user');
const { BUYER_REQUEST, SUPPLIER_REQUEST } = require('#constants/request-types');
const {
  numberGeneration,
  findVobRequestById,
  copyVobRequestToEmpanelment,
  findLatestActiveVobRequestByEmail
} = require('../services/vob-request');
const { generateUUID } = require('#utils/password');
const {
  generateUserPrincipleName,
  createUser
} = require('../../user/user.service');
const { getGroupsAzureId } = require('#utils/db-ad.helper');
const { addMemberToGroup } = require('#utils/ms-graph/group');
const { latestEmpResponseByRequestId } = require('../../empanelment/services');

/** @type {import("express").RequestHandler} */
exports.createVobRequest = async (req, res) => {
  try {
    const requestExists = await findLatestActiveVobRequestByEmail(
      req.body.SupplierEmail
    );
    if (requestExists)
      throw new BadRequestError('Request already exists with same email.');

    // generate unique number
    const initNumber = await numberGeneration({
      APP_NAME: 'VEND_OB_REQ'
    });
    const { userPrincipalName, mailNickName } = generateUserPrincipleName(
      req.body.ContactPersonName,
      initNumber
    );
    const { password, azureUser } = await createUser(
      {
        mailNickName,
        pricipleName: userPrincipalName,
        email: req.body.SupplierEmail,
        fullname: req.body.ContactPersonName,
        company: req.body.SupplierName,
        mobileNumber: req.body.MobileNumber,
        countryCode: req.body.CountryCode,
        userType: 'supplier'
      },
      req.authInfo.preferred_username
    ).catch((err) => {
      throw new BadRequestError(err.message || 'Unable to create user');
    });
    // FIXME: this is giving error
    const groupId = await getGroupsAzureId('supplier');
    await addMemberToGroup(groupId, azureUser.id);
    await collections.TT_ROLE_ASSIGNMENTS.createEntity({
      partitionKey: userPrincipalName,
      rowKey: groupId,
      Status: 'Active'
    });
    const data = {
      ...req.body,
      RequestId: initNumber,
      RowKey: initNumber,
      SupplierAccessEmail: userPrincipalName,
      PartitionKey: BUYER_REQUEST,
      Status: EMPANELMENT_REQUEST_INITIAL,
      CreatedBy: req.authInfo.preferred_username
    };
    const vobreq = await collections.TT_VOB_REQUEST.createEntity(data);
    const formattedResponse = copyVobRequestToEmpanelment(data);
    await collections.TT_EMPANELMENT_FORM.createEntity({
      partitionKey: userPrincipalName,
      rowKey: generateUUID(),
      Status: EMPANELMENT_REQUEST_INITIAL,
      ApprovalStatus: 'Started',
      ...formattedResponse
    });
    // send email
    // console.time('send_email');
    await inviteSupplier(
      req.body.ContactPersonName,
      req.body.SupplierEmail,
      userPrincipalName,
      password
    ).catch((err) => {
      console.log('## Unable to send email');
      console.log(err);
    });
    // console.timeEnd('send_email');
    return res.send(
      successResponse(vobreq, 'Supplier Invited. Request ID: ' + initNumber)
    );
  } catch (error) {
    // console.log(error);
    if (error instanceof BadRequestError)
      throw new BadRequestError(error.message);
    throw new ServiceError(
      error.message || 'Server Error: Self registration failed'
    );
  }
};

/** @type {import("express").RequestHandler} */
exports.getVobRequests = async (req, res) => {
  const combinedResults = [];
  let continuationToken = req.query.nextToken || null;

  const filters = [];
  if (req.query.source === 'buyer') {
    filters.push(`PartitionKey eq '${BUYER_REQUEST}'`);
  }
  if (req.query.source === 'supplier') {
    filters.push(`PartitionKey eq '${SUPPLIER_REQUEST}'`);
  }
  // Retrieve startDate and endDate from the query parameters
  const startDate = req.query.startDate; // YYYY-MM-DD format expected
  const endDate = req.query.endDate; // YYYY-MM-DD format expected

  // Append date filters if both startDate and endDate are provided
  if (startDate && endDate) {
    filters.push(`Timestamp ge datetime'${startDate}T00:00:00.000Z'`);
    filters.push(`Timestamp le datetime'${endDate}T23:59:59.999Z'`);
  }

  if (req.query.status) {
    filters.push(`Status eq '${req.query.status}'`);
  } else {
    // eslint-disable-next-line quotes
    filters.push("Status ne 'Expired'");
  }

  if (req.query.searchUser) {
    filters.push(`SupplierAccessEmail eq '${req.query.searchUser}'`);
  }

  if (req.query.searchGlobal) {
    // Assuming 'PhoneNumber', 'Name', and 'RequestID' are the column names
    const searchFilters = [
      `MobileNumber eq '${req.query.searchGlobal}'`,
      `SupplierName eq '${req.query.searchGlobal}'`,
      `RequestId eq '${req.query.searchGlobal}'`,
      `SupplierEmail eq '${req.query.searchGlobal}'`
      // `ContactPersonName eq '${req.query.searchGlobal}'`
    ];

    // Join the search filters with 'or' to allow any match
    filters.push(`(${searchFilters.join(' or ')})`);
  }

  // Setting up the options for pagination
  const options = {
    queryOptions: {
      filter: filters.join(' and ')
    }
  };

  // Fetching the data with pagination control
  const pagedIterator = collections.TT_VOB_REQUEST.listEntities(options).byPage(
    {
      maxPageSize: req.query.pageSize ? parseInt(req.query.pageSize) : 10,
      continuationToken
    }
  );

  // Retrieve the first page
  const page = await pagedIterator.next();

  // Checking if the page has results and handling them
  if (!page.done) {
    combinedResults.push(...page.value);
    // Continuation token for the next page
    continuationToken = page.value.continuationToken;
  }

  // Return the results and the next page continuation toke
  return res.send({
    data: combinedResults,
    nextToken: continuationToken,
    success: true
  });
};

/** @type {import("express").RequestHandler} */
exports.getVobRequestById = async (req, res) => {
  const vobRequest = await findVobRequestById(req.params.id);
  if (!vobRequest) throw new BadRequestError('Invalid request id');
  return res.send(successResponse(vobRequest));
};

/** @type {import("express").RequestHandler} */
exports.updateVobRequestById = async (req, res) => {
  try {
    const vobRequest = await findVobRequestById(req.params.id);
    if (!vobRequest)
      // eslint-disable-next-line quotes
      throw new BadRequestError("Request doesn't exists with this ID");

    // TODO: if email changed update azure ad email with updated email
    // what if workflow started

    const data = await collections.TT_VOB_REQUEST.updateEntity(
      { ...vobRequest, ...req.body },
      'Merge',
      { etag: '*' }
    );
    return res.send(successResponse(data, 'Request Updated'));
  } catch (error) {
    if (error.statusCode === 404)
      // eslint-disable-next-line quotes
      throw new BadRequestError("Request doesn't exist with this ID");
    if (error instanceof BadRequestError)
      throw new BadRequestError(error.message);
    throw new ServiceError(
      error.message || 'Server Error: update request failed'
    );
  }
};

/** @type {import("express").RequestHandler} */
exports.deleteVobRequestById = async (req, res) => {
  // find request with id
  const vobRequest = await findVobRequestById(req.params.id);
  if (!vobRequest)
    throw new BadRequestError('Request does not exists with this ID');
  // delete user in ad
  await deleteUserByUPN(vobRequest.SupplierAccessEmail);
  // TODO: mark user as inactive in db
  // await collections.TT_USER_DETAILS.updateEntity()
  // mark request as expired
  delete vobRequest.Status;
  await collections.TT_VOB_REQUEST.updateEntity({
    ...vobRequest,
    Status: EMPANELMENT_REQUEST_AUDIT
  });
  return res.send(successResponse(vobRequest));
};

/**
 *
 * @param {Object} obj object
 * @returns
 */
function nestify(obj) {
  const result = {};

  for (const key in obj) {
    // eslint-disable-next-line no-prototype-builtins
    if (obj.hasOwnProperty(key)) {
      const parts = key.split('_');
      let current = result;

      // Iterate over parts of the key to build nested objects
      for (let i = 0; i < parts.length - 1; i++) {
        if (!current[parts[i]]) {
          current[parts[i]] = {};
        }
        current = current[parts[i]];
      }

      // Set the final part of the key to the original value
      current[parts[parts.length - 1]] = obj[key];
    }
  }

  return result;
}
/** @type {import("express").RequestHandler} */
exports.getEmpanelmentRequestById = async (req, res) => {
  const data = await latestEmpResponseByRequestId(req.params?.id);
  if (!data) throw new BadRequestError('Invalid request id');
  return res.send(successResponse(nestify(data)));
};

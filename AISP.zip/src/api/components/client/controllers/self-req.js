const { SUPPLIER_REQUEST, BUYER_REQUEST } = require('#constants/request-types');
const {
  SELF_REQUEST_INITIAL,
  SELF_REQUEST_REJECTED,
  EMPANELMENT_REQUEST_INITIAL,
  SELF_REQUEST_APPROVED
} = require('#enums/empanelment-status');
const { BadRequestError, ServiceError } = require('#errors');
const {
  findVobRequest,
  numberGeneration,
  copyVobRequestToEmpanelment,
  findVobRequestById
} = require('../services/vob-request');
const collection = require('#collections');
const successResponse = require('#response');
const { generateUUID } = require('#utils/password');
const { inviteSupplier, empanlementRejected } = require('#utils/email/index');
const collections = require('#collections');
const {
  generateUserPrincipleName,
  createUser
} = require('../../user/user.service');
const { getGroupsAzureId } = require('#utils/db-ad.helper');
const { addMemberToGroup } = require('#utils/ms-graph/group');

/** @type {import("express").RequestHandler} */
exports.createSelfRequest = async (req, res) => {
  try {
    const requestExists = await findVobRequest(req.body);
    if (requestExists && requestExists?.Status !== 'Rejected')
      throw new BadRequestError('Request already exists with same email.');

    // generate unique number
    const initNumber = await numberGeneration({
      APP_NAME: 'SELF_REG'
    });

    const data = {
      ...req.body,
      RequestId: initNumber,
      RowKey: initNumber,
      PartitionKey: SUPPLIER_REQUEST,
      Status: SELF_REQUEST_INITIAL,
      CreatedBy: req.body.SupplierEmail
    };
    const selfreg = await collection.TT_VOB_REQUEST.createEntity(data);

    return res.send(
      successResponse(selfreg, 'Request Submitted. Request ID: ' + initNumber)
    );
  } catch (error) {
    // console.log(error);
    if (error instanceof BadRequestError)
      throw new BadRequestError(error.message);
    throw new ServiceError(
      error.message || 'Server Error: Self registration failed'
    );
  }
};

/** @type {import("express").RequestHandler} */
exports.approveSelfRequest = async (req, res) => {
  const request = await findVobRequestById(req.body.id);
  if (!request) throw new BadRequestError('Invalid Request Id');
  if (request.partitionKey === BUYER_REQUEST)
    throw new BadRequestError('Empanelment Already Created');
  if (request.Status !== SELF_REQUEST_INITIAL)
    throw new BadRequestError('Action has already been taken on this request');
  if (req.body.action === 'R') {
    await collections.TT_VOB_REQUEST.updateEntity({
      ...request,
      ActionTakenBy: req.authInfo.preferred_username,
      Status: SELF_REQUEST_REJECTED
    });
    await empanlementRejected(request.ContactPersonName, request.SupplierEmail);
    return res.send(successResponse('Self request rejected'));
  }
  const formatted = copyVobRequestToEmpanelment(request);
  const { userPrincipalName, mailNickName } = generateUserPrincipleName(
    request.ContactPersonName,
    request.rowKey
  );
  const { password, azureUser } = await createUser(
    {
      mailNickName,
      pricipleName: userPrincipalName,
      email: request.SupplierEmail,
      fullname: request.ContactPersonName,
      company: request.SupplierName,
      mobileNumber: request.MobileNumber,
      countryCode: request.CountryCode,
      userType: 'supplier'
    },
    req.authInfo.preferred_username
  ).catch((err) => {
    throw new BadRequestError(err.message || 'Unable to create user');
  });
  await collections.TT_VOB_REQUEST.updateEntity({
    ...request,
    Status: SELF_REQUEST_APPROVED,
    ActionTakenBy: req.authInfo.preferred_username,
    SupplierAccessEmail: userPrincipalName
  });
  const groupId = await getGroupsAzureId('supplier');
  await addMemberToGroup(groupId, azureUser.id);
  await collections.TT_ROLE_ASSIGNMENTS.createEntity({
    partitionKey: userPrincipalName,
    rowKey: groupId,
    Status: 'Active'
  });
  await inviteSupplier(
    request.ContactPersonName,
    request.SupplierEmail,
    userPrincipalName,
    password
  );
  const data = await collections.TT_EMPANELMENT_FORM.createEntity({
    partitionKey: userPrincipalName,
    rowKey: generateUUID(),
    ...formatted,
    ApprovalStatus: 'Started',
    Status: EMPANELMENT_REQUEST_INITIAL
  });
  return res.send(successResponse(data, 'Self request approved'));
};

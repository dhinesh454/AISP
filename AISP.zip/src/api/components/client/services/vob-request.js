const collections = require('#collections');
const { BUYER_REQUEST, SUPPLIER_REQUEST } = require('#constants/request-types');
const { ServiceError } = require('#errors');

exports.generateUserPrincipleName = (name, initNumber) => {
  const username =
    name.trim().split(' ').join('').toLowerCase() +
    '_' +
    initNumber.toLowerCase();

  const principleName =
    username.slice(0, 4) +
    '_' +
    initNumber.toLowerCase() +
    process.env.EMAIL_DOMAIN;

  return { principleName, username };
};

exports.numberGeneration = async ({
  APP_NAME = 'SELF_REG',
  PartitionKey = 'type_Empanelment'
}) => {
  const number = await collections.TC_GEN_NUMBER.getEntity(
    PartitionKey,
    APP_NAME
  );
  if (number.CurrentNumber === number.ToNumber)
    throw new ServiceError('Number range exceeded');
  number.CurrentNumber++;
  await collections.TC_GEN_NUMBER.updateEntity(number, 'Merge', { etag: '*' });
  return number.Prefix + number.CurrentNumber;
};

/**
 * Checks if request exists with same email, may be buyer_request or supplier_request
 * @param {string} email supplier email
 * @returns
 */
exports.findVobRequest = async (query) => {
  // const combinedResults = [];

  const filters = [];
  if (query.SupplierEmail) {
    filters.push(`SupplierEmail eq '${query.SupplierEmail}'`);
  }
  if (query.PartitionKey) {
    filters.push(`PartitionKey eq '${query.PartitionKey}'`);
  }

  const entries = collections.TT_VOB_REQUEST.listEntities({
    queryOptions: {
      filter: filters.join(' and ')
    }
  });
  let latestEntity = null;
  for await (const entity of entries) {
    if (!latestEntity || entity.timestamp > latestEntity.timestamp) {
      latestEntity = entity;
    }
  }
  return latestEntity;
};

exports.findVobRequestById = async (id) => {
  const reqTypes = [BUYER_REQUEST, SUPPLIER_REQUEST];
  // const entries = [];
  for (const reqType of reqTypes) {
    try {
      const entry = await collections.TT_VOB_REQUEST.getEntity(reqType, id);
      if (entry) return entry;
    } catch (error) {}
  }
  // return
};

exports.findLatestActiveVobRequestByEmail = async (email) => {
  const entries = collections.TT_VOB_REQUEST.listEntities({
    queryOptions: {
      filter: `SupplierEmail eq '${email}' and Status ne 'Expired'`
    }
  });
  let latestEntity = null;
  for await (const entity of entries) {
    if (!latestEntity || entity.timestamp > latestEntity.timestamp) {
      latestEntity = entity;
    }
  }
  return latestEntity;
};

exports.copyVobRequestToEmpanelment = (request) => {
  const formattedResponse = {};
  for (const key in request) {
    if (/[A-Z]/.test(key)) {
      formattedResponse['BasicInformation_' + key] = request[key];
    }
  }
  return formattedResponse;
};

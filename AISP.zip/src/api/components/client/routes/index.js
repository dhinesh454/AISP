const router = require('express').Router();

const checkAuth = require('#middlewares/check-auth');
const requestValidator = require('#utils/request-validator');
const {
  createVobRequest,
  getVobRequests,
  getVobRequestById,
  updateVobRequestById,
  deleteVobRequestById,
  getEmpanelmentRequestById
} = require('../controllers/vob-request');
const {
  createVobRequestV,
  createEmpanelmentV,
  getVobRequestFilterV
} = require('#validators/client/empanelment');
const { approveSelfRequest } = require('../controllers/self-req');

// VOB Request CRUD
router.post(
  '/createvobrequest',
  checkAuth(['Onboarding.VendorInitiate.Create']),
  requestValidator(createVobRequestV),
  createVobRequest
);
router.get(
  '/getvobrequest',
  checkAuth(['Onboarding.VendorInitiate.Read']),
  requestValidator(null, getVobRequestFilterV),
  getVobRequests
);
router.get(
  '/getvobrequest/:id',
  checkAuth(['Onboarding.VendorInitiate.Read']),
  getVobRequestById
);
router.get(
  '/getempresponse/:id',
  checkAuth(['Onboarding.VendorInitiate.Read']),
  getEmpanelmentRequestById
);
router.patch(
  '/updatevobrequest/:id',
  checkAuth(['Onboarding.VendorInitiate.Edit']),
  updateVobRequestById
);
router.delete(
  '/deletevobrequest/:id',
  checkAuth(['Onboarding.VendorInitiate.Delete']),
  deleteVobRequestById
);
// accept reject self request
router.post(
  '/sregaction',
  checkAuth(['Onboarding.SelfApprove.Edit']),
  requestValidator(createEmpanelmentV),
  approveSelfRequest
);
module.exports = router;

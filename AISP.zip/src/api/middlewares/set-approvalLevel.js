const { getUserPermissions } = require('../components/user/user.service');

/**
 * Check authentication and user permission
 * @returns
 */
module.exports =
  /** @type {import("express").RequestHandler} */
  (req, res, next) => {
    // user logged in
    if (!req.authInfo) {
      return res.status(401).json({ message: 'User not authenticated' });
    }
    // check user permission
    getUserPermissions(req.authInfo)
      .then((permissions) => {
        req.authInfo.permissions = permissions;
        const VendorApproveL = [];

        permissions.forEach((permission) => {
          const match = permission.match(/Onboarding\.VendorApproveL\d+\.(.+)/);
          if (match) {
            const action = match[1];
            const number = parseInt(permission.match(/\d+/)[0]);
            // if (!VendorApproveL[action]) {
            //   VendorApproveL[action] = [];
            // }
            // if (!VendorApproveL[action].includes(number)) {
            //   VendorApproveL[action].push(number);
            // }
            if (!VendorApproveL.includes(number)) {
              VendorApproveL.push(number);
            }
          }
        });
        // if (VendorApproveL.length < 1)
        //   return res.status(403).json({ message: 'Insufficient Permission' });

        req.authInfo.approvalLevel = VendorApproveL;

        next();
      })
      .catch((err) => {
        console.error('Error checking access:', err);
        return res
          .status(500)
          .json({ message: 'Internal Server Error', success: false });
      });
  };

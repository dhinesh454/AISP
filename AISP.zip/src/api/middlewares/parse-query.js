/** @type {import("express").RequestHandler} */
const parseQuery = (req, res, next) => {
  // Sorting
  // req.order = req.query.sort ? req.query.sort.split(',') : ['id'];

  // Pagination
  req.offset = req.query.offset ? parseInt(req.query.offset) : 0;
  req.limit = req.query.limit ? parseInt(req.query.limit) : 10;

  next();
};

module.exports = parseQuery;

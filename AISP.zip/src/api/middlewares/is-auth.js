const { UnauthorizedError } = require('#errors');

function isAuthenticated(req, res, next) {
  // console.log(req.session.cookie);
  if (!req.authInfo) {
    throw new UnauthorizedError('User not authenticated');
  }

  // if (
  //   !req.session?.account?.idTokenClaims?.groups.includes(
  //     process.env.TENANT_AD_GROUPS
  //   )
  // )
  //   throw new ForbiddenError('You do not have access to this tenant');
  next();
}

module.exports = isAuthenticated;

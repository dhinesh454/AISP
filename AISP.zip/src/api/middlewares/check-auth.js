// const jwt = require('jsonwebtoken');
// const { UnauthorizedError, ForbiddenError } = require('#errors');

const { getUserPermissions } = require('../components/user/user.service');

/**
 * Check authentication and user permission
 * @param {Array<number>} allowedPermissions list of allowed permissions
 * @returns
 */
module.exports = (allowedPermissions) => {
  /** @type {import("express").RequestHandler} */
  return (req, res, next) => {
    // user logged in
    if (!req.authInfo) {
      return res.status(401).json({ message: 'User not authenticated' });
    }
    // check user permission
    getUserPermissions(req.authInfo)
      .then((permissions) => {
        if (
          allowedPermissions?.length > 0 &&
          !allowedPermissions.some((permission) =>
            permissions.includes(permission)
          )
        )
          return res
            .status(403)
            .json({ message: 'Insufficient Permission', success: false });

        // If the user's permission matches, proceed to the next middleware or route handler
        next();
      })
      .catch((err) => {
        console.error('Error checking access:', err);
        return res
          .status(500)
          .json({ message: 'Internal Server Error', success: false });
      });
  };
};

const Joi = require('joi');

exports.createAssignmentB = Joi.object({
  userPrincipleName: Joi.string().required(),
  roleIds: Joi.array().items(Joi.string())
});

exports.updateOneAssignmentB = Joi.object({
  Status: Joi.string().required()
}).unknown(true);

exports.updateOneAssignmentP = Joi.object({
  userPrincipleName: Joi.string().required(),
  roleId: Joi.string().required()
});

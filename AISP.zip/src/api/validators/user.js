const Joi = require('joi');

exports.createUserValidator = Joi.object({
  FullName: Joi.string().min(3).max(30).required(),
  Email: Joi.string().email().required(),
  ContactNumber: Joi.string().length(10).required(),
  Company: Joi.string().min(3).max(100).required(),
  Country: Joi.string().required(),
  Status: Joi.string()
    .valid('Active', 'Inactive')
    .required()
    .default('Inactive'),
  Plan: Joi.string().optional()
  // Uncomment this if required
  // UserType: Joi.string()
  //   .valid('vendor_admin', 'user_admin', 'super_admin')
  // .optional()
}).unknown(true);

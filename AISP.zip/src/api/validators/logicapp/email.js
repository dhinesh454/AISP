const Joi = require('joi');

exports.sendEmailV = Joi.object({
  toEmail: Joi.string().email().required(),
  subject: Joi.string().max(100).required(),
  templateId: Joi.string().required()
}).unknown(true);

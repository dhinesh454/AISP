const Joi = require('joi');

exports.createCommentB = Joi.object({
  empId: Joi.string().required(),
  comment: Joi.string().required()
});

const Joi = require('joi');

exports.createVobRequestV = Joi.object({
  SupplierEmail: Joi.string().email().required(),
  MobileNumber: Joi.alternatives()
    .label('Mobile Number')
    .conditional('Country', {
      is: Joi.string().valid('IN', 'India'),
      then: Joi.string()
        .pattern(/^\d{10}$/)
        .required()
        .messages({
          'string.pattern.base': 'Please enter a valid 10 digit mobile number'
        }),
      // .error(new Error('Please enter a valid 10 digit mobile number')),
      otherwise: Joi.string().pattern(/^\d+$/).required().messages({
        'string.pattern.base': 'Please enter a valid mobile number'
      })
      // .error(new Error('Please enter a valid mobile number'))
    }),
  SupplierName: Joi.string().max(100).required().label('Supplier name'),
  CompanyWebsite: Joi.string().uri().required().label('Company website'),
  Country: Joi.string().required(),
  ContactPersonName: Joi.string()
    .min(3)
    .max(30)
    .required()
    .label('Contact person name')
}).unknown(true);

exports.createEmpanelmentV = Joi.object({
  id: Joi.string().required().label('Request Id'),
  action: Joi.string().valid('A', 'R').required()
});

exports.getVobRequestFilterV = Joi.object({
  source: Joi.string().valid('buyer', 'supplier').optional(),
  startDate: Joi.string()
    .pattern(/^\d{4}-\d{2}-\d{2}$/)
    .error(new Error('startDate should be in YYYY-MM-DD format'))
    .optional(),
  endDate: Joi.string()
    .pattern(/^\d{4}-\d{2}-\d{2}$/)
    .error(new Error('endDate should be in YYYY-MM-DD format'))
    .optional(),
  status: Joi.string().optional(),
  searchTerm: Joi.string().optional(),
  nextToken: Joi.string().optional(),
  pageSize: Joi.number().optional().default(5),
  searchUser: Joi.string().optional(),
  searchGlobal: Joi.string().optional()
});

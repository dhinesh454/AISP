const Joi = require('joi');

exports.createGroupValidator = Joi.object({
  name: Joi.string().min(3).max(30).required(),
  roleIds: Joi.array().required()
}).unknown(true);

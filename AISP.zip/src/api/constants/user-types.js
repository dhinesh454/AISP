// const ADMIN = 1;
const BUYER = process.env.BUYER_GROUP;
const SUPPLIER = process.env.SUPPLIER_GROUP;

module.exports = { BUYER, SUPPLIER };

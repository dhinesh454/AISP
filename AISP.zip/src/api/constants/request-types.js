// const ADMIN = 1;
const BUYER_REQUEST = 'BuyerRequest';
const SUPPLIER_REQUEST = 'SupplierRequest';

module.exports = { BUYER_REQUEST, SUPPLIER_REQUEST };

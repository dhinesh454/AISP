const globalRoute = require('express').Router();

const auth = require('./api/components/user/routes');
// const master = require('./api/components/master/routes');
const buyer = require('./api/components/client/routes');
// const supplier = require('./api/components/supplier/routes');
const empanelment = require('./api/components/empanelment/routes');
const approval = require('./api/components/approval/routes');
// const common = require('./api/components/common/routes');
// const experiment = require('./api/components/sap/routes');
const { NotFoundError } = require('#errors');
const {
  handleUpload,
  multerMiddleware,
  handleDownload
} = require('#utils/file-upload');
const logicApp = require('./api/components/logicapp/routes');

globalRoute.get('/', (req, res) => {
  res.send('api');
});
globalRoute.post('/upload', multerMiddleware, handleUpload);
globalRoute.get('/download', handleDownload);
globalRoute.use('/auth', auth);
// globalRoute.use('/common', common);
// globalRoute.use('/master', master);
globalRoute.use('/buyer', buyer);
// globalRoute.use('/supplier', supplier);
globalRoute.use('/empanelment', empanelment);
globalRoute.use('/approval', approval);
globalRoute.use('/logicapp', logicApp);
// globalRoute.use('/sap', experiment);
globalRoute.use('*', (req, res) => {
  throw new NotFoundError();
});

module.exports = globalRoute;

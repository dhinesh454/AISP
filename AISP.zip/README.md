# AISP-Backend

Supplier Portal Backend updated.

## Development setup

Install dependencies

```console
$ npm install
```

Copy the example env file and setup environment variables

```console
$ cp env/.example.env env/.env
```

Run unit test with jest

```console
$ npm run test
```

Start development server with nodemon (hot-reaload)

```console
$ npm run serve
```

Project should start at http://localhost:3001

## Database setup

[Sequelize v6](https://sequelize.org/docs/v6/) is being used to handle database operations. All the database needs are satisfied in `src/db` directory.

To setup an empty database after setting config options in previous step:

### Run migrations

To create tables in database

```console
$ npx sequelize-cli db:migrate
```

Other availavle options can be seen in the help menu:

```console
$ npx sequelize-cli --help
```

---

## Production Note

This project uses a lot of development dependencies which are not required in production. To install production dependencies only use:

```console
$ npm install --omit=dev
```

---

# Business Logic

The critical business logic handled in code

## Dynamic form

The supplier self request form can be dynamic?

We need two tables to store the supplier information

- `suppliers` (stores auth data and basic details of suppliers)
- 2 tables of dynamic form `form_submissions` & `form_submission_values` (stores form response)

Two ways a supplier can be added

- buyer invites supplier
  - all information goes to `suppliers` table, and creating a link between `clients` and `suppliers` table. as supplier table have data no problem with authentication of supplier ✅
- supplier self request

  1. dynamic form? then all data goes to `form_submissions` and `form_submission_values`.

  ❌ problems with this approach is -

  - how to show empanelment report tabular data as this comes from `suppliers` table?
  - how to create authentication data for that supplier?

  2. static form? data can be saved in `suppliers` table and all problems are solved ✅

---

## Action Notification

The `application_status_flow` contains how the notifications will be handled when status is changed.

The event handler configurations are for the current_status, i.e if `status:1` is being changed to `status:2` then the notifications will be handled according to the row `current_status:2`

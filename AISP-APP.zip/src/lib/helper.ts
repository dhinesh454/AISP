export function toCamelCase(str: string) {
  return str
    .replace(/_([a-z])/g, function (match, letter) {
      return letter.toUpperCase();
    })
    .replace(/\s+/g, "");
}
export function convertObject(input: any) {
  const output: any = {};
  for (const key in input) {
    if (typeof input[key] === "object" && input[key] !== null) {
      const innerObj = input[key];
      for (const innerKey in innerObj) {
        output[toCamelCase(innerKey)] = innerObj[innerKey];
      }
    } else {
      output[toCamelCase(key)] = input[key];
    }
  }

  return output;
}

export function lowercaseFirstLetter(str: any) {
  return str.charAt(0).toLowerCase() + str.slice(1);
}

export function addSpaceAfterCamelCase(label: string) {
  return label?.replace(/([a-z])([A-Z])/g, "$1 $2");
}

export function convertFormToObj(input: any) {
  if (input === undefined || input === null) {
    console.error("Input is undefined or null");
    return;
  }
  const output: any = {};
  for (let key in input) {
    if (input[key] !== null && typeof input[key] === 'object') {
      if (input[key]?.value !== undefined || input[key]?.label !== undefined) {
        output[key] = input[key].value;
      }
    }
    else if (input[key] !== undefined) {
      output[toCamelCase(key)] = input[key];
    }
  }
  return output;
}

export function formatDate(timestamp: any) {
  const date = new Date(timestamp);
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false, // Use 24-hour time format
  });
}

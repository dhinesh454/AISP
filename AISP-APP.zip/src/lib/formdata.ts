import { Placeholder } from "react-select/animated";
import { GET_REQUEST } from "./api";

const options = [
  { value: "Yes", label: "Yes" },
  { value: "No", label: "No" },
];
const companyOptions = [
  { value: "0-100", label: "0-100" },
  { value: "0-1000", label: "0-1000" },
  { value: "0-10000", label: "0-10000" },
  { value: "0-30", label: "0-30" },
];

const msmeOptions = [
  { value: "yes", label: "Yes" },
  { value: "no", label: "No" },
];

const countryOptions: any[] = [];
const ProductCatalogueOptions: any[] = [];
const productBusinessTypeOptions: any[] = [];
const type_FirmTypeOptions: any[] = [];
export const dropdownAPI = async () => {
  try {
    const res = await GET_REQUEST("/master/data/drop-downs?type=type_Country");
    const productCategory = await GET_REQUEST(
      "/master/data/drop-downs?type=type_ProductCatalogue"
    );
    const productBusinessType = await GET_REQUEST(
      "/master/data/drop-downs?type=type_BusinessType"
    );
    const type_FirmType = await GET_REQUEST(
      "/master/data/drop-downs?type=type_FirmType"
    );
    countryOptions.push(
      ...res?.data?.map((item: { rowKey: any; FIELD_DESCRIPTION: any }) => ({
        value: item.FIELD_DESCRIPTION,
        label: item.FIELD_DESCRIPTION,
      }))
    );
    ProductCatalogueOptions.push(
      ...productCategory?.data?.map(
        (item: { rowKey: any; FIELD_DESCRIPTION: any }) => ({
          value: item.FIELD_DESCRIPTION,
          label: item.FIELD_DESCRIPTION,
        })
      )
    );
    productBusinessTypeOptions.push(
      ...productBusinessType?.data?.map(
        (item: { rowKey: any; FIELD_DESCRIPTION: any }) => ({
          value: item.FIELD_DESCRIPTION,
          label: item.FIELD_DESCRIPTION,
        })
      )
    );
    type_FirmTypeOptions.push(
      ...type_FirmType?.data?.map(
        (item: { rowKey: any; FIELD_DESCRIPTION: any }) => ({
          value: item.FIELD_DESCRIPTION,
          label: item.FIELD_DESCRIPTION,
        })
      )
    );
  } catch (error) {
    console.error("Error fetching dropdown options:", error);
  }
};

(async () => {
  try {
    await dropdownAPI();
  } catch (error) {
    console.error("Error:", error);
  }
})();

export const empanelmentRequestJSON = [
  {
    label: "RequestId",
    fieldType: "text",
    placeholder: "Request Id",
    required: false,
    col: 6,
  },
  {
    label: "SupplierName",
    fieldType: "text",
    placeholder: "Name of Company",
    required: true,
    col: 6,
  },
  {
    label: "CompanyWebsite",
    fieldType: "text",
    placeholder: "Company Website",
    required: true,
    col: 6,
  },
  {
    label: "ContactPersonName",
    fieldType: "text",
    placeholder: "Name of Contact Person",
    required: true,
    col: 6,
  },
  {
    label: "SupplierEmail",
    fieldType: "email",
    placeholder: "Email ID",
    required: true,
    col: 6,
  },
  {
    label: "Country",
    fieldType: "select",
    placeholder: "Country",
    options: countryOptions,
    required: true,
    col: 6,
  },
  {
    label: "MobileNumber",
    fieldType: "number",
    placeholder: "Mobile Number",
    required: true,
    col: 3,
  },
  {
    label: "LandLineNumber",
    fieldType: "number",
    placeholder: "Land Line Number",
    required: false,
    col: 3,
  },
  {
    label: "ProductCategory",
    fieldType: "select",
    placeholder: "Product Category",
    options: ProductCatalogueOptions,
    required: false,
    col: 6,
  },
  {
    label: "TypeOfBusiness",
    fieldType: "select",
    options: productBusinessTypeOptions,
    placeholder: "Type of Business",
    required: false,
    col: 6,
  },
  {
    label: "TypeOfFirm",
    fieldType: "select",
    options: type_FirmTypeOptions,
    placeholder: "Type of firm",
    required: false,
    col: 6,
  },
  {
    label: "BasicInformation",
    fieldType: "text",
    placeholder: "Basic Information",
    required: false,
    col: 6,
  },
  {
    label: "AdditionalInfo",
    fieldType: "textarea",
    placeholder: "Additional Info",
    required: false,
    col: 6,
  },
];

export const supplierEmpanelmentForm = [
  {
    dropdownName: "Basic Information",
    dropdownValue: "BasicInformation",
    fields: [
      {
        label: "SupplierName",
        fieldType: "text",
        placeholder: "Name of Company",
        required: true,
        col: 6,
      },
      {
        label: "CompanyWebsite",
        fieldType: "text",
        placeholder: "Company Website",
        required: true,
        col: 6,
      },
      {
        label: "ContactPersonName",
        fieldType: "text",
        placeholder: "Name of Contact Person",
        required: true,
        col: 6,
      },
      {
        label: "SupplierEmail",
        fieldType: "email",
        placeholder: "Email ID",
        required: true,
        col: 6,
      },
      {
        label: "Country",
        fieldType: "select",
        placeholder: "Country",
        options: countryOptions,
        required: true,
        col: 6,
      },
      {
        label: "MobileNumber",
        fieldType: "number",
        placeholder: "Mobile Number",
        required: true,
        col: 3,
      },
      {
        label: "LandLineNumber",
        fieldType: "number",
        placeholder: "Land Line Number",
        required: false,
        col: 3,
      },
      {
        label: "ProductCategory",
        fieldType: "select",
        placeholder: "Product Category",
        options: ProductCatalogueOptions,
        required: false,
        col: 6,
      },
      {
        label: "TypeOfBusiness",
        fieldType: "select",
        options: productBusinessTypeOptions,
        placeholder: "Type of Business",
        required: false,
        col: 6,
      },
      {
        label: "TypeOfFirm",
        fieldType: "select",
        options: type_FirmTypeOptions,
        placeholder: "Type of firm",
        required: false,
        col: 6,
      },
      {
        label: "BasicInformation",
        fieldType: "text",
        placeholder: "Basic Information",
        required: false,
        col: 6,
      },
      {
        label: "AdditionalInfo",
        fieldType: "textarea",
        placeholder: "Additional Info",
        required: false,
        col: 6,
      },
    ],
  },
  {
    dropdownName: "Supplier Information",
    dropdownValue: "SupplierInformation",
    fields: [
      // {
      //   label: "NameOfContactPerson",
      //   placeholder: "Name of Contact Person",
      //   fieldType: "text",
      //   col: 6,
      //   required: false,
      // },
      // {
      //   label: "CompanyAddress",
      //   placeholder: "Company Address",
      //   fieldType: "text",
      //   col: 6,
      //   required: false,
      // },
      // {
      //   label: "EmailIfOfContactPerson",
      //   placeholder: "Email If Of Contact Person",
      //   fieldType: "email",
      //   col: 6,
      //   required: false,
      // },
      {
        label: "StreetAddress",
        placeholder: "Street Address",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "MobileNumber",
        placeholder: "Mobile Number",
        fieldType: "Number",
        col: 6,
        required: false,
      },
      {
        label: "IsYourFirmMSME",
        placeholder: "Is Your Firm MSME",
        fieldType: "radio",
        col: 6,
        required: false,
      },
      {
        label: "GeographicServiceArea",
        fieldType: "select",
        placeholder: "Geographic Service Area",
        required: false,
        col: 6,
        options,
      },
      {
        label: "TypeOfBusiness",
        fieldType: "select",
        options: productBusinessTypeOptions,
        placeholder: "Type of Business",
        required: false,
        col: 6,
      },
      {
        label: "GSTIN",
        placeholder: "GSTIN",
        fieldType: "text",
        required: false,
        col: 4,
      },
      {
        label: "PAN",
        placeholder: "PAN",
        fieldType: "text",
        required: false,
        col: 2,
      },
      {
        label: "TypeOfItemsInterestedForSupply",
        fieldType: "select",
        options: productBusinessTypeOptions,
        placeholder: "Type of Items Interested for Supply/Service",
        required: false,
        col: 6,
      },
      {
        label: "EstablishedYear",
        fieldType: "text",
        placeholder: "Established Year",
        required: false,
        col: 6,
      },
      {
        label: "DesignationOfContactPerson",
        placeholder: "Designation of Contact Person",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "Country",
        placeholder: "Country",
        fieldType: "select",
        options: countryOptions,
        col: 3,
        required: false,
      },
      {
        label: "Pin",
        placeholder: "Pin",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "Email",
        placeholder: "Email",
        fieldType: "email",
        col: 6,
        required: false,
      },
      {
        label: "State",
        placeholder: "State",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "City",
        placeholder: "City",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "Linkedin",
        placeholder: "Linkedin",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "STDCodeWithPhoneNo",
        placeholder: "STD Code With Phone No",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "Twitter",
        placeholder: "Twitter",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "FaxNumber",
        placeholder: "Fax Number",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "WebsiteAddress",
        placeholder: "Website Address",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "Website",
        placeholder: "Website",
        fieldType: "text",
        col: 6,
        required: false,
      },
    ],
  },
  {
    dropdownName: "Bank Information",
    dropdownValue: "BankInformation",
    fields: [
      {
        label: "BeneficiaryName",
        placeholder: "Beneficiary Name",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "InternationalBankAccountNumber",
        placeholder: "International Bank Account Number",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "BankAccountNumber",
        placeholder: "Bank Account Number",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "IFSCCode",
        placeholder: "IFSC Code",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "Currency",
        placeholder: "A/C Currency",
        fieldType: "select",
        col: 3,
        required: false,
        options,
      },
      {
        label: "BankAddress",
        placeholder: "Bank Address",
        fieldType: "text",
        col: 6,
        required: false,
      },
    ],
  },
  {
    dropdownName: "Additional Information",
    dropdownValue: "AdditionalInformation",
    fields: [
      {
        label: "Insured",
        placeholder: "Insured",
        fieldType: "select",
        col: 2,
        required: false,
        options,
      },
      {
        label: "InsuranceValidity",
        placeholder: "Insurance Validity",
        fieldType: "text",
        col: 4,
        required: false,
      },
      {
        label: "Bonded",
        placeholder: "Bonded",
        fieldType: "select",
        col: 2,
        required: false,
        options,
      },
      {
        label: "BondDetails",
        placeholder: "Bond Details",
        fieldType: "text",
        col: 4,
        required: false,
      },
      {
        label: "Licensed",
        placeholder: "Licensed",
        fieldType: "select",
        col: 3,
        required: false,
        options,
      },
      {
        label: "LicensedNumber",
        placeholder: "Licensed Number",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "Turnover",
        placeholder: "Turnover",
        fieldType: "text",
        col: 3,
        required: false,
      },
      {
        label: "TurnoverCurrency",
        placeholder: "Turnover Currency",
        fieldType: "select",
        col: 3,
        required: false,
        options,
      },
      {
        label: "HaveYouPreviouslyDoneBusinessWithKindOfOurBusiness",
        placeholder:
          "Have You Previously Done Business With Kind Of Our Business",
        fieldType: "radio",
        col: 6,
        required: false,
      },
      {
        label: "Since",
        placeholder: "Since",
        fieldType: "text",
        col: 6,
        required: false,
      },
      {
        label: "OverallRemarks",
        placeholder: "Overall Remarks",
        fieldType: "textarea",
        col: 12,
        required: false,
      },
    ],
  },
  {
    dropdownName: "Attachments",
    dropdownValue: "Attachments",
    fields: [
      {
        label: "PanCard",
        placeholder: "Pan Card",
        fieldType: "file",
        required: true,
      },
      {
        label: "AadharCard",
        placeholder: "Aadhar Card",
        fieldType: "file",
        required: true,
      },
      {
        label: "MsmeCertificate",
        placeholder: "MSME Certificate",
        fieldType: "file",
        required: true,
      },
      {
        label: "GSTINCertificate",
        placeholder: "GSTIN Certificate",
        fieldType: "file",
        required: true,
      },
      {
        label: "Others",
        placeholder: "Others",
        fieldType: "file",
        required: true,
      },
    ],
  },
  {
    dropdownName: "Questionnaire",
    dropdownValue: "Questionnaire",
    fields: [
      {
        label: "1",
        fieldType: "Questionnaire",
        question: "What is your company size?",
        subfieldType: "select",
        options: companyOptions,
      },
      {
        label: "2",
        fieldType: "Questionnaire",
        question: "Are you registered as MSME?",
        subfieldType: "select",
        options: msmeOptions,
      },
    ],
  },
];

export const selfRegistrationJSON = [
  {
    label: "SupplierName",
    fieldType: "text",
    placeholder: "Name of Company",
    required: true,
    col: 12,
  },
  {
    label: "CompanyWebsite",
    fieldType: "text",
    placeholder: "Company Website",
    required: true,
    col: 12,
  },
  {
    label: "ContactPersonName",
    fieldType: "text",
    placeholder: "Name of Contact Person",
    required: true,
    col: 12,
  },
  {
    label: "SupplierEmail",
    fieldType: "email",
    placeholder: "Email ID",
    required: true,
    col: 12,
  },
  {
    label: "Country",
    fieldType: "select",
    placeholder: "Country",
    options: countryOptions,
    required: true,
    col: 12,
  },
  {
    label: "MobileNumber",
    fieldType: "number",
    placeholder: "Mobile Number",
    required: true,
    col: 6,
  },
  {
    label: "LandLineNumber",
    fieldType: "number",
    placeholder: "Land Line Number",
    required: false,
    col: 6,
  },
  {
    label: "ProductCategory",
    fieldType: "select",
    placeholder: "Product Category",
    options: ProductCatalogueOptions,
    required: false,
    col: 12,
  },
  {
    label: "TypeOfBusiness",
    fieldType: "select",
    options: productBusinessTypeOptions,
    placeholder: "Type of Business",
    required: false,
    col: 12,
  },
  {
    label: "TypeOfFirm",
    fieldType: "select",
    options: type_FirmTypeOptions,
    placeholder: "Type of firm",
    required: false,
    col: 12,
  },
  {
    label: "BasicInformation",
    fieldType: "text",
    placeholder: "Basic Information",
    required: false,
    col: 12,
  }
];

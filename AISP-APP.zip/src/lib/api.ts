import axios from "axios";
import { getCookie } from "cookies-next";

export const GET_REQUEST = async (entity: any) => {
  try {
    const accessToken = getCookie("airditToken");
    const config = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const response = await axios.get(`https://dev-aisp-api.azurewebsites.net/api/${entity}`, config);
    return response?.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response) {
        console.error("Server responded with error status:", error.response.status);
        console.error("Error message:", error.response.data.message);
        return error.response.data;
      } else if (error.request) {
        console.error("No response received from server");
      } else {
        console.error("Error:", error.message);
      }
    } else {
      console.error("Non-Axios error occurred:", error);
    }
    throw error;
  }
};

export const POST_REQUEST = async (entity: any, data?: any) => {
  try {
    const accessToken = getCookie("airditToken");
    const config = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const response = await axios.post(`https://dev-aisp-api.azurewebsites.net/api/${entity}`, data, config);
    return response?.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response) {
        console.error("Server responded with error status:", error.response.status);
        console.error("Error message:", error.response.data.message);
        return error.response.data;
      } else if (error.request) {
        console.error("No response received from server");
      } else {
        console.error("Error:", error.message);
      }
    } else {
      console.error("Non-Axios error occurred:", error);
    }
    throw error;
  }
};

export const PATCH_REQUEST = async (entity: any, data?: any) => {
  try {
    const accessToken = getCookie("airditToken");
    const config = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const response = await axios.patch(`https://dev-aisp-api.azurewebsites.net/api/${entity}`, data, config);
    return response?.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response) {
        console.error("Server responded with error status:", error.response.status);
        console.error("Error message:", error.response.data.message);
        return error.response.data;
      } else if (error.request) {
        console.error("No response received from server");
      } else {
        console.error("Error:", error.message);
      }
    } else {
      console.error("Non-Axios error occurred:", error);
    }
    throw error;
  }
};

export const DELETE_REQUEST = async (entity: any) => {
  try {
    const accessToken = getCookie("airditToken");
    const config = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const response = await axios.delete(`https://dev-aisp-api.azurewebsites.net/api/${entity}`, config);
    return response?.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response) {
        console.error("Server responded with error status:", error.response.status);
        console.error("Error message:", error.response.data.message);
        return error.response.data;
      } else if (error.request) {
        console.error("No response received from server");
      } else {
        console.error("Error:", error.message);
      }
    } else {
      console.error("Non-Axios error occurred:", error);
    }
    throw error;
  }
};

export const PUT_REQUEST = async (entity: any, data?: any) => {
  try {
    const accessToken = getCookie("airditToken");
    const config = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const response = await axios.put(`https://dev-aisp-api.azurewebsites.net/api/${entity}`, data, config);
    return response?.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response) {
        console.error("Server responded with error status:", error.response.status);
        console.error("Error message:", error.response.data.message);
        return error.response.data;
      } else if (error.request) {
        console.error("No response received from server");
      } else {
        console.error("Error:", error.message);
      }
    } else {
      console.error("Non-Axios error occurred:", error);
    }
    throw error;
  }
};
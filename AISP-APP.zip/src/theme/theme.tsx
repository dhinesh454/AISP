import { PaletteMode } from "@mui/material";
import { amber, deepOrange, grey } from "@mui/material/colors";

const theme = {
  typography: {
    fontFamily: ["Poppins", "sans-serif"].join(","),
  },
  palette: {
    mode: "light",
    primary: {
      main: "#8C57FF",
    },
    secondary: {
      main: "#FFFFF",
    },
  },
  components: {
    MuiFormLabel: {
      styleOverrides: {
        asterisk: { color: "red" },
      },
    },
  },
};

export const getDesignTokens = (mode: PaletteMode) => ({
  typography: {
    fontFamily: ["Poppins", "sans-serif"].join(","),
  },
  palette: {
    mode,
    ...(mode === "light"
      ? {
          primary: {
            main: "#8C57FF",
          },
          secondary: {
            main: "#dcd2f0",
          },
          divider: "rgba(0, 0, 0, 0.12)",
          background: {
            default:"#F4F5FA",
            // paper: "rgb(40, 36, 61)",
          },
          text: {
            // primary: '#FFFFF',
            // secondary: '#8C57FF',
            // disabled:'#FFFFF'
          },
        }
      : {
        primary: {
            main: "#8C57FF",
          },
          secondary: {
            main: "#0000",
          },
        divider: "rgba(255, 255, 255, 0.12)",
        background: {
          default:"#28243D",
          // paper: "rgb(40, 36, 61)",
        },
        // text: {
        //   primary: '#FFFFF',
        //   secondary: 'rgba(255, 255, 255, 0.7)',
        //   disabled:'rgba(255, 255, 255, 0.5)'
        // },
        }),
  },
  components: {
    MuiFormLabel: {
      styleOverrides: {
        asterisk: { color: "red" },
      },
    },
    MuiDataGrid: {
      styleOverrides: {
          root: {
              border: 'none'
          }
      },
  },
  },
});

export default theme;

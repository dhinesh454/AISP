"use client";
import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import { DataGridPremium, useGridApiRef } from "@mui/x-data-grid-premium";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import GroupsOutlinedIcon from "@mui/icons-material/GroupsOutlined";
import { styled } from "@mui/material/styles";
import { Button, TextField, Typography } from "@mui/material";
import { BeatLoader } from "react-spinners";
import { GET_REQUEST, PATCH_REQUEST, POST_REQUEST } from "@/lib/api";
import { convertFormToObj } from "@/lib/helper";
import { CustomDataFound } from "./NoDataFound";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";

export default function GroupRoleGrid({
  groupData,
  handleDialogClose,
  showRoles,
  partitionKey,
  clearPartitionKey,
  action = true,
  fullName,
  setFullName,
}: {
  groupData: any;
  handleDialogClose: () => void;
  showRoles: () => void;
  partitionKey?: any;
  clearPartitionKey: () => void;
  action?: boolean;
  fullName: string;
  setFullName: (value: string) => void;
}) {
  const { mode } = useThemeContext();
  const [gridData, setGridData] = useState<any[]>([]);
  const [isDisable, setIsDisable] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const apiRef = useGridApiRef();
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    if (partitionKey) {
      fetchGroupRole();
    } else if (groupData) {
      fetchGroupRole();
    } else {
      setFullName("");
      setGridData([]);
      setLoading(false);
    }
  }, [partitionKey, groupData]);

  async function fetchGroupRole() {
    try {
      setLoading(true);
      setIsDisable(true);
      if (partitionKey) {
        const response = await GET_REQUEST(`auth/getgroup/${partitionKey}`);
        let savedData: any = [];
        if (response && response.data) {
          const responseData = response.data;
          setFullName(responseData?.role_name);
          savedData = responseData?.roles?.map((row: any, index: number) => ({
            ...row,
            id: index,
          }));
        }
        let addedData = [];
        if (groupData) {
          addedData = groupData?.map((row: any, index: number) => ({
            ...row,
            id: savedData.length + index,
          }));
        }
        const combinedData = [...savedData, ...addedData];
        setGridData(combinedData);
      } else {
        const addedData = groupData?.map((row: any, index: number) => ({
          ...row,
          id: index,
        }));
        setGridData(addedData);
      }
      setLoading(false);
      setIsDisable(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
      setIsDisable(false);
    }
  }
  const handleRowDelete = (idToDelete: number) => {
    setGridData((prevData) => prevData.filter((row) => row.id !== idToDelete));
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors: any = {};
    if (fullName === "") {
      newErrors.FullName = "This field is required";
      isValid = false;
    } else {
      newErrors.FullName = "";
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    try {
      e.preventDefault();
      setIsDisable(true);
      const isValid = validateForm();
      if (!isValid) {
        setIsDisable(false);
        return;
      }
      setIsDisable(false);
      const roleData = {
        name: fullName,
        roleIds: gridData.map((gdata: any) => gdata.rowKey),
      };
      if (partitionKey) {
        const response = await PATCH_REQUEST(
          `auth/updategroup/${partitionKey}`,
          roleData
        );
        if (response?.success) {
          setIsDisable(false);
          showAlert(response.message, response.success);
        } else {
          setIsDisable(false);
          showAlert(response.message, response.success);
        }
      } else {
        const response = await POST_REQUEST("auth/creategroup", roleData);
        if (response?.success) {
          setIsDisable(false);
          showAlert(response.message, response.success);
        } else {
          alert(response?.message);
          setIsDisable(false);
          showAlert(response.message, response.success);
        }
      }
      setTimeout(() => {
        handleDialogClose(), setGridData([]), clearPartitionKey();
      }, 1500);
    } catch (error) {
      console.log(error);
      setIsDisable(false);
    }
  };

  const columns = [
    { field: "rowKey", headerName: "Roles", flex: 1 },
    {
      field: "role_name",
      headerName: "Role Name",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="py-2 flex items-center">
          <GroupsOutlinedIcon className="mr-2" fontSize="medium" />
          <span>{params.value}</span>
        </Box>
      ),
    },
    {
      field: "Action",
      headerName: "Action",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="py-2 flex items-center">
          <Button
            color="inherit"
            variant="text"
            sx={{ fontWeight: 500, fontSize: "13px" }}
            disabled={isDisable || !action}
            onClick={() => handleRowDelete(params.row.id)}
          >
            <DeleteOutlineIcon
              fontSize="small"
              style={{ marginRight: "5px" }}
            />
          </Button>
        </Box>
      ),
    },
  ];

  return (
    <Box>
      <Typography
        variant="h6"
        className={`text-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
        }`}
      >
        {partitionKey ? `Update ` : `Create `} Group Role
      </Typography>
      <Box
        sx={{
          m: 2,
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          padding: "0 50px",
        }}
      >
        <TextField
          required
          id="FullName"
          label="Group Role Name"
          value={fullName}
          fullWidth
          type="text"
          disabled={!action}
          InputLabelProps={{ shrink: true }}
          onChange={(e) => setFullName(e.target.value)}
          error={!!errors?.FullName}
          helperText={errors?.FullName}
          sx={{ flex: 4, mr: 1 }}
        />
        <Button
          variant="contained"
          color="primary"
          onClick={showRoles}
          sx={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: "40px",
          }}
          disabled={!action}
        >
          <span className="normal-case">Choose Role</span>
          <GroupsOutlinedIcon className="ml-2" fontSize="small" />
        </Button>
      </Box>

      <DataGridPremium
        rows={gridData}
        columns={columns}
        apiRef={apiRef}
        loading={loading}
        disableRowSelectionOnClick
        slots={{
          noRowsOverlay: CustomDataFound,
        }}
        sx={{
          "& .MuiDataGrid-overlayWrapper": {
            minHeight: "200px",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: mode === "dark" ? "#424242" : "#FFFFF",
          },
          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: "600",
          },
        }}
      />
      <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
        {action && (
          <Button
            className={`rounded-md ${
              isDisable && "cursor-not-allowed opacity-[0.6]"
            }`}
            sx={{ ml: 2 }}
            variant="contained"
            disabled={isDisable}
            onClick={handleFormSubmit}
          >
            <span className="normal-case">
              {isDisable ? (
                <BeatLoader color="#FFFFFF" size={10} />
              ) : partitionKey ? (
                `Update`
              ) : (
                `Submit`
              )}
            </span>
          </Button>
        )}
        <Button
          variant="outlined"
          color="primary"
          className="rounded-md"
          onClick={() => {
            handleDialogClose(), setGridData([]), clearPartitionKey();
          }}
          sx={{ ml: 2 }}
        >
          <span className="normal-case">Cancel</span>
        </Button>
      </Box>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </Box>
  );
}

import { Box } from "@mui/material";
import { useState } from "react";

const CustomColum = ({ reactTable }: { reactTable: any }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <Box className="relative w-[100%] flex justify-end">
      <button
        className="flex items-center  h-10 bg-[#FFFF] text-[#999999]  px-4 py-2 ml-2 rounded-md border-solid border-2 border-[#b5b4b4]"
        onClick={toggleDropdown}
      >
        Column
      </button>
      {isDropdownOpen && (
        <Box className="absolute top-full left-0 w-full bg-white border border-gray-300 mt-1 shadow-2xl rounded-md z-10">
          <label className="block p-2">
            <input
              {...{
                type: "checkbox",
                checked: reactTable.getIsAllColumnsVisible(),
                onChange: reactTable.getToggleAllColumnsVisibilityHandler(),
              }}
            />
            <span className="text-[14px] font-medium ml-4">Select All</span>
          </label>
          <hr />
          {reactTable.getAllLeafColumns().map((column: any) => {
            // if (column.id === "Select" || column.id === "Action") {
            //   return null;
            // }
            return (
              <Box key={column.id} className="p-2">
                <label>
                  <input
                    type="checkbox"
                    checked={column.getIsVisible()}
                    onChange={column.getToggleVisibilityHandler()}
                  />
                  <span className="text-[14px] font-medium ml-4 text-wrap">
                    {column.id}
                  </span>
                </label>
              </Box>
            );
          })}
        </Box>
      )}
    </Box>
  );
};

export default CustomColum;

"use client";
import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import {
  Button,
  Checkbox,
  FormControlLabel,
  FormGroup,
  TextField,
  Typography,
} from "@mui/material";
import { BeatLoader } from "react-spinners";
import { GET_REQUEST, PATCH_REQUEST, POST_REQUEST } from "@/lib/api";
import { CustomDataFound } from "./NoDataFound";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { Padding } from "@mui/icons-material";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";

export default function RolePermissionsGrid({
  handleDialogClose,
  partitionKey,
  clearPartitionKey,
  action = true,
}: {
  handleDialogClose: () => void;
  partitionKey?: any;
  clearPartitionKey: () => void;
  action?: boolean;
}) {
  const { mode } = useThemeContext();
  const [data, setData] = useState<any>({});
  const [checkboxList, setCheckboxList] = useState<any>({});
  const [checkbox, setCheckbox] = useState<any>({});
  const [isDisable, setIsDisable] = useState<boolean>(false);
  const [roleName, setRoleName] = useState<string>("");
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    fetchRolePermissions();
  }, [partitionKey]);

  async function fetchRolePermissions() {
    try {
      setIsDisable(true);
      const res = await GET_REQUEST("auth/getpermissions");
      if (res.success) {
        setData(res.data);
        initializeCheckboxState(res.data);
      }
      if (partitionKey) {
        const response = await GET_REQUEST(`auth/getrole/${partitionKey}`);
        if (response && response.data) {
          const responseData = response.data;
          setRoleName(responseData?.role_name);
          setCheckboxFromResponse(responseData.permissions);
        }
      }
      setIsDisable(false);
    } catch (error) {
      console.log(error);
      setIsDisable(false);
    }
  }

  const initializeCheckboxState = (data: any) => {
    const initialCheckboxState = Object.keys(data).reduce(
      (acc: any, categoryKey) => {
        const category = data[categoryKey];
        acc[categoryKey] = Object.keys(category).reduce(
          (innerAcc: any, permKey) => {
            innerAcc[permKey] = {};
            return innerAcc;
          },
          {}
        );
        return acc;
      },
      {}
    );
    setCheckboxList(initialCheckboxState);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) {
      setIsDisable(false);
      return;
    }
    const selectedPermissions = Object.keys(data).reduce(
      (acc: any, categoryKey) => {
        const category = data[categoryKey];
        acc[categoryKey] = Object.keys(category).reduce(
          (innerAcc: any, permKey) => {
            if (permKey !== "description") {
              innerAcc[permKey] = ["Create", "Edit", "Read", "Delete"].reduce(
                (actionAcc: any, actionKey) => {
                  actionAcc[actionKey] = checkbox[categoryKey]?.[permKey]?.[
                    actionKey
                  ]
                    ? "Active"
                    : "Inactive";
                  return actionAcc;
                },
                {}
              );
            }
            return innerAcc;
          },
          {}
        );
        return acc;
      },
      {}
    );

    const payload = {
      name: roleName,
      permissions: selectedPermissions,
    };
    try {
      setIsDisable(true);
      if (partitionKey) {
        const response = await PATCH_REQUEST(
          `auth/updaterole/${partitionKey}`,
          payload
        );
        if (response?.success) {
          showAlert(response.message, response.success);
        } else {
          showAlert(response.message, response.success);
        }
      } else {
        const response = await POST_REQUEST("auth/createrole", payload);
        if (response?.success) {
          showAlert(response.message, response.success);
        } else {
          showAlert(response.message, response.success);
        }
      }
      setTimeout(() => {
        handleDialogClose(),
          setCheckbox({}),
          setRoleName(""),
          clearPartitionKey();
      }, 1500);
    } catch (error) {
      console.log(error);
    } finally {
      setIsDisable(false);
    }
  };

  const handleCheckboxChange = (
    categoryKey: string,
    permKey: string,
    actionKey: string
  ) => {
    const updatedCheckbox = { ...checkboxList, ...checkbox };
    updatedCheckbox[categoryKey][permKey][actionKey] =
      !updatedCheckbox[categoryKey][permKey][actionKey];
    setCheckbox(updatedCheckbox);
  };

  const renderPermissions = (permissions: any, categoryKey: string) => {
    return Object.keys(permissions).map((permKey) => {
      const perm = permissions[permKey];
      return permKey !== "description" ? (
        <Box
          key={permKey}
          sx={{
            display: "flex",
            alignItems: "center",
            mb: 2,
            borderBottom: "1px solid",
            borderBottomColor: "#D5D1EA",
          }}
        >
          <Typography variant="body2" sx={{ flex: 1 }}>
            {perm.description}
          </Typography>
          <FormGroup row>
            {["Create", "Edit", "Read", "Delete"].map((actionKey) => {
              return (
                <FormControlLabel
                  key={actionKey}
                  sx={{ paddingX: "20px" }}
                  control={
                    <Checkbox
                      disabled={!action}
                      checked={!!checkbox[categoryKey]?.[permKey]?.[actionKey]}
                      onChange={() =>
                        handleCheckboxChange(categoryKey, permKey, actionKey)
                      }
                    />
                  }
                  label=""
                />
              );
            })}
          </FormGroup>
        </Box>
      ) : null;
    });
  };

  const setCheckboxFromResponse = (permissions: any) => {
    const updatedCheckbox = { ...checkboxList };
    Object.keys(permissions).forEach((categoryKey) => {
      const category = permissions[categoryKey];
      Object.keys(category).forEach((permKey) => {
        const perm = category[permKey];
        Object.keys(perm).forEach((actionKey) => {
          updatedCheckbox[categoryKey] = updatedCheckbox[categoryKey] || {};
          updatedCheckbox[categoryKey][permKey] =
            updatedCheckbox[categoryKey][permKey] || {};
          updatedCheckbox[categoryKey][permKey][actionKey] =
            perm[actionKey] === "Active";
        });
      });
    });
    setCheckbox(updatedCheckbox);
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors: any = {};
    if (roleName === "") {
      newErrors.RoleName = "This field is required";
      isValid = false;
    } else {
      newErrors.RoleName = "";
    }
    setErrors(newErrors);
    return isValid;
  };
  return (
    <Box>
      <Typography
        variant="h6"
        className={`text-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
        }`}
      >
        {partitionKey ? `Update ` : `Add `} Role
      </Typography>
      <Typography
        variant="body1"
        className={`text-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
        }`}
      >
        Set Role Permissions
      </Typography>
      {data ? (
        <Box>
          <Box
            sx={{
              m: 2,
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              padding: "0 50px",
            }}
          >
            <TextField
              required
              id="RoleName"
              label="Role Name"
              value={roleName}
              fullWidth
              type="text"
              disabled={!action}
              InputLabelProps={{ shrink: true }}
              onChange={(e) => setRoleName(e.target.value)}
              error={!!errors?.RoleName}
              helperText={errors?.RoleName}
              sx={{ flex: 4, mr: 1 }}
            />
          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              mb: 2,
              justifyContent: "flex-end",
            }}
          >
            {["Create", "Edit", "Read", "Delete"].map((actionKey) => (
              <Box key={actionKey}>
                <Typography
                  variant="body2"
                  className={`font-semibold mr-[52px]  ${
                    mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
                  }`}
                >
                  {actionKey}
                </Typography>
              </Box>
            ))}
          </Box>
          <Box sx={{ overflowY: "auto", maxHeight: "40vh" }}>
            {Object.keys(data).map((categoryKey) => {
              const category = data[categoryKey];
              return (
                <Box key={categoryKey} sx={{ mb: 2 }}>
                  <Typography
                    variant="body1"
                    className={`font-semibold mb-2 ${
                      mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
                    }`}
                  >
                    {categoryKey}
                  </Typography>
                  {renderPermissions(category, categoryKey)}
                </Box>
              );
            })}
          </Box>
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            {action && (
              <Button
                className={`rounded-md ${
                  isDisable && "cursor-not-allowed opacity-[0.6]"
                }`}
                sx={{ ml: 2 }}
                variant="contained"
                disabled={isDisable}
                onClick={handleFormSubmit}
              >
                <span className="normal-case">
                  {isDisable ? (
                    <BeatLoader color="#FFFFFF" size={10} />
                  ) : partitionKey ? (
                    `Update`
                  ) : (
                    `Submit`
                  )}
                </span>
              </Button>
            )}
            <Button
              variant="outlined"
              color="primary"
              className="rounded-md"
              onClick={() => {
                handleDialogClose(),
                  setCheckbox({}),
                  setRoleName(""),
                  clearPartitionKey();
              }}
              sx={{ ml: 2 }}
            >
              <span className="normal-case">Cancel</span>
            </Button>
          </Box>
        </Box>
      ) : (
        <Box sx={{ display: "flex", justifyContent: "center" }}>
          {CustomDataFound()}
        </Box>
      )}
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </Box>
  );
}

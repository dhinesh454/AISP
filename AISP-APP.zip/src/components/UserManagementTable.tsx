"use client";
import React, { useState, HTMLProps, useEffect, useRef } from "react";
import Select from "react-select";
import { CiExport } from "react-icons/ci";
import {
  Column,
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  Table,
  PaginationState,
  useReactTable,
} from "@tanstack/react-table";
import CreateUserModal from "./CreateUser";
import {
  MdOutlineKeyboardArrowLeft,
  MdOutlineKeyboardArrowRight,
} from "react-icons/md";
import { mkConfig, generateCsv, download } from "export-to-csv";
import { GET_REQUEST } from "@/lib/api";
import { useRouter } from "next/navigation";
import { deleteCookie } from "cookies-next";
import { Box } from "@mui/material";

const UserManagementTable = ({ columns, endPoint, tableName, fetchData }: any) => {
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const [isCreateUserModalOpen, setIsCreateUserModalOpen] = useState(false);
  const [data, setData] = useState<any>([]);
  const [nextToken, setNextToken] = useState("");
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const [rowSelection, setRowSelection] = useState({});
  const [dateValue, setDateValue] = useState<any>({
    startDate: null,
    endDate: null,
  });
  const [status, setStatus] = useState<any>(null);
  const [userCategory, setUserCategory] = useState(null);

  // Options for the Select components
  const userCategoryOptions = [
    { value: "admin", label: "Admin" },
    { value: "user", label: "User" },
    // Add more options as needed
  ];

  const statusOptions = [
    { value: "All", label: "All" },
    { value: "Active", label: "Active" },
    { value: "Inactive", label: "Inactive" },
    // Add more options as needed
  ];

  const csvConfig = mkConfig({
    fieldSeparator: ",",
    filename: tableName,
    decimalSeparator: ".",
    useKeysAsHeaders: true,
  });

  const exportExcel = (rows: any) => {
    const rowData = rows.map((row: any) => row.original);
    const csv = generateCsv(csvConfig)(rowData);
    download(csvConfig)(csv);
  };

  const openCreateUserModal = () => {
    setIsCreateUserModalOpen(true);
  };

  const closeCreateUserModal = () => {
    setIsCreateUserModalOpen(false);
  };

  function IndeterminateCheckbox({
    indeterminate,
    className = "",
    onChange, // Add onChange prop
    ...rest
  }: {
    indeterminate?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  } & HTMLProps<HTMLInputElement>) {
    const ref = useRef<HTMLInputElement>(null!);

    useEffect(() => {
      if (typeof indeterminate === "boolean") {
        ref.current.indeterminate = !rest.checked && indeterminate;
      }
    }, [ref, indeterminate]);

    return (
      <input
        type="checkbox"
        ref={ref}
        className={className + " cursor-pointer"}
        onChange={onChange} // Pass onChange event here
        {...rest}
      />
    );
  }
 
  async function handleDataFetch(filterType: string, inputValue: any) {
    try {
      let apiEndpoint = endPoint;
      let queryParams = `pageSize=${pagination.pageSize}`;
  
      if (filterType === "status") {
        const filterStatus: any = status?.value;
        if (filterStatus !== "All") {
          queryParams += `&status=${filterStatus}`;
        }
      } else if (filterType === "searchGlobal") {
        if (inputValue !== "") {
          queryParams += `&searchGlobal=${inputValue}`;
        }
      } else if (filterType === "searchUser") {
        if (inputValue !== "") {
          queryParams += `&searchUser=${inputValue}`;
        }
      }
      const res = await GET_REQUEST(`${apiEndpoint}?${queryParams}`);
      if (res?.success) {
        setNextToken(res?.nextToken);
        setData(res?.data);
      } else {
        if (res?.message === "Unauthorized") {
          deleteCookie("airditToken");
          router.refresh();
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  
  async function handleStatusFilter() {
    await handleDataFetch("status", status?.value);
  }
  
  async function handleFilter(inputValue: any) {
    await handleDataFetch("searchGlobal", inputValue);
  }
  
  async function handleFilterUser(inputValue: any) {
    await handleDataFetch("searchUser", inputValue);
  }
  
  async function apiCall() {
    await handleDataFetch("api", null);
  }

  useEffect(() => {
    if (isCreateUserModalOpen) {
      document.body.classList.add("modal-open");
    } else {
      document.body.classList.remove("modal-open");
    }
  }, [isCreateUserModalOpen]);

  const reactTable = useReactTable({
    data,
    columns,
    state: {
      pagination,
      rowSelection,
    },
    manualPagination: true,
    enableRowSelection: true,
    getCoreRowModel: getCoreRowModel(),
    onRowSelectionChange: setRowSelection,
    getFilteredRowModel: getFilteredRowModel(), //client side filtering
  });
  useEffect(() => {
    console.log("123",fetchData)
    apiCall();
  }, [fetchData]);

  return (
    <Box>
      {tableName === "User" && (
        <Box className="flex items-center space-x-4">
          <Box className="relative border border-[#CFCFCF] rounded-lg py-1 w-[20%] ">
            <label className="absolute left-3 -top-[.5px] text-[12px] z-10 text-[#828282] font-light">
              User Category
            </label>
            <Box className="w-full">
              <Select
                name="User Category"
                options={userCategoryOptions}
                value={userCategory}
                onChange={(selectedOption: any) =>
                  setUserCategory(selectedOption)
                }
                styles={dropDownStyle}
              />
            </Box>
          </Box>
          <Box className="relative border border-[#CFCFCF] rounded-lg py-1 w-[20%]">
            <label className="absolute left-3 -top-[.5px] text-[12px] z-10 text-[#828282] font-light">
              Status
            </label>
            <Box className="w-full">
              <Select
                name="Status"
                options={statusOptions}
                value={status}
                onChange={(selectedOption: any) => setStatus(selectedOption)}
                styles={dropDownStyle}
              />
            </Box>
          </Box>
          <button
            type="button"
            className="bg-[#8C57FF] text-white px-4 py-2 ml-2 rounded-md"
            onClick={handleStatusFilter}
          >
            Show
          </button>
        </Box>
      )}
      <Box className="flex justify-between ">
        <button
          type="button"
          className="flex items-center sm:w-[40%] md:w-[20%] lg:w-[20%] xl:w-[10%] h-10 bg-[#FFFF] text-[#999999] mt-6 px-4 py-2 ml-2 rounded-md border-solid border-2 border-[#b5b4b4]"
          onClick={() => exportExcel(reactTable.getFilteredRowModel().rows)}
        >
          <CiExport className="mr-2 text-[#6c6c6c]" /> Export
        </button>

        <Box className="my-4 flex justify-end">
          <input
            type="text"
            className="px-4 py-2 border border-[#CFCFCF] outline-none rounded-md pl-3"
            placeholder="Search User"
          />
          {tableName === "User" && (
            <Box>
              <button
                type="button"
                className="bg-[#8C57FF] text-white px-4 py-2 ml-2 rounded-md"
                onClick={openCreateUserModal}
              >
                Add New User
              </button>
              {isCreateUserModalOpen && (
                <Box className="fixed inset-0 z-50 flex justify-center items-center bg-[#141414]/[.30] bg-opacity-30">
                  <Box className="w-[19%] py-2">
                    <CreateUserModal
                      isOpen={isCreateUserModalOpen}
                      onClose={closeCreateUserModal}
                    />
                  </Box>
                </Box>
              )}
            </Box>
          )}
          {tableName === "RoleAssignment" && (
            <Box>
              <button
                type="button"
                className="bg-[#8C57FF] text-white px-4 py-2 ml-2 rounded-md"
                // onClick={openModal}
              >
                Assignment
              </button>
            </Box>
          )}
        </Box>
      </Box>
      {data?.length > 0 ? (
        <>
          <table className="text-center mt-4 w-full border border-[#0000001F]">
            {reactTable.getHeaderGroups().map((headerGroup) => (
              <tr
                key={headerGroup?.id}
                className="bg-[#d6dce6] text-[#00185A] text-[14px] font-thin py-4"
              >
                {headerGroup.headers.map((header) => (
                  <th
                    key={header?.id}
                    className={`w-[${header.getSize()}] text-center py-4  border border-[#0000001F]`}
                  >
                    {
                      // Check if it's the checkbox column
                      header.id === "Select" ? (
                        <IndeterminateCheckbox
                          {...{
                            checked: reactTable.getIsAllRowsSelected(),
                            indeterminate: reactTable.getIsSomeRowsSelected(),
                            onChange:
                              reactTable.getToggleAllRowsSelectedHandler(),
                          }}
                        />
                      ) : (
                        // Render other headers normally
                        // @ts-ignore
                        header?.column?.columnDef?.Header
                      )
                    }
                  </th>
                ))}
              </tr>
            ))}
            {reactTable?.getRowModel()?.rows?.map((row) => (
              <tr
                key={row.id}
                className="text-[13px] text-center border border-[#0000001F]"
              >
                {row?.getVisibleCells().map((cell) => (
                  <td
                    key={cell.id}
                    className={`w-[${cell.column.getSize()}] p-2  border border-[#0000001F]`}
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </table>
          <Box>
            <Box />
            <Box className="text-black flex justify-end items-center mt-2 text-sm">
              <Box className="flex items-center">
                <span className="mr-2">Rows per page:</span>
                <select
                  value={reactTable.getState().pagination.pageSize}
                  onChange={(e) => {
                    reactTable.setPageSize(Number(e.target.value));
                  }}
                >
                  {[5, 10, 15, 20, 30, 40, 50, 100].map((pageSize) => (
                    <option key={pageSize} value={pageSize}>
                      {pageSize}
                    </option>
                  ))}
                </select>
              </Box>
              <Box className="ml-10">
                {/* <span>
            <Box>Page</Box>
            <strong>
              {reactTable.getState().pagination.pageIndex + 1} of{" "}
              {reactTable.getPageCount().toLocaleString()}
            </strong>
          </span> */}
                <span>1-5 of 13</span>
              </Box>
              <Box className="flex ml-5">
                <button
                  className="p-1 cursor-pointer"
                  onClick={() => reactTable.previousPage()}
                  disabled={!reactTable.getCanPreviousPage()}
                >
                  <MdOutlineKeyboardArrowLeft />
                </button>
                <button
                  className="p-1 cursor-pointer"
                  onClick={() => reactTable.nextPage()}
                  disabled={!reactTable.getCanNextPage()}
                >
                  <MdOutlineKeyboardArrowRight />
                </button>
              </Box>
            </Box>
          </Box>
        </>
      ) : (
        <Box className="text-center h-[100px] text-[#6c6c6c] font-bold flex justify-center items-center">
          No Data Found
        </Box>
      )}
    </Box>
  );
};

export default UserManagementTable;

const dropDownStyle = {
  control: (baseStyles: any, state: any) => ({
    ...baseStyles,
    color: "#000000DE",
    backgroundColor: "white",
    outline: state.isSelected ? "none" : "none",
    border: state.isFocused ? "none" : "none",
    boxShadow: "none",
    "&:hover": {
      border: "none",
    },
    "&:focus": {
      border: "1px solid #FFA475 !important",
    },
  }),
};

"use client";
import React, { useState} from "react";
import Box from "@mui/material/Box";
import { DataGridPremium } from "@mui/x-data-grid-premium";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { CustomToolbar } from "./CustomToolbar";
import { styled } from '@mui/material/styles';
import { CustomDataFound } from "./NoDataFound";

export default function DynamicDataGrid({
  tableName,
  initialState,
  columns,
  apiRef,
  gridData,
  loading,
}: any) {
  const { mode } = useThemeContext();
  const [selectedRowIDs, setSelectedRowIDs] = useState<any>([]);

  async function handleDeleteSelected(ids: any) {
    try {
      // console.log("handleDeleteSelected", ids);
      //   const response = await DELETE_REQUEST(`buyer/deletevobrequest/${ids}`);
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <Box>
      <DataGridPremium
        checkboxSelection
        rows={gridData}
        columns={columns}
        apiRef={apiRef}
        loading={loading}
        disableRowSelectionOnClick
        initialState={initialState}
        onRowSelectionModelChange={(newSelection: any) => {
          const selectedIDs: any = newSelection.map((id: any) => {
            const selectedRow: any = gridData.find((row: any) => row.id === id);
            return selectedRow?.RequestId;
          });
          setSelectedRowIDs(selectedIDs);
        }}
        slots={{
          noRowsOverlay: CustomDataFound,
          toolbar: () => (
            <CustomToolbar
              selectedRowIDs={selectedRowIDs}
              onDelete={handleDeleteSelected}
            />
          ),
        }}
        pagination={true}
        sx={{
          "& .MuiDataGrid-overlayWrapper": {
            minHeight: "200px",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: mode === "dark" ? "#424242" : "#FFFFF",
          },
          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight:'600'
          },
        }}
      />
    </Box>
  );
}

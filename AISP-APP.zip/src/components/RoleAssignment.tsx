"use client";
import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import { DataGridPremium, useGridApiRef } from "@mui/x-data-grid-premium";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import GroupsOutlinedIcon from "@mui/icons-material/GroupsOutlined";
import { styled } from "@mui/material/styles";
import { Autocomplete, Button, TextField, Typography } from "@mui/material";
import { BeatLoader } from "react-spinners";
import { GET_REQUEST, PATCH_REQUEST, POST_REQUEST } from "@/lib/api";
import { convertFormToObj } from "@/lib/helper";
import { CustomDataFound } from "./NoDataFound";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";

export default function RoleAssignmentGrid({
  roleAssignmentData,
  handleDialogClose,
  showRoles,
  partitionKey,
  rowKey,
  clearPartitionAndRowKey,
  action = true,
  userName,
  setUserName,
  userId,
  setUserId,
  usersList,
}: {
  roleAssignmentData: any;
  handleDialogClose: () => void;
  showRoles: () => void;
  partitionKey?: any;
  rowKey?: any;
  clearPartitionAndRowKey: () => void;
  action?: boolean;
  userName: string;
  setUserName: (value: string) => void;
  userId: string;
  setUserId: (value: string) => void;
  usersList?: any;
}) {
  const { mode } = useThemeContext();
  const [gridData, setGridData] = useState<any[]>([]);
  const [isDisable, setIsDisable] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const apiRef = useGridApiRef();
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    if (partitionKey) {
      fetchAddRole();
    } else if (roleAssignmentData) {
      fetchAddRole();
    } else {
      setUserId("");
      setGridData([]);
      setLoading(false);
    }
  }, [partitionKey, roleAssignmentData]);

  async function fetchAddRole() {
    try {
      setLoading(true);
      setIsDisable(true);
      let savedData: any = [];
      let addedData: any = [];
      if (partitionKey) {
        const response = await GET_REQUEST(
          `auth/getassignments/${partitionKey}/${rowKey}`
        );
        if (response?.data) {
          const responseData = response.data;
          if (typeof responseData === "object" && responseData !== null) {
            const selectedUser = usersList.find(
              (item: any) => item.value === responseData.partitionKey
            );
            setUserName(selectedUser.label);
            setUserId(responseData.partitionKey);
            savedData = [
              {
                ...responseData,
                id: responseData.rowKey,
                role_name: responseData.details.role_name,
                role_type: responseData.details.role_type,
              },
            ];
            console.log("savedData", savedData);
          } else {
            console.error(
              "Expected responseData to be an object, but got:",
              responseData
            );
          }
        }
      }
      if (roleAssignmentData) {
        addedData = roleAssignmentData.map((row: any, index: number) => ({
          ...row,
          id: savedData.length + index,
        }));
      }
      console.log("savedData", savedData);
      console.log("addedData", addedData);
      const combinedData = [...savedData, ...addedData];
      setGridData(combinedData);
      setLoading(false);
      setIsDisable(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
      setIsDisable(false);
    }
  }

  const handleRowDelete = (idToDelete: number) => {
    setGridData((prevData) => prevData.filter((row) => row.id !== idToDelete));
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors: any = {};
    console.log("userId", userId);
    if (userId === "") {
      newErrors.UserId = "This field is required";
      isValid = false;
    } else {
      newErrors.UserId = "";
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    try {
      e.preventDefault();
      setIsDisable(true);
      const isValid = validateForm();
      if (!isValid) {
        setIsDisable(false);
        return;
      }
      setIsDisable(false);
      const roleData = {
        roleIds: gridData.map((gdata: any) => gdata.rowKey),
        userPrincipleName: userId,
      };
      if (partitionKey) {
        const response = await POST_REQUEST("auth/createassignments", roleData);
        if (response?.success) {
          setIsDisable(false);
          showAlert(response.message, response.success);
        } else {
          alert(response?.message);
          setIsDisable(false);
          showAlert(response.message, response.success);
        }
      } else {
        const response = await POST_REQUEST("auth/createassignments", roleData);
        if (response?.success) {
          setIsDisable(false);
          showAlert(response.message, response.success);
        } else {
          alert(response?.message);
          setIsDisable(false);
          showAlert(response.message, response.success);
        }
      }
      setTimeout(() => {
        handleDialogClose(), setGridData([]), clearPartitionAndRowKey();
      }, 1500);
    } catch (error) {
      console.log(error);
      setIsDisable(false);
      handleDialogClose();
    }
  };

  const columns = [
    { field: "rowKey", headerName: "Role ID", flex: 1 },
    { field: "role_name", headerName: "Role Name", flex: 1 },
    { field: "role_type", headerName: "Role Type", flex: 1 },
    {
      field: "Action",
      headerName: "Action",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="py-2 flex items-center">
          <Button
            color="inherit"
            variant="text"
            sx={{ fontWeight: 500, fontSize: "13px" }}
            disabled={isDisable || !action}
            onClick={() => handleRowDelete(params.row.id)}
          >
            <DeleteOutlineIcon
              fontSize="small"
              style={{ marginRight: "5px" }}
            />
          </Button>
        </Box>
      ),
    },
  ];

  return (
    <Box>
      <Typography
        variant="h6"
        className={`text-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
        }`}
      >
        {partitionKey ? `Update ` : `Add `} Role
      </Typography>
      <Typography
        variant="body1"
        className={`text-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
        }`}
      >
        {partitionKey ? `Update ` : `Set `} Role Permissions
      </Typography>
      <Box
        sx={{
          m: 2,
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          padding: "0 50px",
        }}
      >
        <Autocomplete
          id="UserId"
          value={userId}
          options={usersList}
          sx={{ width: "80%" }}
          onChange={(event:any, newValue:any) => {
            if (newValue) {
              setUserName(newValue.label);
              setUserId(newValue.value);
            } else {
              setUserName("");
              setUserName("");
            }
          }}
          renderInput={(params: any) => (
            <TextField {...params} label="User Id" />
          )}
        />
        <Button
          variant="contained"
          color="primary"
          onClick={showRoles}
          sx={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: "40px",
            marginLeft: "5px",
          }}
          disabled={!action}
        >
          <span className="normal-case">Choose Role</span>
          <GroupsOutlinedIcon className="ml-2" fontSize="small" />
        </Button>
      </Box>

      {userName && (
        <Typography
          variant="body1"
          className={` ml-2 ${
            mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"
          }`}
        >
          <span style={{ fontWeight: 600 }}>User Name:</span> {userName}
        </Typography>
      )}

      <DataGridPremium
        rows={gridData}
        columns={columns}
        apiRef={apiRef}
        loading={loading}
        disableRowSelectionOnClick
        slots={{
          noRowsOverlay: CustomDataFound,
        }}
        sx={{
          "& .MuiDataGrid-overlayWrapper": {
            minHeight: "200px",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: mode === "dark" ? "#424242" : "#FFFFF",
          },
          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: "600",
          },
        }}
      />
      <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
        {action && (
          <Button
            className={`rounded-md ${
              isDisable && "cursor-not-allowed opacity-[0.6]"
            }`}
            sx={{ ml: 2 }}
            variant="contained"
            disabled={isDisable}
            onClick={handleFormSubmit}
          >
            <span className="normal-case">
              {isDisable ? (
                <BeatLoader color="#FFFFFF" size={10} />
              ) : partitionKey ? (
                `Update`
              ) : (
                `Submit`
              )}
            </span>
          </Button>
        )}
        <Button
          variant="outlined"
          color="primary"
          className="rounded-md"
          onClick={() => {
            handleDialogClose(), setGridData([]), clearPartitionAndRowKey();
          }}
          sx={{ ml: 2 }}
        >
          <span className="normal-case">Cancel</span>
        </Button>
      </Box>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </Box>
  );
}

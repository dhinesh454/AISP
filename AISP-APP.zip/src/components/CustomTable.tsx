"use client";
import React, { useState, HTMLProps, useEffect, useRef } from "react";
import {
  Column,
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  Table,
  PaginationState,
  useReactTable,
} from "@tanstack/react-table";
import { useSearchParams } from "next/navigation";
import { IoIosSearch } from "react-icons/io";
import { DELETE_REQUEST, GET_REQUEST, POST_REQUEST } from "@/lib/api";
import {
  MdOutlineKeyboardArrowLeft,
  MdOutlineKeyboardArrowRight,
} from "react-icons/md";
import { CiExport } from "react-icons/ci";
import { mkConfig, generateCsv, download } from "export-to-csv";
import Datepicker from "react-tailwindcss-datepicker";
import Select from "react-select";
import { MdDeleteOutline } from "react-icons/md";
import { RiPencilFill } from "react-icons/ri";
import CustomColum from "./customColum";
import { addSpaceAfterCamelCase } from "@/lib/helper";
import Swal from "sweetalert2";
import { deleteCookie } from "cookies-next";
import { useRouter } from "next/navigation";
import { Box } from "@mui/material";

const csvConfig = mkConfig({
  fieldSeparator: ",",
  filename: "EmpanelmentReport",
  decimalSeparator: ".",
  useKeysAsHeaders: true,
});

const exportExcel = (rows: any) => {
  const rowData = rows.map((row: any) => row.original);
  const csv = generateCsv(csvConfig)(rowData);
  download(csvConfig)(csv);
};

const statusOptions = [
  { value: "All", label: "All" },
  { value: "Active", label: "Active" },
  { value: "Rejected", label: "Rejected" },
  { value: "Expired", label: "Expired" },
  // Add more options as needed
];

const CustomTable = ({
  tableName,
  endPoint,
  source,
  onSelectType,
  onSelectEmpanelmentRequest,
}: any) => {
  const router = useRouter();
  const [data, setData] = useState<any>([]);
  const [nextToken, setNextToken] = useState("");
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const [rowSelection, setRowSelection] = useState({});
  const [dateValue, setDateValue] = useState<any>({
    startDate: null,
    endDate: null,
  });
  const [status, setStatus] = useState<any>(null);
  const [columnVisibility, setColumnVisibility] = React.useState({});

  const columns = [
    {
      id: "Select",
      Header: ({ table }: any) => (
        <IndeterminateCheckbox
          {...{
            checked: table.getIsAllRowsSelected(),
            indeterminate: table.getIsSomeRowsSelected(),
            onChange: table.getToggleAllRowsSelectedHandler(),
          }}
        />
      ),
      cell: ({ row }: any) => (
        <Box className="px-1">
          <IndeterminateCheckbox
            {...{
              checked: row.getIsSelected(),
              disabled: !row.getCanSelect(),
              indeterminate: row.getIsSomeSelected(),
              onChange: row.getToggleSelectedHandler(),
            }}
          />
        </Box>
      ),
    },
    {
      id: "Request ID",
      accessorKey: "RequestId",
      Header: "Request ID",
      cell: (props: any) => (
        <p
          className="py-2 text-[#0049F3] cursor-pointer font-semibold"
          onClick={() =>
            onSelectEmpanelmentRequest(props.getValue(), true, false)
          }
        >
          {props.getValue()}
        </p>
      ),
    },
    {
      id: "Supplier Name",
      accessorKey: "SupplierName",
      Header: "Supplier Name",
      cell: (props: any) => <p className="py-2">{props.getValue()}</p>,
    },
    {
      id: "Mobile Number",
      accessorKey: "MobileNumber",
      Header: "Mobile Number",
      cell: (props: any) => <p className="py-2 ">{props.getValue()}</p>,
    },
    {
      id: "Supplier Email",
      accessorKey: "SupplierEmail",
      Header: "Supplier Email",
      cell: (props: any) => <p className="py-2">{props.getValue()}</p>,
    },

    {
      id: "Status",
      accessorKey: "Status",
      Header: "Status",
      cell: (props: any) => {
        return (
          <Box className="inline-block">
            <p
              className={`flex items-center justify-center rounded-full h-[30px] w-20 font-normal text-[13px] leading-[18px] ${
                props.getValue() === "Active"
                  ? "bg-[#E9F7E9] text-[#25AB21]"
                  : props.getValue() === "In-active"
                  ? "bg-[#FFF4E8] text-[#F79420]"
                  : props.getValue() === "Rejected" ||
                    props.getValue() === "Expired"
                  ? "bg-[#F7E9E9] text-[#FF0000]"
                  : ""
              }`}
            >
              {props.getValue()}
            </p>
          </Box>
        );
      },
    },
    {
      id: "Action",
      accessorKey: "RequestId",
      Header: "Action ",
      cell: (props: any) => (
        <Box>
          {tableName === "EmpanelmentReport" ? (
            <Box className="py-2 flex items-center justify-center">
              {source === "supplier" ? (
                <>
                  <button
                    className="border-solid border-2 border-[#25AB21] b-2 text-[#25AB21] py-1 px-2 rounded-full"
                    onClick={() => {
                      Swal.fire({
                        title: "Are you sure you want to approve this?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, Approve it!",
                        customClass: "ml-[15%]",
                      }).then((result) => {
                        if (result.isConfirmed) {
                          approveRejectRequest(props.getValue(), "A");
                        }
                      });
                    }}
                  >
                    Approve
                  </button>
                  <button
                    className="border-solid border-2 border-[#FF0000] b-2 text-[#FF0000] py-1 px-2 ml-2 rounded-full"
                    onClick={() => {
                      Swal.fire({
                        title: "Are you sure you want to reject this?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, Reject it!",
                        customClass: "ml-[15%]",
                      }).then((result) => {
                        if (result.isConfirmed) {
                          approveRejectRequest(props.getValue(), "R");
                        }
                      });
                    }}
                  >
                    Reject
                  </button>
                </>
              ) : (
                <>
                  <RiPencilFill
                    onClick={() =>
                      onSelectEmpanelmentRequest(props.getValue(), true, true)
                    }
                    className="cursor-pointer w-4 h-4"
                  />
                  <MdDeleteOutline
                    onClick={() => {
                      Swal.fire({
                        title: "Are you sure you want to delete this?",
                        text: "You won't be able to delete this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, Delete it!",
                        customClass: "ml-[15%]",
                      }).then((result) => {
                        if (result.isConfirmed) {
                          deleteRequest(props.getValue());
                        }
                      });
                    }}
                    className="cursor-pointer w-4 h-4 ml-2"
                  />
                </>
              )}
            </Box>
          ) : (
            <Box>
              <>
                <RiPencilFill
                  onClick={() =>
                    onSelectEmpanelmentRequest(props.getValue(), true, true)
                  }
                  className="cursor-pointer w-4 h-4"
                />
                {/* <MdDeleteOutline
                  onClick={() => deleteRequest(props.getValue())}
                  className="cursor-pointer w-4 h-4 ml-2"
                /> */}
              </>
            </Box>
          )}
        </Box>
      ),
    },
  ];

  async function handleDataFetch(
    filterType: string,
    inputValue: any,
    dateValue: any
  ) {
    try {
      let queryParams = `source=${source}&pageSize=${pagination.pageSize}`;

      if (filterType === "status") {
        const filterStatus: any = status?.value;
        if (filterStatus !== "All") {
          queryParams += `&status=${filterStatus}`;
        }
      } else if (filterType === "searchGlobal") {
        if (inputValue !== "") {
          queryParams += `&searchGlobal=${inputValue}`;
        }
      } else if (filterType === "searchUser") {
        if (inputValue !== "") {
          queryParams += `&searchUser=${inputValue}`;
        }
      } else if (filterType === "dateValueChange") {
        if (dateValue.startDate !== null) {
          queryParams += `&startDate=${dateValue.startDate}&endDate=${dateValue.endDate}`;
        }
      }

      const res = await GET_REQUEST(`${endPoint}?${queryParams}`);

      if (res?.success) {
        setNextToken(res?.nextToken);
        setData(res?.data);
      } else {
        if (res?.message === "Unauthorized") {
          deleteCookie("airditToken");
          router.refresh();
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  async function handleStatusFilter() {
    await handleDataFetch("status", status?.value, null);
  }

  async function handleFilter(inputValue: any) {
    await handleDataFetch("searchGlobal", inputValue, null);
  }

  async function handleFilterUser(inputValue: any) {
    await handleDataFetch("searchUser", inputValue, null);
  }

  async function handleDateValueChange(newValue: any) {
    await handleDataFetch("dateValueChange", null, newValue);
  }

  async function apiCall() {
    await handleDataFetch("api", null, null);
  }

  useEffect(() => {
    apiCall();
  }, [source]);

  function IndeterminateCheckbox({
    indeterminate,
    className = "",
    onChange,
    ...rest
  }: {
    indeterminate?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  } & HTMLProps<HTMLInputElement>) {
    const ref = useRef<HTMLInputElement>(null!);

    useEffect(() => {
      if (typeof indeterminate === "boolean") {
        ref.current.indeterminate = !rest.checked && indeterminate;
      }
    }, [ref, indeterminate]);

    return (
      <input
        type="checkbox"
        ref={ref}
        className={className + " cursor-pointer"}
        onChange={onChange} // Pass onChange event here
        {...rest}
      />
    );
  }

  async function approveRejectRequest(requestId: any, action: string) {
    try {
      const res = {
        id: requestId,
        action: action,
      };
      const response = await POST_REQUEST("buyer/sregaction ", res);
      if (response?.success) {
        Swal.fire({
          title: action === "A" ? "Approved !" : "Rejected !",
          text: response?.message,
          icon: "success",
          showConfirmButton: false,
          timer: 3000,
        });
        apiCall();
      } else {
        Swal.fire({
          title: "Error",
          text: response?.message,
          icon: "error",
          showConfirmButton: false,
          timer: 3000,
        });
      }
    } catch (error) {
      console.log(error);
    }
  }

  async function deleteRequest(requestId: any) {
    try {
      const response = await DELETE_REQUEST(
        `buyer/deletevobrequest/${requestId}`
      );
      if (response?.success) {
        Swal.fire({
          title: "Deleted!",
          text: response?.message,
          icon: "success",
          showConfirmButton: false,
          timer: 3000,
        });
        apiCall();
      } else {
        Swal.fire({
          title: "Error",
          text: response?.message,
          icon: "error",
          showConfirmButton: false,
          timer: 3000,
        });
      }
    } catch (error) {
      console.log(error);
    }
  }

  const reactTable = useReactTable({
    data,
    columns,
    state: {
      pagination,
      rowSelection,
      columnVisibility: columnVisibility,
    },
    manualPagination: true,
    enableRowSelection: true,
    getCoreRowModel: getCoreRowModel(),
    onRowSelectionChange: setRowSelection,
    getFilteredRowModel: getFilteredRowModel(), //client side filtering
    // getPaginationRowModel: getPaginationRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
  });
  return (
    <Box className="shadow-2xl rounded-lg w-[90%] m-auto mt-5 px-4 bg-white">
      <Box className="p-4 ">
        <Box className="flex w-full items-center">
          <Box className="flex relative mt-2 w-[30%]  text-[13px]">
            <IoIosSearch className="absolute top-3 left-2 text-[#8C8C8C]" />
            <input
              type="text"
              className="w-[100%] px-4 py-2 border-none outline-none rounded-[10px] pl-8 bg-[#F0F0F0]  "
              placeholder="Request ID/ Supplier Name/ Mobile Number "
              onChange={(e) => handleFilter(e.target.value)}
            />
          </Box>
          <Box className="relative  rounded-lg py-1 w-[25%] ml-2 border-[1px] border-[#CFCFCF]">
            <label className="absolute left-3 -top-[.5px] text-[12px] z-10 text-[#828282] font-light">
              Select Date Range
            </label>
            <Box className="w-full">
              <Datepicker
                separator={"-"}
                value={dateValue}
                onChange={handleDateValueChange}
                showShortcuts={true}
                placeholder={"Select"}
                inputClassName="w-[100%] py-2 pl-1 border-none outline-none rounded-[10px] pl-8 bg-white"
              />
            </Box>
          </Box>
          <Box className="relative border border-[#CFCFCF] rounded-lg py-1 w-[15%] ml-2">
            <label className="absolute left-3 -top-[.5px] text-[12px] z-10 text-[#828282] font-light">
              Status
            </label>
            <Box className="w-full">
              <Select
                name="Status"
                options={statusOptions}
                value={status}
                onChange={(selectedOption: any) => setStatus(selectedOption)}
                styles={colorStyles}
              />
            </Box>
          </Box>
          <Box className=" flex w-[20%] ml-2">
            <button
              type="button"
              className="bg-[#8C57FF] text-white px-4 py-2  rounded-md"
              onClick={handleStatusFilter}
            >
              Show
            </button>
          </Box>
        </Box>
        <Box className="flex justify-between items-center ">
          <button
            type="button"
            className="flex items-center sm:w-[40%] md:w-[20%] lg:w-[20%] xl:w-[10%] h-10 bg-[#FFFF] text-[#999999]  px-4 py-2 ml-2 rounded-md border-solid border-2 border-[#b5b4b4]"
            onClick={() => exportExcel(reactTable.getFilteredRowModel().rows)}
          >
            <CiExport className="mr-2 text-[#6c6c6c]" /> Export
          </button>
          <Box className="flex items-center w-[45%]">
            <CustomColum reactTable={reactTable} />
            <Box className="my-4 flex justify-end ml-5">
              <input
                type="text"
                className="px-4 py-2 border border-[#CFCFCF] outline-none rounded-md pl-3"
                placeholder="Search User"
                onChange={(e) => handleFilterUser(e.target.value)}
              />
            </Box>
          </Box>
        </Box>
      </Box>
      <Box className="flex items-center w-[100%] ml-2 ">
        <button
          className={`w-[15%] text-[16px] leading-[24px] text-center border-[#0000001F]   ${
            source === "supplier" ? "border-2 border-b-0" : "border-b-2"
          }`}
          onClick={() => onSelectType("supplier")}
        >
          Pending for Review
        </button>
        <button
          className={`w-[15%] .. leading-[24px] text-center border-[#0000001F]  ${
            source === "buyer" ? "border-2 border-b-0" : "border-b-2"
          }`}
          onClick={() => onSelectType("buyer")}
        >
          Ongoing
        </button>
        <Box className="border-b-2 border-[#0000001F] w-[5%] mt-6"></Box>
      </Box>
      {data?.length > 0 ? (
        <>
          <table className="text-center mt-4 w-full border border-[#0000001F]">
            {reactTable.getHeaderGroups().map((headerGroup) => (
              <tr
                key={headerGroup?.id}
                className="bg-[#d6dce6] text-[#00185A] text-[14px] font-thin py-4"
              >
                {headerGroup.headers.map((header) => (
                  <th
                    key={header?.id}
                    className={`w-[${header.getSize()}] text-center py-4  border border-[#0000001F]`}
                  >
                    {
                      // Check if it's the checkbox column
                      header.id === "Select" ? (
                        <IndeterminateCheckbox
                          {...{
                            checked: reactTable.getIsAllRowsSelected(),
                            indeterminate: reactTable.getIsSomeRowsSelected(),
                            onChange:
                              reactTable.getToggleAllRowsSelectedHandler(),
                          }}
                        />
                      ) : (
                        // Render other headers normally
                        // @ts-ignore
                        header?.column?.columnDef?.Header
                      )
                    }
                  </th>
                ))}
              </tr>
            ))}
            {reactTable?.getRowModel()?.rows?.map((row) => (
              <tr
                key={row.id}
                className="text-[13px] text-center border border-[#0000001F]"
              >
                {row?.getVisibleCells().map((cell) => (
                  <td
                    key={cell.id}
                    className={`w-[${cell.column.getSize()}] p-2  border border-[#0000001F]`}
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </table>
          <Box>
            <Box />
            <Box className="text-black flex justify-end items-center mt-2 text-sm">
              <Box className="flex items-center">
                <span className="mr-2">Rows per page:</span>
                <select
                  value={reactTable.getState().pagination.pageSize}
                  onChange={(e) => {
                    reactTable.setPageSize(Number(e.target.value));
                  }}
                >
                  {[5, 10, 15, 20, 30, 40, 50, 100].map((pageSize) => (
                    <option key={pageSize} value={pageSize}>
                      {pageSize}
                    </option>
                  ))}
                </select>
              </Box>
              <Box className="ml-10">
                {/* <span>
            <Box>Page</Box>
            <strong>
              {reactTable.getState().pagination.pageIndex + 1} of{" "}
              {reactTable.getPageCount().toLocaleString()}
            </strong>
          </span> */}
                <span>1-5 of 13</span>
              </Box>
              <Box className="flex ml-5">
                <button
                  className="p-1 cursor-pointer"
                  onClick={() => reactTable.previousPage()}
                  disabled={!reactTable.getCanPreviousPage()}
                >
                  <MdOutlineKeyboardArrowLeft />
                </button>
                <button
                  className="p-1 cursor-pointer"
                  onClick={() => reactTable.nextPage()}
                  disabled={!reactTable.getCanNextPage()}
                >
                  <MdOutlineKeyboardArrowRight />
                </button>
              </Box>
            </Box>
          </Box>
        </>
      ) : (
        <Box className="text-center h-[100px] text-[#6c6c6c] font-bold flex justify-center items-center">
          No Data Found
        </Box>
      )}
    </Box>
  );
};

export default CustomTable;

const colorStyles = {
  control: (baseStyles: any, state: any) => ({
    ...baseStyles,
    height: "20px",
    backgroundColor: "white",
    outline: state.isSelected ? "none" : "none",
    border: state.isFocused ? "none" : "none",
    boxShadow: "none",
    "&:hover": {
      border: "none",
    },
    "&:focus": {
      border: "1px solid #FFA475 !important",
    },
  }),
};

const customDateRangeStyle = `border border-blueBorder rounded-[10px] pl-2 pr-1 focus:outline-none text-[14px] font-semibold text-[#00156A]  border-[#BDD4FF] font-montserrat placeholder:font-[600] w-[230px] h-[48px] mb-0 bg-white w-full placeholder:text-[#D2D2D2]`;

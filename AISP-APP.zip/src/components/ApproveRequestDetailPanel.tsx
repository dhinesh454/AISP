"use client";
import React, { useState } from "react";
import { IoIosInformationCircleOutline } from "react-icons/io";
import { LiaCommentDots } from "react-icons/lia";
import { CgAttachment } from "react-icons/cg";
import { FiPlusCircle } from "react-icons/fi";
import { PdfIcon } from "@/components/icons";
import { FaEye } from "react-icons/fa";
import { HiDotsVertical } from "react-icons/hi";
import { FaUser } from "react-icons/fa";
import { RxPaperPlane } from "react-icons/rx";
import { addSpaceAfterCamelCase } from "@/lib/helper";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { Avatar, Badge, Box, Button, Tab, Tabs, Typography } from "@mui/material";
import { PATCH_REQUEST, POST_REQUEST } from "@/lib/api";
import { useMsal } from "@azure/msal-react";
import { ErrorAlert, SuccessAlert } from "./Alerts";


const ApproveRequestDetailPanel = ({
  data,
  setRefetch,
}: {
  data: any;
  setRefetch: any;
}) => {
  const { mode } = useThemeContext();
  const [selectedTab, setSelectedTab] = useState(0);
  const { instance } = useMsal();
  const [userinfo, setUserInfo] = React.useState<any>(
    instance.getAllAccounts()
  );
  const [commentText, setCommentText] = useState("");
  const [isComment,setIsComment]=useState<boolean>(false);
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");

  const nameOfFirm = data?.data?.BasicInformation?.SupplierName;
  const nameOfContactPerson = data?.data?.BasicInformation?.ContactPersonName;
  const status = data?.data?.Status;
  const requestedDate = data?.data?.timestamp;
  const commentCount = data?.data?.comments?.length;
  const attachmentsCount = data?.data?.Attachments?.length;
  const empId=data?.partitionKey;
  const id=data?.rowKey;

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue);
  };

  function InformationPanel() {
    const Item = data?.data || {};
    return (
      <Box component="div" sx={{ overflowY: "scroll", height: "44vh" }}>
        {Object.keys(Item)
          .filter(
            (heading) =>
              typeof Item[heading] === "object" &&
              Item[heading] !== null &&
              !Array.isArray(Item[heading])
          )
          .map((heading, index) => (
            <Box key={index} className="border-b-[1px] p-4">
              <h2 className="text-[14px] font-semibold mb-2">
                {addSpaceAfterCamelCase(heading)}
              </h2>
              <Box className="w-full text-[13px]">
                <Box
                  className="grid gap-2"
                  sx={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fill, minmax(200px, 1fr))",
                    alignItems: "center",
                  }}
                >
                  {Object.entries(Item[heading]).map(
                    ([key, value]: any, entryIndex: any) => (
                      <React.Fragment key={entryIndex}>
                        <p
                          className="text-[#595959] flex-shrink"
                          style={{
                            whiteSpace: "normal",
                            wordBreak: "break-word",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {addSpaceAfterCamelCase(key)}
                        </p>
                        <p
                          className="text-[#141414] font-medium flex-shrink"
                          style={{
                            whiteSpace: "normal",
                            wordBreak: "break-word",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {typeof value === "object"
                            ? JSON.stringify(value)
                            : value}
                        </p>
                      </React.Fragment>
                    )
                  )}
                </Box>
              </Box>
            </Box>
          ))}
      </Box>
    );
  }

  function CommentsPanel() {
    const sortedComments: any = data?.data?.comments?.sort((a: any, b: any) => {
      return (new Date(b.timestamp) as any) - (new Date(a.timestamp) as any);
    });

    return (
      <Box
        component="div"
        sx={{ overflow: "scroll", overflowX: "hidden", height: "44vh" }}
      >
        {sortedComments?.map((comment: any, index: number) => (
          <Box key={index} className="bg-[#F0F0F0] rounded-[4px] m-2">
            <Box className="flex items-center p-4">
              <Avatar
                alt="profile image"
                src="/images/profileImage.png"
                sx={{ width: 50, height: 50 }}
              />
              <Box className="flex-row ml-4">
                <h2 className="text-[16px] font-bold">{comment.CreatedBy}</h2>
                <h4 className="text-[12px] mt-2">
                  {new Date(comment.timestamp).toLocaleString()}
                </h4>
                <h5 className="text-[13px] font-semibold">
                  {comment.CommentText}
                </h5>
              </Box>
            </Box>
          </Box>
        ))}
      </Box>
    );
  }

  function AttachmentsPanel() {
    return (
      <Box
        component="div"
        sx={{
          overflow: "scroll",
          overflowX: "hidden",
          height: "44vh",
          paddingTop: "10px",
        }}
      >
        <Box className="flex justify-between px-4">
          <h2 className="text-[#262626] text-[15px] font-semibold">
            Attachments (1)
          </h2>
          <button className="text-[#8C57FF] text-[15px] font-semibold flex items-center justify-center ">
            <FiPlusCircle className="mr-1" /> Attachments
          </button>
        </Box>
        <Box className="flex rounded-[4px] justify-between bg-[#F0F0F0] p-3 w-[30%] items-center">
          <PdfIcon className="mr-2 text-[40px]" />
          <Box className="mr-2">
            <h2 className="text-[13px] font-semibold">PO 45000000060.pdf</h2>
            <h2 className="text-[10px] text-center">1.1MB, 10/08.2023</h2>
          </Box>
          <FaEye className="mr-2 text-[20px]" />
          <HiDotsVertical className="mr-2 text-[20px]" />
        </Box>
      </Box>
    );
  }

  async function handleComment() {
    try {
      setIsComment(true)
      const commentData: any = {
        empId,
        comment: commentText,
      };
      const response = await POST_REQUEST("approval/comments", commentData);
      if (response.success) {
       setRefetch(true);
       setCommentText("");
      }
      setIsComment(false)
    } catch (error) {
      console.log(error);
      setIsComment(false)
    }
  }

  async function handleApprovalReject(action:string) {
    try {
      setIsComment(true)
      const approvalRejectObj: any = {
        id,
        action: action,
      };
      const response = await PATCH_REQUEST("approval/action ", approvalRejectObj);
      if (response.success) {
       setRefetch(true);
       showAlert(response.message, response.success);
      }else{
        showAlert(response.message, response.success);
      }
    } catch (error) {
      console.log(error);
      setIsComment(false)
    }
  }

  return (
    <Box className="bg-transparent h-[80vh]">
      <Box
        className={`rounded-md shadow-lg ml-1 ${
          mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
        }`}
      >
        <Box className="flex-row bg-gradient-to-l from-[#8C57FF] to-[#c5abff] p-4 rounded-md h-[19.5vh]">
          <h3 className="text-[15px] font-semibold">{nameOfFirm}</h3>
          <Box className="flex my-4 text-[13px]">
            <Box className="mr-5 ">
              <h4 className="font-medium">Requested Date</h4>
              <p>{new Date(requestedDate).toLocaleString()}</p>
            </Box>
            <Box className="mr-5">
              <h4 className="font-medium">Requested By</h4>
              <p>{nameOfContactPerson}</p>
            </Box>
            <Box className="mr-5">
              <h4 className="font-medium">Overall Status</h4>
              <Box
                className={`flex items-center justify-center rounded-full p-1 font-medium text-[13px] 
                 ${
                   status === "Approved"
                     ? "bg-[#E9F7E9] text-[#25AB21]"
                     : status === "Rejected"
                     ? "bg-[#F7E9E9] text-[#FF0000]"
                     : "bg-[#FFF4E8] text-[#F79420]"
                 }
                `}
              >
                <Box className="flex items-center">
                  {status === "Approved" ? (
                    <>
                      <span className="">{status}</span>
                    </>
                  ) : status === "Rejected" ? (
                    <>
                      <span className="">{status}</span>
                    </>
                  ) : (
                    <>
                      <span className="">{status}</span>
                    </>
                  )}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
        <Tabs
          onChange={handleChange}
          value={selectedTab}
          aria-label="Tabs where each tab needs to be selected manually"
          className="h-[8vh]"
        >
          <Tab
            className="normal-case px-10"
            icon={<IoIosInformationCircleOutline fontSize="large" />}
            iconPosition="start"
            label={
              <Box
                position="relative"
                display="inline-flex"
                alignItems="center"
              >
                <Typography sx={{ fontSize: "14px" }}>Information</Typography>
              </Box>
            }
          />
          <Tab
            className="normal-case px-10"
            icon={<LiaCommentDots fontSize="large" />}
            iconPosition="start"
            label={
              <Box
                position="relative"
                display="inline-flex"
                alignItems="center"
              >
                <Typography sx={{ fontSize: "14px" }}>Comments</Typography>
                <Badge
                  badgeContent={commentCount}
                  color="primary"
                  sx={{ position: "absolute", right: -15 }}
                />
              </Box>
            }
          />
          <Tab
            className="normal-case px-10"
            icon={<CgAttachment fontSize="large" />}
            iconPosition="start"
            label={
              <Box
                position="relative"
                display="inline-flex"
                alignItems="center"
              >
                <Typography sx={{ fontSize: "14px" }}>Attachments</Typography>
                <Badge
                  badgeContent={attachmentsCount}
                  color="primary"
                  sx={{ position: "absolute", right: -15 }}
                />
              </Box>
            }
          />
        </Tabs>
        {selectedTab === 0 && <InformationPanel />}
        {selectedTab === 1 && <CommentsPanel />}
        {selectedTab === 2 && <AttachmentsPanel />}
      </Box>
      <Box
        className={`flex justify-between items-center w-[99.8%] bg-[#F5F6F7] px-2 shadow-lg py-2 rounded-md ml-1 mt-1 h-[8vh] ${
          mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
        }`}
      >
        <Box className="flex items-center w-[65%]">
          <Box className="flex relative w-[100%]">
            <FaUser className="absolute w-[20px] h-[20px] top-2.5 left-2 text-[#8C8C8C]" />
            <input
              type="text"
              className="w-[100%] px-4 py-2 border-none outline-none rounded-full pl-8 bg-[#EAEAEA]"
              placeholder="Type here..."
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
            />
          </Box>
          <Button
            variant="contained"
            sx={{
              borderRadius: "50%", // Set border radius to 50% to make it round
              minWidth: "unset", // Remove any minimum width to allow it to shrink to circle size
              padding: 0, // Remove padding to ensure it's a perfect circle
              width: "40px", // Set width to 40px
              height: "40px", // Set height to 40px
            }}
            onClick={handleComment}
            disabled={isComment}
          >
            <RxPaperPlane />
          </Button>
        </Box>
        <Box className="flex">
          <Button
            variant="outlined"
            color="success"
            type="button"
            className="rounded-full mx-2"
            onClick={() =>handleApprovalReject("Accepted")}
          >
            <span className="normal-case">Approve</span>
          </Button>
          <Button
            variant="outlined"
            color="error"
            type="button"
            className="rounded-full mx-2"
            onClick={() => handleApprovalReject("Rejected")}
          >
            <span className="normal-case">Reject</span>
          </Button>
          <Button
            variant="text"
            type="button"
            onClick={() => console.log("Show Log Clicked")}
          >
            <span className="normal-case">Show Log</span>
          </Button>
        </Box>
      </Box>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </Box>
  );
};

export default ApproveRequestDetailPanel;

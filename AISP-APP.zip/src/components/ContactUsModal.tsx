"use client";
import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";

const ContentWrapper = styled("div")({
  display: "flex",
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
});

const ContactInfoWrapper = styled("div")({
  display: "flex",
  flexDirection: "column",
});

export default function ContactUsModal() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      <Button
        variant="outlined"
        onClick={handleClickOpen}
        className="rounded-md"
      >
        <span className="font-bold normal-case">Contact Us</span>
      </Button>
      <Dialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
        sx={{ borderRadius: "10px", marginLeft: "50%", marginTop: "10%" }}
      >
        <DialogTitle
          sx={{ m: 0, p: 2, background: "#9039E8", color: "#FFF" }}
          id="customized-dialog-title"
          className="font-bold"
        >
          Contact Us
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: "#FFF",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent sx={{ background: "#9039E8", color: "#FFF" }}>
          <ContentWrapper>
            <ContactInfoWrapper className="border-r-2 p-3">
              <Typography
                variant="body1"
                gutterBottom
                className="font-semibold"
              >
                IT Services
              </Typography>
              <Typography className="mt-4" variant="body2" gutterBottom>
                <PhoneIcon /> +91 9611067676
              </Typography>
              <Typography className="mt-2" variant="body2" gutterBottom>
                <EmailIcon /> it@airditsoftware.com
              </Typography>
            </ContactInfoWrapper>
            <ContactInfoWrapper className="p-3">
              <Typography
                variant="body1"
                gutterBottom
                className="font-semibold"
              >
                Business Services
              </Typography>
              <Typography className="mt-4" variant="body2" gutterBottom>
                <PhoneIcon /> +91 9015466052
              </Typography>
              <Typography className="mt-2" variant="body2" gutterBottom>
                <EmailIcon /> sales@airditsoftware.com
              </Typography>
            </ContactInfoWrapper>
          </ContentWrapper>
        </DialogContent>
      </Dialog>
      {/* </BootstrapDialog> */}
    </React.Fragment>
  );
}

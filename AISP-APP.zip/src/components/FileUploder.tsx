import React, { ChangeEvent, useState } from "react";
import { POST_REQUEST } from "@/lib/api";
import { FadeLoader } from "react-spinners";
import { MdOutlineFileUpload } from "react-icons/md";
import { Box } from "@mui/material";
// import { errorAlert } from "./Alerts";

const FileUploader = ({
  handleClose,
  onSetFile,
}: {
  handleClose: any;
  onSetFile: any;
}) => {
  const [isUpload, setIsUpload] = useState<boolean>(false);

  async function handleFileUpload(event: ChangeEvent<HTMLInputElement>) {
    setIsUpload(true);
    const file = event.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file, file.name);
    uploadFileApi(formData)
  }

  function handleCloseUploader() {
    handleClose(false);
  }

  function handleDragOver(event: any) {
    event.preventDefault();
  }

  function handleDrop(event: any) {
    event.preventDefault();
    setIsUpload(true);
    const file = event.dataTransfer.files[0];
    if (file) {
      const formData = new FormData();
      formData.append("file", file, file.name);
      uploadFileApi(formData)
    }
  }

  async function uploadFileApi(formData: any) {
    try {
      const response = await POST_REQUEST("upload", formData);
      console.log("response",response)
      if (response?.success) {
        onSetFile(response?.data.filename);
        setIsUpload(false);
        handleCloseUploader();
      }else{
        setIsUpload(false);
        // errorAlert(response?.message)
      }
    } catch (error) {
      console.log(error);
      setIsUpload(false);
    }
  }

  return (
    <Box className="fixed top-0 left-0 flex justify-center items-center w-full h-full bg-gray-800 bg-opacity-50 z-50">
      <Box className="bg-white rounded-lg shadow-lg p-4 w-[400px]">
        <Box
          className="flex flex-col items-center justify-center border-dashed border-2 border-gray-400 p-8 cursor-pointer"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {isUpload ? (
            <FadeLoader />
          ) : (
            <Box className="flex flex-col justify-center items-center">
              <MdOutlineFileUpload className="h-12 w-12 mb-4 text-gray-400" />
              <span className="text-gray-400">Drag & Drop files here</span>
              <span className="text-gray-400">or</span>
              <label htmlFor="file-upload" className="cursor-pointer">
                <input
                  id="file-upload"
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                <Box className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4">
                  Choose File
                </Box>
              </label>
            </Box>
          )}
        </Box>
        <button
          onClick={handleCloseUploader}
          className="mt-4 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center"
        >
          Close
        </button>
      </Box>
    </Box>
  );
};

export default FileUploader;

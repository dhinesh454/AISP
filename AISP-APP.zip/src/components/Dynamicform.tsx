"use client";
import React, { useEffect, useState } from "react";
import { dropdownAPI, empanelmentRequestJSON } from "@/lib/formdata";
import { GET_REQUEST, PATCH_REQUEST, POST_REQUEST } from "@/lib/api";
import { addSpaceAfterCamelCase, convertObject } from "@/lib/helper";
import { BeatLoader, MoonLoader } from "react-spinners";
import { TextField, Button, InputLabel, Select, MenuItem, FormControl, Box, Typography, Snackbar, Alert } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { ErrorAlert, SuccessAlert } from "./Alerts";

const DynamicForm = ({
  requestId = null,
  setShowEmpanelmentRequest,
  action = true,
}: {
  requestId?: any;
  setShowEmpanelmentRequest?: any;
  action?: boolean;
}) => {
  const { mode } = useThemeContext();
  const [formValues, setFormValues] = useState<any>({});
  const [originalFormValues, setOriginalFormValues] = useState<any>({});
  const [isDisable, setIsDisable] = useState<any>(false);
  const [dropdownLoaded, setDropdownLoaded] = useState(false);
  const [open, setOpen] = useState(false);
  const [apiSuccess, setApiSuccess] = useState(false);
  const [apiMessage, setApiMessage] = useState("");
  const ITEM_HEIGHT = 40;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  useEffect(() => {
    if (requestId !== null) {
      getEmpanelmentReport();
    }
  }, [requestId]);
  async function getEmpanelmentReport() {
    try {
      const response = await GET_REQUEST(`buyer/getvobrequest/${requestId}`);
      if (response && response.data) {
        const responseData = response.data;
        console.log("responseData",responseData);
        setOriginalFormValues(responseData);
        const mappedData: any = {};
        empanelmentRequestJSON.map((field: any) => {
          if (responseData && responseData.hasOwnProperty(field.label)) {
            mappedData[field.label] = responseData[field.label];
          }
        });
        setFormValues(mappedData);
      }
    } catch (error) {
      console.log(error);
    }
  }

  function handleChange(e: { target: { value: any } }, name: any) {
    const { value } = e.target;
    console.log({ name, value });
    setFormValues({ ...formValues, [name]: value });
  }

  async function handleSubmit(e: any) {
    e.preventDefault();
    setIsDisable(true);
    console.log("formValues", formValues);
    if (requestId) {
      try {
        const originalValues = originalFormValues;
        const modifiedValues: any = {};
        Object.keys(formValues).forEach((key) => {
          if (originalValues[key] !== formValues[key]) {
            modifiedValues[key] = formValues[key];
          }
        });
        const response = await PATCH_REQUEST(`buyer/updatevobrequest/${requestId}`, modifiedValues);
        if (response?.success) {
          showAlert(response?.message, response?.success);
        } else {
          showAlert(response?.message, response?.success);
        }
        setTimeout(() => {
          setIsDisable(false);
          setShowEmpanelmentRequest(false);
        }, 3000);
      } catch (error) {
        console.log(error);
        setIsDisable(false);
      }
    } else {
      try {
        const response = await POST_REQUEST("buyer/createvobrequest", formValues);
        console.log(response);
        if (response?.success) {
          showAlert(response?.message, response?.success);
          setIsDisable(false);
        } else {
          showAlert(response?.message, response?.success);
          setIsDisable(false);
        }
      } catch (error) {
        console.log(error);
        showAlert("Server error", false);
        setIsDisable(false);
      }
    }
  }
  
  function showAlert(message: any, status: any) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    (async () => {
      try {
        await dropdownAPI();
        setDropdownLoaded(true);
      } catch (error) {
        console.error("Error:", error);
      }
    })();
  }, []);

  return (
    <form onSubmit={handleSubmit}>
      {dropdownLoaded ? (
        <Box
          className={`w-[100%] shadow-xl rounded-md py-5 px-6 ${mode==='dark'?"bg-[#312D4B]":"bg-[#FFFFFF]"}`}
        >
          <Box className="grid grid-cols-12 gap-2 mt-5">
            {empanelmentRequestJSON.map((field: any, index) => (
              <Box
                key={index}
                className={`relative ${
                  field.col === 12
                    ? "col-span-12"
                    : field.col === 6
                    ? "col-span-6"
                    : field.col === 4
                    ? "col-span-4"
                    : field.col === 3
                    ? "col-span-3"
                    : field.col === 2
                    ? "col-span-2"
                    : field.col === 1
                    ? "col-span-1"
                    : "col-span-12"
                }`}
              >
                {field.fieldType === "select" && (
                  <Box className="m-2">
                    <FormControl
                      fullWidth
                      disabled={!action}
                      variant="outlined"
                      required={field.required}
                    >
                      <InputLabel id={`${field.label}-label`} shrink>
                        {field.placeholder}
                      </InputLabel>
                      <Select
                        required={field.required}
                        labelId={`${field.label}-label`}
                        id={field.label}
                        value={formValues[field?.label] || ""}
                        label={field.placeholder}
                        onChange={(e) => handleChange(e, field?.label)}
                        MenuProps={MenuProps}
                        notched
                      >
                        {field?.options.map((option: any) => (
                          <MenuItem key={option} value={option.value}>
                            {option.value}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>
                )}
                {field.fieldType === "textarea" && (
                  <Box className="m-2">
                    <TextField
                      required={field.required}
                      id={field.label}
                      multiline
                      rows={3}
                      label={field.placeholder}
                      defaultValue={formValues[field?.label] || ""}
                      fullWidth
                      disabled={!action}
                      InputLabelProps={{ shrink: true }}
                      onChange={(e) => handleChange(e, field?.label)}
                    />
                  </Box>
                )}
                {field.fieldType !== "select" &&
                  field.fieldType !== "textarea" && (
                    <Box className="m-2">
                      <TextField
                        required={field.required}
                        id={field.label}
                        label={field.placeholder}
                        defaultValue={formValues[field?.label] || ""}
                        fullWidth
                        type={field.fieldType === "number" ? "number" : "text"}
                        disabled={!action || field.label === "RequestId"}
                        InputLabelProps={{ shrink: true }}
                        onChange={(e) => handleChange(e, field?.label)}
                      />
                    </Box>
                  )}
              </Box>
            ))}
          </Box>
          <Box className="flex justify-end  m-2">
            {!requestId ? (
              <Button
                className="w-[15%] rounded-md"
                variant="outlined"
                onClick={() => {
                  setFormValues([]);
                }}
              >
                <span className="normal-case">Cancel</span>
              </Button>
            ) : (
              <Button
                className="w-[15%] rounded-md"
                variant="outlined"
                onClick={() => setShowEmpanelmentRequest(false)}
              >
                <span className="normal-case">Back</span>
              </Button>
            )}
            {action && (
              <Button
                type="submit"
                className={`w-[15%] rounded-md ${
                  isDisable && "cursor-not-allowed opacity-[0.6]"
                }`}
                sx={{ ml: 2 }}
                variant="contained"
                disabled={isDisable}
              >
                <span className="normal-case">
                  {isDisable ? (
                    <BeatLoader color="#FFFFFF" size={10} />
                  ) : requestId ? (
                    `Update`
                  ) : (
                    `Submit`
                  )}
                </span>
              </Button>
            )}
          </Box>
        </Box>
      ) : (
        <Box className="flex justify-center h-[80vh] items-center">
          <MoonLoader />
        </Box>
      )}
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </form>
  );
};

export default DynamicForm;

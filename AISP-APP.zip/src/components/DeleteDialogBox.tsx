import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import WarningIcon from "@mui/icons-material/Warning";
import { Box, Typography } from "@mui/material";

export default function DeleteDialogBox({
  handleDelete,
  openDelete,
  handleDeleteDialogClose,
  itemId,
}: {
  handleDelete: () => void;
  openDelete: boolean;
  handleDeleteDialogClose: () => void;
  itemId: any;
}) {
  return (
    <Dialog
      open={openDelete}
      onClose={handleDeleteDialogClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      sx={{
        "& .MuiDialog-paper": {
          width: "30%",
          margin: "auto",
        },
      }}
    >
      <DialogTitle
        id="alert-dialog-title"
        sx={{
          borderBottom: "1px solid #d32f2f",
        }}
      >
        <Box display="flex" alignItems="center" color="#d32f2f">
          <WarningIcon sx={{ mr: 1 }} />
          <Typography
            variant="h6"
            component="div"
            color="#000000"
            fontWeight={600}
          >
            Delete
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent
        sx={{
          borderBottom: "1px solid #E0E0E0",
          marginY: "10px",
        }}
      >
        <DialogContentText
          id="alert-dialog-description"
          sx={{ wordBreak: "break-word" }} // Added word break styling
        >
          <Typography variant="body1" color="textPrimary" fontWeight={600}>
            Are you sure you want to delete this ({itemId}) item?
          </Typography>
          <Typography variant="body2" color="textSecondary">
            This action is permanent and cannot be undone.
          </Typography>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleDelete}
          variant="contained"
          color="primary"
          autoFocus
        >
          <span className="normal-case">Delete</span>
        </Button>
        <Button onClick={handleDeleteDialogClose} variant="outlined">
          <span className="normal-case">Cancel</span>
        </Button>
      </DialogActions>
    </Dialog>
  );
}

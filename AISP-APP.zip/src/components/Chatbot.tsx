"use client";
import { Box } from "@mui/material";
import React, { useState } from "react";
import { TbMessageChatbot } from "react-icons/tb";

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  return (
    <Box className="fixed bottom-2 right-8 z-50">
      <button
        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-full focus:outline-none"
        onClick={toggleChatbot}
      >
        <TbMessageChatbot className="text-[26px]" />
      </button>
      <Box
        className={`fixed bottom-14 right-8 z-50 ${isOpen ? "block" : "hidden"}`}
      >
        <Box className="bg-white border border-gray-300 shadow-lg rounded-lg mt-5 h-full">
          {isOpen && (
            <Box className="p-4">
              <iframe
                src="https://copilotstudio.microsoft.com/environments/Default-35db81e3-52bb-42a9-9d79-0a40236ee492/bots/crb0b_aispCopiot/webchat?__version__=2"
                width="350px "
                height="500px"
                title="Chatbot"
              ></iframe>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default Chatbot;

"use client";
import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { useThemeContext } from "@/theme/ThemeContextProvider";

interface InfoCardProps {
  title: string;
  count: number;
  description: string;
  icon: React.ReactNode;
  iconBackgroundColor?: string;
}

export default function InfoCard({
  title,
  count,
  description,
  icon,
  iconBackgroundColor,
}: InfoCardProps) {
  const { mode } = useThemeContext();
  return (
    <Card
      sx={{
        minWidth: "22%",
        padding: "2px",
        margin: { xs: "5px", md: 0 },
        display: "flex",
        justifyContent: "space-between",
        backgroundColor: mode === "dark" ? "#312D4B" : "#FFFFFF",
      }}
    >
      <CardContent>
        <Typography
          sx={{
            fontSize: 15,
            fontWeight: 500,
            color: mode === "dark" ? "#D5D1EA" : "#141414",
          }}
          gutterBottom
        >
          {title}
        </Typography>
        <Typography variant="h5" component="div">
          {count}
        </Typography>
        <Typography
          sx={{
            mb: 1.5,
            fontSize: 13,
            fontWeight: 400,
            color: mode === "dark" ? "#D5D1EA" : "#7B7A7A",
          }}
        >
          {description}
        </Typography>
      </CardContent>
      <CardContent>
        <Box
          sx={{
            fontSize: 30,
            borderRadius: 1,
            backgroundColor: iconBackgroundColor,
            padding: 1,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {icon}
        </Box>
      </CardContent>
    </Card>
  );
}

import * as React from "react";
import Alert from "@mui/material/Alert";
import AlertTitle from "@mui/material/AlertTitle";
import Stack from "@mui/material/Stack";
import Snackbar from "@mui/material/Snackbar";

export function SuccessAlert({ msg, onClose, open }: { msg: string; onClose: any; open: boolean }) {
  return (
    <Snackbar open={open} autoHideDuration={3000} onClose={onClose} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
      <Alert onClose={onClose} severity="success" variant="filled" sx={{ width: "100%" }}>
        {msg}
      </Alert>
    </Snackbar>
  );
}

export function WarningAlert({ msg, onClose, open }: { msg: string; onClose: any; open: boolean }) {
  return (
    <Snackbar open={open} autoHideDuration={3000} onClose={onClose} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
      <Alert onClose={onClose} severity="warning" variant="filled" sx={{ width: "100%" }}>
        {msg}
      </Alert>
    </Snackbar>
  );
}

export function InfoAlert({ msg, onClose, open }: { msg: string; onClose: any; open: boolean }) {
  return (
    <Snackbar open={open} autoHideDuration={3000} onClose={onClose} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
    <Alert onClose={onClose} severity="info" variant="filled" sx={{ width: "100%" }}>
      {msg}
    </Alert>
  </Snackbar>
  );
}

export function ErrorAlert({ msg, onClose, open }: { msg: string; onClose: any; open: boolean }) {
  return (
    <Snackbar open={open} autoHideDuration={3000} onClose={onClose} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
    <Alert onClose={onClose} severity="error" variant="filled" sx={{ width: "100%" }}>
      {msg}
    </Alert>
  </Snackbar>
  );
}
import React from "react";
import Chatbot from "./Chatbot";
import { Box, Typography } from "@mui/material";

const Footer = () => {
  return (
    <Box className="fixed bottom-0 w-full text-center text-black py-4">
      <Typography variant="body2" align="center" fontWeight={500}>
        Version 0.1
      </Typography>
      <Chatbot />
    </Box>
  );
};

export default Footer;

"use client";
import React, { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { styled, Theme, CSSObject } from "@mui/material/styles";
import {
  Divider,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Box,
  IconButton,
} from "@mui/material";
import MuiDrawer from "@mui/material/Drawer";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import Link from "next/link";
import { lowercaseFirstLetter } from "@/lib/helper";
import Image from "next/image";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import PeopleIcon from "@mui/icons-material/People";
import ManageAccountsOutlinedIcon from "@mui/icons-material/ManageAccountsOutlined";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import DescriptionIcon from "@mui/icons-material/Description";
import AssignmentOutlinedIcon from "@mui/icons-material/AssignmentOutlined";
import AssignmentIcon from "@mui/icons-material/Assignment";
import TaskOutlinedIcon from "@mui/icons-material/TaskOutlined";
import TaskIcon from "@mui/icons-material/Task";
import CircleOutlinedIcon from "@mui/icons-material/CircleOutlined";
import CircleIcon from "@mui/icons-material/Circle";
import { GET_REQUEST } from "@/lib/api";

const drawerWidth = 300;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: "70px",
  [theme.breakpoints.up("sm")]: {
    width: "70px",
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": {
      ...openedMixin(theme),
      backgroundColor: "#28243D", // Set a consistent background color
      color: "#ffffff", // Set the text color
    },
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": {
      ...closedMixin(theme),
      backgroundColor: "#28243D", // Set a consistent background color
      color: "#ffffff", // Set the text color
    },
  }),
}));

const SideBarNavigation = ({ open, handleDrawerClose }: any) => {
  const [navMenu, setNavMenu] = useState([]);
  const [openDropdown, setOpenDropdown] = useState(null);
  const pathname = usePathname();

  const navigationAPiCall = async () => {
    const navigation = await GET_REQUEST("/auth/access");
    setNavMenu(navigation?.data?.userAccess?.navigations);
  };

  useEffect(() => {
    navigationAPiCall();
  }, []);

  const toggleDropdown = (index: any) => {
    setOpenDropdown((prevIndex) => (prevIndex === index ? null : index));
  };

  const renderNavItem = (item: any, index: any) => {
    const isSelected = pathname === "/" + lowercaseFirstLetter(item.code);
    const hasSubMenu = Array.isArray(item.values);
    // Define the priority mapping
    const priorityMap: { [key: string]: number } = {
      EmpanelmentRequest: 1,
      EmpanelmentReport: 2,
      EmpanelmentForm: 3,
      VendorApproval: 4,
      User: 5,
      RolePerm: 6,
      RoleGroup: 7,
      RoleAssignment: 8,
    };

    // Sort submenu items based on priority
    if (hasSubMenu) {
      item.values.sort((a: any, b: any) => {
        return priorityMap[a.code] - priorityMap[b.code];
      });
    }

    const isSubItemSelected =
      hasSubMenu &&
      item.values.some(
        (subItem: any) => pathname === "/" + lowercaseFirstLetter(subItem.code)
      );

    const selectedStyle = {
      background: "linear-gradient(270deg, #8c57ff, #c5abff 100%)",
      borderRadius: "0 50px 50px 0",
    };
    const selectedMainSelectStyle = {
      backgroundColor: "#cde3fc14",
      borderRadius: "0 50px 50px 0",
    };
    const hoverStyle = {
      "&:hover": {
        backgroundColor: "#cde3fc14",
        borderRadius: "0 50px 50px 0",
      },
    };

    return (
      <ListItem key={item.code} disablePadding sx={{ display: "block" }}>
        <ListItemButton
          onClick={() => hasSubMenu && toggleDropdown(index)}
          sx={{
            minHeight: "30px",
            justifyContent: open ? "initial" : "center",
            px: 3,
            py: "5px",
            m: "5px 10px 5px 0",
            ...(isSelected && !isSubItemSelected
              ? selectedStyle
              : isSelected || isSubItemSelected
              ? selectedMainSelectStyle
              : {}),
            ...hoverStyle,
          }}
        >
          <ListItemIcon
            sx={{
              minWidth: 0,
              mr: open ? 3 : "auto",
              justifyContent: "center",
              color: "#ffffff",
            }}
          >
            {item.code === "Onboarding" &&
              (isSelected || isSubItemSelected ? (
                <PeopleIcon />
              ) : (
                <PeopleAltOutlinedIcon />
              ))}
            {item.code === "UserManage" &&
              (isSelected || isSubItemSelected ? (
                <ManageAccountsIcon />
              ) : (
                <ManageAccountsOutlinedIcon />
              ))}
          </ListItemIcon>
          <ListItemText
            primary={item.description}
            sx={{
              opacity: open ? 1 : 0,
              color: "#ffffff",
            }}
          />
          {hasSubMenu && (
            <IconButton
              edge="end"
              size="small"
              sx={{ display: open ? "initial" : "none", color: "#ffffff" }}
            >
              {openDropdown === index ? <IoIosArrowUp /> : <IoIosArrowDown />}
            </IconButton>
          )}
        </ListItemButton>
        {hasSubMenu && (
          <List
            component="div"
            disablePadding
            sx={{ display: openDropdown === index ? "block" : "none" }}
          >
            {item.values.map((subItem: any) => {
              const isSubItemSelected =
                pathname === "/" + lowercaseFirstLetter(subItem.code);
              return (
                <ListItemButton
                  key={subItem.code}
                  component={Link}
                  href={"/" + lowercaseFirstLetter(subItem.code)}
                  sx={{
                    minHeight: "30px",
                    py: "5px",
                    pl: 4,
                    m: "5px 10px 5px 0",
                    ...(isSubItemSelected ? selectedStyle : {}),
                    ...hoverStyle,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: 3,
                      color: "#ffffff",
                    }}
                  >
                    {subItem.code === "EmpanelmentRequest" &&
                      (isSubItemSelected ? (
                        <InsertDriveFileIcon />
                      ) : (
                        <InsertDriveFileOutlinedIcon />
                      ))}
                    {subItem.code === "EmpanelmentReport" &&
                      (isSubItemSelected ? (
                        <DescriptionIcon />
                      ) : (
                        <DescriptionOutlinedIcon />
                      ))}
                    {subItem.code === "EmpanelmentForm" &&
                      (isSubItemSelected ? (
                        <AssignmentIcon />
                      ) : (
                        <AssignmentOutlinedIcon />
                      ))}
                    {subItem.code === "VendorApproval" &&
                      (isSelected || isSubItemSelected ? (
                        <TaskIcon />
                      ) : (
                        <TaskOutlinedIcon />
                      ))}
                    {[
                      "User",
                      "RolePerm",
                      "RoleGroup",
                      "RoleAssignment",
                    ].includes(subItem.code) &&
                      (isSubItemSelected ? (
                        <CircleIcon fontSize="small" />
                      ) : (
                        <CircleOutlinedIcon fontSize="small" />
                      ))}
                  </ListItemIcon>
                  <ListItemText
                    primary={subItem.description}
                    sx={{
                      opacity: open ? 1 : 0,
                      color: "#ffffff",
                    }}
                  />
                </ListItemButton>
              );
            })}
          </List>
        )}
      </ListItem>
    );
  };

  return (
    <Drawer
      variant="permanent"
      open={open}
      sx={{
        "& .MuiDrawer-paper": { backgroundColor: "#28243D", border: "none" },
      }}
    >
      <DrawerHeader>
        {open ? (
          <Box
            sx={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Image
              src="/images/airdit-full-logo-transparent.png"
              width={150}
              height={40}
              alt="airdit logo"
              className="ml-5"
            />
            <IconButton onClick={handleDrawerClose} sx={{ color: "#ffffff" }}>
              <ChevronLeftIcon />
            </IconButton>
          </Box>
        ) : (
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <Image
              src="/images/airdit-short-logo-transparent.png"
              width={35}
              height={35}
              alt="airdit logo"
            />
          </Box>
        )}
      </DrawerHeader>
      <List>{navMenu?.map((item, index) => renderNavItem(item, index))}</List>
    </Drawer>
  );
};

export default SideBarNavigation;

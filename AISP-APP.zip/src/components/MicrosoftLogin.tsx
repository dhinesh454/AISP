"use client";
import React, { Fragment, useEffect } from "react";
import { setCookie, deleteCookie } from "cookies-next";
import { MicrosoftIcon } from "./icons";
import { useMsal, AuthenticatedTemplate, UnauthenticatedTemplate } from "@azure/msal-react";
import { loginRequest } from "../../authConfig";
import { useRouter } from "next/navigation";
import { GET_REQUEST } from "@/lib/api";
import { Button, Typography } from "@mui/material";

const MicrosoftLogin = () => {
  const router = useRouter();
  const { instance } = useMsal();
  let activeAccount;
  if (instance) {
    activeAccount = instance.getActiveAccount();
  }

  const handleLoginPopup = async () => {
    const res = await instance?.loginPopup({ ...loginRequest, redirectUri: "/redirect" });
    setCookie("airditToken", res?.accessToken);
    if (res?.accessToken) {
      const navigation:any = await GET_REQUEST("/auth/access");
      setCookie("airditNavigation", navigation?.data?.userAccess?.navigations);
      setCookie("airditAction", navigation?.data?.userAccess?.actions);
      router.push("/dashboard");
    }
  };
  const handleLogoutPopup = () => {
    instance.logoutPopup({
      mainWindowRedirectUri: "/", // redirects the top level app after logout
      account: instance.getActiveAccount(),
    });
    deleteCookie("airditToken");
  };

  return (
    <Fragment>
      {/* <AuthenticatedTemplate>
        <button className="bg-loginbutton bg-[#953AF9] flex  text-white font-bold  p-2 text-lg w-fit  rounded-md" onClick={handleLogoutPopup}>
          <MicrosoftIcon /> <p>Log out With Microsoft</p>
        </button>
      </AuthenticatedTemplate> */}
      <UnauthenticatedTemplate>
        <Button
          className="flex text-white font-bold mt-5 text-lg w-[400px] rounded-md "
          variant="contained"
          color="primary"
          onClick={handleLoginPopup}
        >
          <MicrosoftIcon /> <span className="pl-5 normal-case text-[16px] font-bold">Log In With Microsoft</span>
        </Button>
      </UnauthenticatedTemplate>
    </Fragment>
  );
};

export default MicrosoftLogin;

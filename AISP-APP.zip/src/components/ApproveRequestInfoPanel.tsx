"use client";
import React, { useState, useEffect } from "react";
import { Badge, Box, Typography, Card } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import QueryBuilderIcon from "@mui/icons-material/QueryBuilder";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import DoNotDisturbIcon from "@mui/icons-material/DoNotDisturb";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import SwapVertOutlinedIcon from "@mui/icons-material/SwapVertOutlined";
import FilterAltIcon from "@mui/icons-material/FilterAlt";

const ApproveRequestInfoPanel = ({ data, onSelectItem }: { data: any; onSelectItem: any }) => {
  const { mode } = useThemeContext();
  const [selectedItemIndex, setSelectedItemIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredData, setFilteredData] = useState(data);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  useEffect(() => {
    let filtered = data.filter(
      (item: any) =>
        item?.data?.BasicInformation?.SupplierName.toLowerCase().includes(
          searchQuery.toLowerCase()
        ) ||
        item?.data?.BasicInformation?.ContactPersonName.toLowerCase().includes(
          searchQuery.toLowerCase()
        )
    );
    if (sortOrder) {
      filtered = sortData(filtered, sortOrder);
    }
    setFilteredData(filtered);
  }, [searchQuery, data, sortOrder]); // Include sortOrder in dependencies
  

  useEffect(() => {
    if (sortOrder) {
      const filtered: any = sortData(filteredData, sortOrder);
      setFilteredData(filtered);
    }
  }, [sortOrder]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleSortClick = () => {
    setSortOrder((prevOrder) => (prevOrder === "asc" ? "desc" : "asc"));
  };

  const sortData = (data: any[], order: "asc" | "desc") => {
    return data.sort((a, b) => {
      const aDateParts:any = a?.data?.timestamp?.split("-");
      const bDateParts: any =
        b?.data?.timestamp?.split("-");
  
      if (!aDateParts || !bDateParts) {
        return 0; // or any other handling you prefer
      }
  
      const aDate:any = new Date(aDateParts[2], aDateParts[1] - 1, aDateParts[0]);
      const bDate: any = new Date(
        bDateParts[2],
        bDateParts[1] - 1,
        bDateParts[0]
      );
  
      if (order === "asc") {
        return aDate - bDate;
      } else {
        return bDate - aDate;
      }
    });
  };
  
  return (
    <Box
      className={`rounded-md shadow-lg h-[80vh] ${mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"}`}
    >
      <Box sx={{ display: "flex", justifyContent: "center", paddingTop: "10px" }}>
        <Typography sx={{ color: "#8C57FF" }}>
          Total Requests
        </Typography>
        <Badge badgeContent={filteredData?.length} color="primary" sx={{ top: 10, right: -15 }} />
      </Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", px: 2, my: 1 }}>
        <Box sx={{ position: "relative", width: "70%", textAlign: "13px" }}>
          <SearchOutlinedIcon sx={{ position: "absolute", top: "calc(50% - 10px)", left: "10px", color: "#8C8C8C" }} fontSize="small" />
          <input
            type="text"
            className="w-full pl-8 pr-2 py-1 border-none outline-none rounded-full bg-[#F0F0F0]"
            placeholder="Search"
            value={searchQuery}
            onChange={handleSearchChange}
          />
        </Box>
        <SwapVertOutlinedIcon
          sx={{ color: "#45464F", fontSize: "20px", ml: 2, cursor: "pointer" }}
          onClick={handleSortClick}
        />
        <FilterAltIcon sx={{ color: "#45464F", fontSize: "20px", ml: 2 }} />
      </Box>
      <Box className="overflow-y-auto h-[69vh]">
        <Box>
          {filteredData?.map((item: any, index: any) => {
            let isOverdue = false;
            if (item?.data?.timestamp) {
              const validityParts: any =
                item.data.timestamp.split("-");
              if (validityParts.length === 3) {
                const validityDate = new Date(
                  validityParts[2],
                  validityParts[1] - 1,
                  validityParts[0]
                );
                const today = new Date();
                isOverdue = validityDate < today;
              }
            }

            return (
              <Card
                className={`flex-row p-2 border-b-2 border-b-[#eee] border-l-2 my-1 ${
                  selectedItemIndex === index
                    ? "bg-gradient-to-l from-[#8C57FF] to-[#c5abff] text-[#FFFFFF]"
                    : "text-[#7B7A7A] hover:bg-gradient-to-l hover:from-[#d0afff] hover:to-[#e4d9fa]"
                } cursor-pointer ${
                  item.data.Status === "Approved"
                    ? "border-[#25AB21]"
                    : item.data.Status === "Rejected"
                    ? "border-[#FF0000]"
                    : "border-[#F79420]"
                }`}
                key={index}
                onClick={() => {
                  setSelectedItemIndex(index);
                  onSelectItem(item);
                }}
              >
                <Box className="flex justify-between">
                  <Typography
                    variant="body2"
                    fontWeight={600}
                    className={`${
                      selectedItemIndex === index
                        ? "text-[#FFFFFF]"
                        : "text-[#000000]"
                    }`}
                  >
                    {item?.data?.BasicInformation?.SupplierName}
                  </Typography>
                  <Box
                    className={`flex items-center justify-center rounded-full p-1 font-medium text-[13px] ${
                      item.data.Status === "Approved"
                        ? "bg-[#E9F7E9] text-[#25AB21]"
                        : item.data.Status === "Rejected"
                        ? "bg-[#F7E9E9] text-[#FF0000]"
                        : "bg-[#FFF4E8] text-[#F79420]"
                    }`}
                  >
                    <Box className="flex items-center">
                      {item.data.Status === "Approved" ? (
                        <>
                          <CheckCircleOutlineIcon fontSize="small" />
                          <span className="ml-1">
                            {item.data.Status}
                          </span>
                        </>
                      ) : item.data.Status === "Rejected" ? (
                        <>
                          <DoNotDisturbIcon fontSize="small" />
                          <span className="ml-1">
                            {item.data.Status}
                          </span>
                        </>
                      ) : (
                        <>
                          <QueryBuilderIcon fontSize="small" />
                          <span className="ml-1">
                            {item.data.Status}
                          </span>
                        </>
                      )}
                    </Box>
                  </Box>
                </Box>
                <Box className="mt-2">
                  <Typography variant="body2">
                    {item?.data?.BasicInformation?.ContactPersonName}
                  </Typography>
                </Box>
                <Box className="flex">
                  <Typography variant="body2">
                    {new Date(item?.data?.timestamp).toLocaleString()}
                  </Typography>
                  {isOverdue && (
                    <Typography
                      variant="body2"
                      className="ml-2 text-[#FF0000]"
                    >
                      | Overdue
                    </Typography>
                  )}
                </Box>
              </Card>
            );
          })}
        </Box>
      </Box>
    </Box>
  );
};

export default ApproveRequestInfoPanel;

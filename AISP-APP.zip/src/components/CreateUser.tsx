import React, { useEffect, useState, ChangeEvent, SyntheticEvent } from "react";
import { BeatLoader } from "react-spinners";
import { GET_REQUEST, POST_REQUEST, PUT_REQUEST } from "@/lib/api";
import { convertFormToObj } from "@/lib/helper";
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
  SelectChangeEvent,
} from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { ErrorAlert, SuccessAlert } from "./Alerts";

// Types for props
interface CreateUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  partitionKey?: string;
  action?: boolean;
}

// Types for form values
interface FormValues {
  FullName: string;
  Email: string;
  Company: string;
  Country: string | null;
  ContactNumber: string;
  UserType: string | null;
  Plan: string | null;
  Status: string | null;
}

// Types for form errors
interface FormErrors {
  FullName: string;
  Email: string;
  Company: string;
  Country: string;
  ContactNumber: string;
  UserType: string;
  Plan: string;
  Status: string;
}

// Types for dropdown options
interface DropdownOption {
  value: string;
  label: string;
}

const CreateUserModal: React.FC<CreateUserModalProps> = ({
  isOpen,
  onClose,
  partitionKey,
  action = true,
}) => {
  const { mode } = useThemeContext();
  const [isDisable, setIsDisable] = useState<boolean>(false);
  const [formValues, setFormValues] = useState<FormValues>({
    FullName: "",
    Email: "",
    Company: "",
    Country: null,
    ContactNumber: "",
    UserType: "Internal",
    Plan: null,
    Status: null,
  });
  const [errors, setErrors] = useState<FormErrors>({
    FullName: "",
    Email: "",
    Company: "",
    Country: "",
    ContactNumber: "",
    UserType: "",
    Plan: "",
    Status: "",
  });
  const requiredFields = [
    "FullName",
    "Email",
    "Company",
    "Country",
    "ContactNumber",
    "Status",
  ];
  const [originalFormValues, setOriginalFormValues] = useState<
    Partial<FormValues>
  >({});
  const [countryOptions, setCountryOptions] = useState<DropdownOption[]>([]);
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");

  const ITEM_HEIGHT = 40;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const dropdownAPi = async () => {
    try {
      const countryResponse = await GET_REQUEST(
        "/master/data/drop-downs?type=type_Country"
      );
      const options = countryResponse?.data?.map((item: any) => ({
        value: item.FIELD_DESCRIPTION,
        label: item.FIELD_DESCRIPTION,
      }));
      setCountryOptions(options);
    } catch (error) {
      console.error("Error fetching dropdown options:", error);
    }
  };


  const plans: DropdownOption[] = [
    { value: "Basic", label: "Basic" },
    { value: "Premium", label: "Premium" },
    { value: "Enterprise", label: "Enterprise" },
  ];

  const statuses: DropdownOption[] = [
    { value: "Active", label: "Active" },
    { value: "Inactive", label: "Inactive" },
  ];

  useEffect(() => {
    dropdownAPi();
  }, []);

  useEffect(() => {
    if (partitionKey) {
      getUserDetail();
    }
  }, [partitionKey, countryOptions]);

  async function getUserDetail() {
    try {
      const response = await GET_REQUEST(`auth/getusers/${partitionKey}`);
      if (response && response.data) {
        const responseData = response.data;
        setOriginalFormValues(responseData);
        setFormValues({
          FullName: responseData.FullName,
          Email: responseData.Email,
          Company: responseData.Company,
          Country: responseData.Country,
          ContactNumber: responseData.ContactNumber,
          UserType: responseData.UserType,
          Plan:
            plans.find((option) => option.value === responseData.Plan)?.value ||
            null,
          Status:
            statuses.find((option) => option.value === responseData.Status)
              ?.value || null,
        });
      }
    } catch (error) {
      console.log(error);
    }
  }

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormValues((prevFormValues) => ({
      ...prevFormValues,
      [name]: value,
    }));

    const newErrors = { ...errors };
    if (value === "" || value === null) {
      newErrors[name as keyof FormErrors] = "This field is required";
    } else {
      newErrors[name as keyof FormErrors] = "";
    }
    setErrors(newErrors);
  };

  const handleSelectChange = (
    e: SelectChangeEvent<string>,
    fieldName: string
  ) => {
    const selectedValue = e.target.value;
    setFormValues((prevFormValues) => ({
      ...prevFormValues,
      [fieldName]: selectedValue,
    }));
    const newErrors = { ...errors };
    if (selectedValue === "" || selectedValue === null) {
      newErrors[fieldName as keyof FormErrors] = "This field is required";
    } else {
      newErrors[fieldName as keyof FormErrors] = "";
    }
    setErrors(newErrors);
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    requiredFields.forEach((field) => {
      if (
        formValues[field as keyof FormValues] === "" ||
        formValues[field as keyof FormValues] === null
      ) {
        newErrors[field as keyof FormErrors] = "This field is required";
        isValid = false;
      } else {
        newErrors[field as keyof FormErrors] = "";
      }
    });

    setErrors(newErrors);
    return isValid;
  };
  const handleFormSubmit = async (e: SyntheticEvent) => {
    try {
      e.preventDefault();
      setIsDisable(true);
      const isValid = validateForm();
      if (!isValid) {
        setIsDisable(false);
        return;
      }
      const formKeyValue = convertFormToObj({ ...formValues });
      const formDataWithoutNullAndEmpty = Object.fromEntries(
        Object.entries(formKeyValue).filter(
          ([key, value]) => value !== "" && value !== null
        )
      );
      if (partitionKey) {
        const originalValues = originalFormValues;
        let modifiedValues: any = {};
        Object.keys(formDataWithoutNullAndEmpty).forEach((key) => {
          if (
            originalValues[key as keyof FormValues] !==
              formDataWithoutNullAndEmpty[key] &&
            formDataWithoutNullAndEmpty[key] !== ""
          ) {
            modifiedValues[key as keyof FormValues] =
              formDataWithoutNullAndEmpty[key];
          }
        });
        const response = await PUT_REQUEST(
          `auth/updateuser/${partitionKey}`,
          modifiedValues
        );
        if (response?.message) {
          showAlert(response?.message, response?.success);
          setIsDisable(false);
        }
      } else {
        const response = await POST_REQUEST(
          "auth/createuser",
          formDataWithoutNullAndEmpty
        );
        if (response?.success) {
          showAlert(response?.message, response?.success);
          setIsDisable(false);
        } else {
          showAlert(response?.message, response?.success);
          setIsDisable(false);
        }
      }
         setTimeout(() => {
           onClose();
         }, 1500);
    } catch (error) {
      console.log(error);
      showAlert("Server error", false);
      setIsDisable(false);
    }
  };

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: SyntheticEvent, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  return (
    <Box
      className={`fixed top-0 h-full right-0 w-1/4 bg-white overflow-hidden z-50 ${
        isOpen ? "block" : "hidden"
      }`}
    >
      <Box className="m-4">
        <Box className="border-b-[1px] border-[#BFBFBF] py-5 mb-2 ">
          <Typography
            variant="body1"
            align="left"
            fontWeight={500}
            className={`px-1 flex items-center ${
              mode === "dark" ? "text-[#D5D1EA]" : "text-[#423B7C]"
            }`}
          >
            {partitionKey ? `Update User` : `Add New User`}
          </Typography>
        </Box>
        <Box className="modal-card-body overflow-y-auto max-h-[78vh]">
          {partitionKey && (
            <Typography
              variant="body2"
              align="left"
              fontWeight={500}
              className={`py-2 flex items-center ${
                mode === "dark" ? "text-[#D5D1EA]" : "text-[#423B7C]"
              }`}
            >
              User Email: {partitionKey}
            </Typography>
          )}
          <Box className="mx-2 mt-5">
            <TextField
              required
              id="FullName"
              label="Full Name"
              value={formValues.FullName || ""}
              fullWidth
              type="text"
              disabled={!action}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={handleInputChange}
              name="FullName"
              error={Boolean(errors.FullName)}
              helperText={errors.FullName}
              FormHelperTextProps={{
                style: {
                  fontSize: "0.75rem",
                },
              }}
            />
          </Box>

          <Box className="mx-2 mt-5">
            <TextField
              required
              id="Email"
              label="Email"
              value={formValues.Email || ""}
              fullWidth
              type="email"
              disabled={!action}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={handleInputChange}
              name="Email"
              error={Boolean(errors.Email)}
              helperText={errors.Email}
              FormHelperTextProps={{
                style: {
                  fontSize: "0.75rem",
                },
              }}
            />
          </Box>

          <Box className="mx-2 mt-5">
            <TextField
              required
              id="Company"
              label="Company"
              value={formValues.Company || ""}
              fullWidth
              type="text"
              disabled={!action}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={handleInputChange}
              name="Company"
              error={Boolean(errors.Company)}
              helperText={errors.Company}
              FormHelperTextProps={{
                style: {
                  fontSize: "0.75rem",
                },
              }}
            />
          </Box>

          <Box className="mx-2 mt-5">
            <FormControl fullWidth error={Boolean(errors.Country)}>
              <InputLabel required shrink htmlFor="Country" disabled={!action}>
                Country
              </InputLabel>
              <Select
                required
                label="Country"
                value={formValues.Country || ""}
                onChange={(e) => handleSelectChange(e, "Country")}
                MenuProps={MenuProps}
                id="Country"
                name="Country"
                displayEmpty
                disabled={!action}
              >
                {countryOptions.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>{errors.Country}</FormHelperText>
            </FormControl>
          </Box>

          <Box className="mx-2 mt-5">
            <TextField
              required
              id="ContactNumber"
              label="Contact Number"
              value={formValues.ContactNumber || ""}
              fullWidth
              type="text"
              disabled={!action}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={handleInputChange}
              name="ContactNumber"
              error={Boolean(errors.ContactNumber)}
              helperText={errors.ContactNumber}
              FormHelperTextProps={{
                style: {
                  fontSize: "0.75rem",
                },
              }}
            />
          </Box>

          <Box className="mx-2 mt-5">
            <TextField
              id="UserType"
              label="User Type"
              value={formValues.UserType || ""}
              fullWidth
              type="text"
              disabled
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={handleInputChange}
              name="UserType"
              error={Boolean(errors.UserType)}
              helperText={errors.UserType}
              FormHelperTextProps={{
                style: {
                  fontSize: "0.75rem",
                },
              }}
            />
          </Box>

          <Box className="mx-2 mt-5">
            <FormControl fullWidth>
              <InputLabel shrink htmlFor="Plan" disabled={!action}>
                Plan
              </InputLabel>
              <Select
                label="Plan"
                value={formValues.Plan || ""}
                onChange={(e) => handleSelectChange(e, "Plan")}
                MenuProps={MenuProps}
                id="Plan"
                name="Plan"
                displayEmpty
                disabled={!action}
              >
                {plans.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>{errors.Plan}</FormHelperText>
            </FormControl>
          </Box>

          <Box className="mx-2 mt-5">
            <FormControl fullWidth error={Boolean(errors.Status)}>
              <InputLabel required shrink htmlFor="Status" disabled={!action}>
                Status
              </InputLabel>
              <Select
                required
                label="Status"
                value={formValues.Status || ""}
                onChange={(e) => handleSelectChange(e, "Status")}
                MenuProps={MenuProps}
                id="Status"
                name="Status"
                displayEmpty
                disabled={!action}
              >
                {statuses.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>{errors.Status}</FormHelperText>
            </FormControl>
          </Box>
        </Box>
        <Box className="flex justify-end mt-4 mb-4">
          <Button
            onClick={onClose}
            variant="outlined"
            color="primary"
            className="mr-2"
            disabled={isDisable}
          >
            <span className="normal-case">Cancel</span>
          </Button>
          <Button
            onClick={handleFormSubmit}
            variant="contained"
            color="primary"
            disabled={isDisable}
          >
            <span className="normal-case">
              {isDisable ? (
                <BeatLoader color={"#fff"} loading={isDisable} size={10} />
              ) : partitionKey ? (
                "Update User"
              ) : (
                "Add User"
              )}
            </span>
          </Button>
        </Box>
      </Box>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </Box>
  );
};

export default CreateUserModal;

import {
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarFilterButton,
  GridToolbarDensitySelector,
  GridToolbarExport,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid-premium";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";

export function CustomToolbar({ selectedRowIDs, onDelete }: any) {
  return (
    <GridToolbarContainer
      sx={{
        padding: "10px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <div>
        <GridToolbarColumnsButton
          slotProps={{ button: { color: "inherit" } }}
        />
        <GridToolbarFilterButton slotProps={{ button: { color: "inherit" } }} />
        <GridToolbarDensitySelector
          slotProps={{ button: { color: "inherit" } }}
        />
        <Button
          color="inherit"
          variant="text"
          sx={{ fontWeight: 500, fontSize: "13px" }}
          disabled
        >
          <DeleteIcon fontSize="small" style={{ marginRight: "5px" }} />
          Delete
        </Button>
        <GridToolbarExport slotProps={{ button: { color: "inherit" } }} />
      </div>
      <GridToolbarQuickFilter slotProps={{ button: { color: "inherit" } }} />
    </GridToolbarContainer>
  );
}

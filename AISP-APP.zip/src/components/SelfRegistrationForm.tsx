"use client";
import React, { useEffect, useState } from "react";
import { dropdownAPI, selfRegistrationJSON } from "@/lib/formdata";
import { POST_REQUEST } from "@/lib/api";
import { addSpaceAfterCamelCase } from "@/lib/helper";
import { BeatLoader, MoonLoader } from "react-spinners";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { ErrorAlert, SuccessAlert } from "./Alerts";
// import { successAlert, warningAlert } from "./Alerts";

const SelfRegistrationForm = (capVal: any) => {
  const [formValues, setFormValues] = useState<any>({});
  const [showButton, setShowButton] = useState<any>(true);
  const [isLoading, setIsLoading] = useState<any>(false);
  const [dropdownLoaded, setDropdownLoaded] = useState(false);
  const [open, setOpen] = useState(false);
  const [apiSuccess, setApiSuccess] = useState(false);
  const [apiMessage, setApiMessage] = useState("");
  const ITEM_HEIGHT = 40;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  function handleChange(e: { target: { value: any } }, name: any) {
    const { value } = e.target;
    console.log({ name, value });
    setFormValues({ ...formValues, [name]: value });
  }

  async function handleSubmit(e: any) {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await POST_REQUEST(
        "master/createselfrequest",
        formValues
      );
      if (response?.success) {
        showAlert(response?.message, response?.success);
        setIsLoading(false);
      }
    } catch (error) {
      console.log(error);
      setIsLoading(false);
    }
  }
  function showAlert(message: any,status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };


  useEffect(() => {
    if (capVal?.capVal !== null) {
      setShowButton(false);
    }
  }, [capVal?.capVal]);

  useEffect(() => {
    (async () => {
      try {
        await dropdownAPI();
        setDropdownLoaded(true);
      } catch (error) {
        console.error("Error:", error);
      }
    })();
  }, []);

  return (
    <form onSubmit={handleSubmit}>
      {dropdownLoaded ? (
        <>
          <Box className="grid  gap-2 bg-[#FFF] m-1 p-2">
            {selfRegistrationJSON.map((field: any, index: any) => (
              <Box
                key={index}
                className={`relative bg-[#FFF] ${
                  field.col === 12
                    ? "col-span-12"
                    : field.col === 6
                    ? "col-span-6"
                    : field.col === 4
                    ? "col-span-4"
                    : field.col === 3
                    ? "col-span-3"
                    : field.col === 2
                    ? "col-span-2"
                    : field.col === 1
                    ? "col-span-1"
                    : "col-span-12"
                }`}
              >
                {field.fieldType === "select" && (
                  <Box className="m-2">
                    <FormControl fullWidth variant="outlined">
                      <InputLabel id={`${field.label}-label`} shrink>
                        {field.placeholder}
                      </InputLabel>
                      <Select
                        labelId={`${field.label}-label`}
                        id={field.label}
                        value={formValues[field?.label] || ""}
                        label={field.placeholder}
                        onChange={(e) => handleChange(e, field?.label)}
                        MenuProps={MenuProps}
                        notched
                      >
                        {field?.options.map((option: any) => (
                          <MenuItem key={option} value={option.value}>
                            {option.value}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>
                )}
                {field.fieldType === "textarea" && (
                  <Box className="m-2">
                    <TextField
                      fullWidth
                      required={field.required}
                      id={field.label}
                      multiline
                      rows={3}
                      label={field.placeholder}
                      defaultValue={formValues[field?.label] || ""}
                      onChange={(e) => handleChange(e, field?.label)}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                )}
                {field.fieldType !== "select" &&
                  field.fieldType !== "textarea" && (
                    <Box className="m-2">
                      <TextField
                        fullWidth
                        required={field.required}
                        id={field.label}
                        label={field.placeholder}
                        defaultValue={formValues[field?.label] || ""}
                        type={field.fieldType === "number" ? "number" : "text"}
                        onChange={(e) => handleChange(e, field?.label)}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Box>
                  )}
              </Box>
            ))}
          </Box>
          <Box className="flex justify-around my-1">
            <Button
              type="button"
              variant="outlined"
              className="px-4 py-2 w-[45%] rounded-md"
              onClick={() => {
                setFormValues([]);
              }}
            >
              <span className="normal-case">Cancel</span>
            </Button>
            <Button
              type="submit"
              variant="contained"
              // className={`px-4 py-2 w-[45%] rounded-md  ${
              //   isLoading || showButton ? "cursor-not-allowed opacity-60" : ""
              // }`}
              // disabled={showButton || isLoading}
            >
              <span className="normal-case">
                {isLoading ? (
                  <BeatLoader color="#FFFFFF" size={10} />
                ) : (
                  "Submit"
                )}
              </span>
            </Button>
          </Box>
        </>
      ) : (
        <Box className="flex justify-center h-[80vh] items-center">
          <MoonLoader />
        </Box>
      )}
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </form>
  );
};

export default SelfRegistrationForm;

"use client";
import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import {
  DataGridPremium,
  useGridApiRef,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarFilterButton,
  GridToolbarDensitySelector,
  GridToolbarExport,
  useKeepGroupedColumnsHidden,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid-premium";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { Button, Typography } from "@mui/material";
import { GET_REQUEST } from "@/lib/api";
import { addSpaceAfterCamelCase, formatDate } from "@/lib/helper";
import { CustomDataFound } from "./NoDataFound";

function RolesToolbar() {
  return (
    <GridToolbarContainer
      sx={{
        padding: "10px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <div>
        <GridToolbarColumnsButton slotProps={{ button: { color: "inherit" } }} />
        <GridToolbarFilterButton slotProps={{ button: { color: "inherit" } }} />
        <GridToolbarDensitySelector slotProps={{ button: { color: "inherit" } }} />
        <GridToolbarExport slotProps={{ button: { color: "inherit" } }} />
      </div>
      <GridToolbarQuickFilter slotProps={{ button: { color: "inherit" } }} />
    </GridToolbarContainer>
  );
}

export default function 
RolesDetailsGrid({
  hideRoles,
  handleRolesDetails,
}: {
  hideRoles: () => void;
  handleRolesDetails: any;
}) {
  const { mode } = useThemeContext();
  const [selectedRows, setSelectedRows] = useState<any>([]);
  const [gridData, setGridData] = useState<any>([]);
  const [loading, setLoading] = useState<any>(true);
  const [action, setAction] = useState(false);
  const apiRef = useGridApiRef();

  function handleRoles() {
    handleRolesDetails(selectedRows);
    hideRoles();
  }

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await GET_REQUEST("auth/getroles?status=Active&pageSize=1000");
        if (res.success) {
          const dataWithIds = res.data.map((row: any, index: any) => ({
            ...row,
            id: index,
          }));
          setGridData(dataWithIds);
        }
        setLoading(false);
      } catch (error) {
        console.error("Error fetching counts:", error);
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  const initialState = useKeepGroupedColumnsHidden({
    apiRef,
    initialState: {
      columns: {
        columnVisibilityModel: {
          partitionKey: true,
          rowKey: true,
          role_name: true,
          timestamp: true,
          status: true,
        },
      },
      pagination: { paginationModel: { pageSize: 10 } },
    },
  });

  const columns = [
    { field: "partitionKey", headerName: "Role ID", flex: 1 },
    { field: "rowKey", headerName: "Roles", flex: 1 },
    { field: "role_name", headerName: "Role Name", flex: 1 },
    {
      field: "timestamp",
      headerName: "Created On",
      flex: 1,
      renderCell: (params: any) => formatDate(params.value),
    },
    {
      field: "status",
      headerName: "Account status",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="inline-block">
          <p
            className={`flex items-center justify-center rounded-full h-[30px] w-20 font-normal text-[13px] leading-[18px] ${
              params.row.status === "Active"
                ? "bg-[#E9F7E9] text-[#25AB21]"
                : "bg-[#FFF4E8] text-[#F79420]"
            }`}
          >
            {addSpaceAfterCamelCase(params.row.status)}
          </p>
        </Box>
      ),
    },
  ];

  return (
    <Box>
      <Typography
        variant="h6"
        className={`${mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"}`}
      >
        Roles Details
      </Typography>
      <Typography
        variant="body2"
        className={`${mode === "dark" ? "text-[#D5D1EA]" : "text-[#000000de]"}`}
      >
        Find all of your company's Roles.
      </Typography>
      <Box sx={{ height: 450, overflowY: "auto" }}>
        <DataGridPremium
          checkboxSelection
          rows={gridData}
          columns={columns}
          apiRef={apiRef}
          initialState={initialState}
          loading={loading}
          disableRowSelectionOnClick
          onRowSelectionModelChange={(newSelection: any) => {
            const selectedRowsFormatted = newSelection.map((id: any) => {
              const selectedRow = gridData.find((row: any) => row.id === id);
              return {
                rowKey: selectedRow?.partitionKey,
                role_name: selectedRow?.role_name,
                role_type: selectedRow?.role_type,
              };
            });
            setSelectedRows(selectedRowsFormatted);
          }}
          slots={{
            noRowsOverlay: CustomDataFound,
            toolbar: () => <RolesToolbar />,
          }}
          sx={{
            "& .MuiDataGrid-overlayWrapper": {
              minHeight: "200px",
            },
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: mode === "dark" ? "#424242" : "#FFFFF",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              fontWeight: "600",
            },
          }}
        />
      </Box>
      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
        <Button variant="contained" color="primary" onClick={handleRoles}>
          <span className="normal-case">Add</span>
        </Button>
        <Button
          variant="outlined"
          color="primary"
          onClick={hideRoles}
          sx={{ ml: 2 }}
        >
          <span className="normal-case">Cancel</span>
        </Button>
      </Box>
    </Box>
  );
}

import * as React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { addSpaceAfterCamelCase } from "@/lib/helper";

export default function HorizontalLinearAlternativeLabelStepper({
    data,
    activeStepCount,
  }: any) {
  return (
    <Box sx={{ width: "80%" }}>
      <Stepper activeStep={activeStepCount} alternativeLabel>
        {data?.map((item: any, index: any) => (
          <Step key={index}
          sx={{
            "& .MuiStepLabel-iconContainer .Mui-active": {
              color: "#25AB21"
          },
            "& .MuiStepLabel-iconContainer .Mui-completed": {
                color: "#25AB21"
            },
          
        }}>
            <StepLabel>{addSpaceAfterCamelCase(item?.dropdownName)}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
}

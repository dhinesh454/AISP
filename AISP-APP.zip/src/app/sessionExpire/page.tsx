"use client";
import React, { useState } from "react";
import { deleteCookie } from "cookies-next";
import { useMsal, AuthenticatedTemplate, UnauthenticatedTemplate } from "@azure/msal-react";
import { GrSystem } from "react-icons/gr";
import { Box } from "@mui/material";

const SessionExpire = () => {
    const { instance } = useMsal();
    const handleLogoutPopup = () => {
        instance.logoutPopup({
          mainWindowRedirectUri: "/",
          account: instance.getActiveAccount(),
        });
        deleteCookie("airditToken");
    };

    return (
        <Box className="flex flex-col h-screen justify-center items-center">
                <GrSystem className="text-blue-500 mr-2 my-5" size={100} />
                <p className="text-[20px] font-bold">Your session is expires.</p>
                <p> For security reasons, please logout.</p>
            <AuthenticatedTemplate>
                <button
                    className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline my-5"
                    onClick={handleLogoutPopup}
                >
                    Logout
                </button>
            </AuthenticatedTemplate>
        </Box>
    );
};

export default SessionExpire;

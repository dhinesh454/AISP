"use client";
import { Box } from "@mui/material";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { SyncLoader } from "react-spinners";

const AccessDeniedPage = () => {
  const pathname = usePathname();
  return pathname === "/redirect" ? (
    <Box className="flex items-center text-[18px] ml-5 text-[#9d9f9f]">
      Loading
      <SyncLoader color={"#9d9f9f"} size={10} className="ml-2" />
    </Box>
  ) : (
    <Box className="flex flex-col items-center justify-center h-screen">
      <h1 className="text-4xl font-bold mb-4">403 - Access Denied</h1>
      <p className="text-lg mb-8">
        You do not have permission to view this page.
      </p>
      <Link href="/" className="text-blue-600 hover:underline">
        Go back to home
      </Link>
    </Box>
  );
};

export default AccessDeniedPage;

import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { MsalAuthProvider } from "../context/MsalAuthContext";
import { headers } from "next/headers";
import { ThemeContextProvider } from "@/theme/ThemeContextProvider";
const inter = Inter({ subsets: ["latin"] });

export async function generateMetadata(): Promise<Metadata> {
  const headersList = headers();
  const pathName = getHeaderName(headersList.get("x-next-pathname") as string);
  return {
    title: `AISP ${pathName}`,
  };
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="initial-scale=1, width=device-width" />
      </head>
      <body className={inter.className}>
        <ThemeContextProvider>
          <MsalAuthProvider>{children}</MsalAuthProvider>
        </ThemeContextProvider>
      </body>
    </html>
  );
}

function getHeaderName(label: string): string {
  let formattedString = label?.replace(/\//g, " ");
  formattedString = formattedString?.replace(/(?<!^)([A-Z])/g, " $1");
  formattedString = formattedString?.replace(
    /^([a-z])| ([a-z])/g,
    (match) => match?.toUpperCase()
  );
  return `- ${formattedString}`;
}

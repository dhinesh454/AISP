"use client";
import React, { useState } from "react";
import Image from "next/image";
import SelfRegistrationForm from "@/components/SelfRegistrationForm";
import ReCAPTCHA from "react-google-recaptcha";
import bg from "../../../public/images/suppliergradientbg.png";
import { Typography, IconButton, Box } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import Link from "next/link";

const SelfRegistration = () => {
  const [capVal, setCapVal] = useState(null);
  // let localSitekey="6LcyO9QpAAAAANVGaJhIpIxPEjcWuRrA4P8ifDyr"
  return (
    <Box
      className="bg-cover bg-center w-full p-4"
      style={{ backgroundImage: `url(${bg.src})` }}
    >
      <Box className="flex flex-col items-center justify-center md:flex-row ">
        <Box className="w-full md:w-auto md:mb-0">
          <Link href="/" className="text-blue-600 hover:underline">
            <ArrowBackIcon style={{ color: "#fff" }} />
          </Link>
        </Box>
        <Typography variant="h4" className="text-[#fff] text-center md:flex-grow">
          Supplier Self Registrations Form
        </Typography>
      </Box>
      <Typography variant="body1" className="text-[#fff] text-center mb-2">
        Register For Business Collaboration
      </Typography>
      <Box className="w-full flex flex-col md:flex-row md:px-20 md:py-5">
        <Box className="md:w-1/2 bg-white p-5 rounded-md">
          <SelfRegistrationForm capVal={capVal} />
        </Box>
        <Box className="md:w-1/2 bg-gray-200 min-h-screen max-h-auto flex flex-col justify-center items-center rounded-md">
          <Image
            alt="self-request"
            width={500}
            height={500}
            src="/images/self-request-bg.png"
          />
          <Box className="mt-2">
            <ReCAPTCHA
              sitekey="6LchQtQpAAAAADVZk0HQkJ49salC_xa-oQZtARWU"
              onChange={(val: any) => setCapVal(val)}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default SelfRegistration;

import React from "react";
import Image from "next/image";
import { AispLogoIcon } from "@/components/icons";
import MicrosoftLogin from "@/components/MicrosoftLogin";
import { redirect } from "next/navigation";
// import { getCookie } from "cookies-next";
import { cookies } from "next/headers";
import { Box, Button } from "@mui/material";
import ContactUsModal from "@/components/ContactUsModal";
const login = () => {
  const cookieStore = cookies();
  const token = cookieStore.get("airditToken");
  if (token) {
    redirect("/dashboard");
  }

  return (
    <Box className="h-screen relative w-full overflow-hidden  ">
      <Box className="absolute inset-0 w-full h-full  [mask-image:radial-gradient(transparent,white)] pointer-events-none"/>
      <Image width={150} alt="loginImage" src="/images/logo.png" height={100} className="absolute top-3 left-4 rounded- z-40" />
      <Box className="flex lg:flex-row flex-col gap-4 overflow-y-hidden">
        <Box className="w-full lg:w-3/5 bg-gradient-to-r from-[#F4F5FA] to-[#ECEDF3] z-0 h-screen hidden lg:block rounded-none">
          <Box className="flex justify-center items-center mt-0 md:mt-5 h-full">
            <Image width={550} alt="loginImage" height={500} src="/images/man-sitting.png" />
          </Box>
        </Box>
        <Box className="w-full h-screen lg:w-2/5 px-5 flex justify-center items-center  lg:mt-0">
          <Box className="flex flex-col gap-5 z-0  ">
            <Box className="self-center">
              <AispLogoIcon />
            </Box>
            <Box className="text-center">
              <Box className=" text-[30px] md:text-[50px] font-bold">
                Supplier <span className="font-normal">portal</span>
              </Box>
              <Box className=" text-[12px] md:text-[22px] font-medium mt-2">Welcome to the Supplier Portal !</Box>
              <Box className="font-medium">Please Log-in to your account and start the adventure</Box>
            </Box>
            <Box className="self-center">
              <MicrosoftLogin />
            </Box>

            <Box className="absolute bottom-5 right-5">
             <ContactUsModal/>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default login;

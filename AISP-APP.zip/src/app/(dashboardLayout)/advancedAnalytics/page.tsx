import Link from "next/link";

const AdvancedAnalytics = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h1 className="text-4xl font-bold mb-4">Welcome to Advanced Analytics Page</h1>
      <p className="text-lg mb-8">
        This is a dummy page for Microsoft Power BI.
      </p>
      <Link href="/dashboard" className="text-blue-600 hover:underline">
        Go back to Dashboard
      </Link>
    </div>
  );
};

export default AdvancedAnalytics;

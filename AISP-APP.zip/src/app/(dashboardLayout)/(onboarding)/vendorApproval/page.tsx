"use client";
import React, { useEffect, useState } from "react";
import { GoArrowLeft } from "react-icons/go";
import ApproveRequestDetailPanel from "@/components/ApproveRequestDetailPanel";
import ApproveRequestInfoPanel from "@/components/ApproveRequestInfoPanel";
import Box from "@mui/material/Box";
import { GET_REQUEST } from "@/lib/api";
import { Button, Typography } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import TaskIcon from "@mui/icons-material/Task";
import { FaUser } from "react-icons/fa";
import { RxPaperPlane } from "react-icons/rx";
import { MoonLoader } from "react-spinners";
import { CustomDataFound } from "@/components/NoDataFound";

const VendorApproval = () => {
  const { mode } = useThemeContext();
  const [approveRequestData, setApproveRequestData] = useState<any>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [refetch,setRefetch]=useState<boolean>(false);

  useEffect(() => {
    setIsLoading(true)
  }, []);

  useEffect(() => {
    async function fetchData() {
      try {
        const resApproval = await GET_REQUEST("approval/getapprovals");
        if (resApproval.success) {
          if (resApproval?.data && resApproval?.data?.length > 0) {
            setSelectedItem(resApproval?.data[0]);
            setApproveRequestData(resApproval?.data)
          }
        }
        setIsLoading(false)
      } catch (error) {
        console.error("Error fetching counts:", error);
        setIsLoading(false)
      }
    }
    fetchData();
  }, [refetch]);

  const handleItemSelect = (item: any) => {
    console.log("item",item)
    setSelectedItem(item);
  };
  return (
    <Box>
      <Box>
        {!isLoading ? (
          <Box className="flex flex-col">
            {approveRequestData.length > 0 ? <Box className="flex">
              <Box className="w-[25%]">
                {approveRequestData && (
                  <ApproveRequestInfoPanel
                    data={approveRequestData}
                    onSelectItem={handleItemSelect}
                  />
                )}
              </Box>
              <Box component="div" sx={{ overflow: "none", width: "75%" }}>
                {selectedItem ? (
                  <ApproveRequestDetailPanel data={selectedItem} setRefetch={setRefetch} />
                ) : (
                  ""
                )}
              </Box>
            </Box>:<Box className="flex justify-center h-[80vh] items-center">
          <CustomDataFound/>
          </Box>}
          </Box>
        ) : (
          <Box className="flex justify-center h-[80vh] items-center">
            <MoonLoader />
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default VendorApproval;

// const approveRequest = {
//   approveRequestData: [
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "ABC Enterprises",
//             Country: "USA",
//             TypeOfFirm: "Private Limited",
//             GeographicServiceArea: "North America",
//             TypeOfBusiness: "Manufacturing",
//             GSTNo: "ABC123456789",
//             PANNo: "ABCDE1234F",
//             "TypeOfItemInterestedForSupply/Service": "Electronics",
//             EstablishedYear: "2005",
//             BriefBusinessDescription: "ABC Enterprises specializes in manufacturing electronic components.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "John Doe",
//             CompanyAddress: "123 Main Street",
//             EmailOfContactPerson: "john.doe@example.com",
//             StreetAddress: "123 Main Street",
//             PhoneNumber: "+1 (123) 456-7890",
//             DesignationOfContactPerson: "CEO",
//             Country: "USA",
//             Pin: "12345",
//             Email: "info@example.com",
//             State: "California",
//             City: "Los Angeles",
//             LinkedIn: "https://www.linkedin.com/in/johndoe",
//             STDCodeWithPhoneNumber: "123",
//             Twitter: "@johndoe",
//             FaxNumber: "+1 (123) 456-7890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "ABC Enterprises Pvt. Ltd.",
//             InternationalBankAccountNumber: "US123456789",
//             BankAccountNumber: "123456789",
//             IFSCCode: "ABCD1234567",
//             Currency: "USD",
//             BankAddress: "789 Bank Street, Los Angeles, CA, USA",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "Yes",
//             Validity: "01-01-2025",
//             Bonded: "No",
//             Details: "Insured by ABC Insurance Company",
//             "Licensed?": "Yes",
//             TurnOver: "$1,000,000",
//             TurnOverForm: "Annual",
//             Since: "2010",
//             Status: "In Process",
//           },
//         ],
//       },
//     },
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "XYZ Corporation",
//             Country: "Canada",
//             TypeOfFirm: "Public Limited",
//             GeographicServiceArea: "Global",
//             TypeOfBusiness: "Consulting",
//             GSTNo: "XYZ987654321",
//             PANNo: "XYZAB5678C",
//             "TypeOfItemInterestedForSupply/Service": "IT Services",
//             EstablishedYear: "2010",
//             BriefBusinessDescription: "XYZ Corporation provides consulting services in IT sector.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Jane Smith",
//             CompanyAddress: "456 Elm Street",
//             EmailOfContactPerson: "jane.smith@example.com",
//             StreetAddress: "456 Elm Street",
//             PhoneNumber: "+1 (456) 789-0123",
//             DesignationOfContactPerson: "CTO",
//             Country: "Canada",
//             Pin: "67890",
//             Email: "info@example.com",
//             State: "Ontario",
//             City: "Toronto",
//             LinkedIn: "https://www.linkedin.com/in/janesmith",
//             STDCodeWithPhoneNumber: "456",
//             Twitter: "@janesmith",
//             FaxNumber: "+1 (456) 789-0123",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "XYZ Corporation Ltd.",
//             InternationalBankAccountNumber: "CA987654321",
//             BankAccountNumber: "987654321",
//             IFSCCode: "XYZE9876543",
//             Currency: "CAD",
//             BankAddress: "321 Bank Avenue, Toronto, ON, Canada",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "No",
//             Validity: "24-08-2024",
//             Bonded: "Yes",
//             Details: "Bonded by XYZ Bonding Company",
//             "Licensed?": "Yes",
//             TurnOver: "$2,500,000",
//             TurnOverForm: "Annual",
//             Since: "2005",
//             Status: "In Process",
//           },
//         ],
//       },
//     },
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "LMN Innovations",
//             Country: "UK",
//             TypeOfFirm: "Limited Liability Company",
//             GeographicServiceArea: "Europe",
//             TypeOfBusiness: "Technology",
//             GSTNo: "LMN123456789",
//             PANNo: "LMNOP1234G",
//             "TypeOfItemInterestedForSupply/Service": "Software",
//             EstablishedYear: "2012",
//             BriefBusinessDescription: "LMN Innovations specializes in developing innovative software solutions.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Mark Johnson",
//             CompanyAddress: "789 Oak Avenue",
//             EmailOfContactPerson: "mark.johnson@example.com",
//             StreetAddress: "789 Oak Avenue",
//             PhoneNumber: "+44 1234 567890",
//             DesignationOfContactPerson: "Managing Director",
//             Country: "UK",
//             Pin: "AB12 3CD",
//             Email: "info@example.com",
//             State: "London",
//             City: "London",
//             LinkedIn: "https://www.linkedin.com/in/markjohnson",
//             STDCodeWithPhoneNumber: "44",
//             Twitter: "@markjohnson",
//             FaxNumber: "+44 1234 567890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "LMN Innovations LLC",
//             InternationalBankAccountNumber: "UK123456789",
//             BankAccountNumber: "123456789",
//             IFSCCode: "LMNO1234567",
//             Currency: "GBP",
//             BankAddress: "456 Bank Lane, London, UK",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "Yes",
//             Validity: "31-12-2023",
//             Bonded: "No",
//             Details: "Insured by LMN Insurance Services",
//             "Licensed?": "Yes",
//             TurnOver: "£750,000",
//             TurnOverForm: "Annual",
//             Since: "2012",
//             Status: "Rejected",
//           },
//         ],
//       },
//     },
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "PQR Solutions",
//             Country: "Australia",
//             TypeOfFirm: "Proprietary Limited",
//             GeographicServiceArea: "Asia-Pacific",
//             TypeOfBusiness: "Engineering",
//             GSTNo: "PQR987654321",
//             PANNo: "PQRST5678H",
//             "TypeOfItemInterestedForSupply/Service": "Construction Materials",
//             EstablishedYear: "2008",
//             BriefBusinessDescription: "PQR Solutions provides engineering solutions for construction projects.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Emily Brown",
//             CompanyAddress: "987 Maple Lane",
//             EmailOfContactPerson: "emily.brown@example.com",
//             StreetAddress: "987 Maple Lane",
//             PhoneNumber: "+61 2 3456 7890",
//             DesignationOfContactPerson: "Project Manager",
//             Country: "Australia",
//             Pin: "1234",
//             Email: "info@example.com",
//             State: "New South Wales",
//             City: "Sydney",
//             LinkedIn: "https://www.linkedin.com/in/emilybrown",
//             STDCodeWithPhoneNumber: "61",
//             Twitter: "@emilybrown",
//             FaxNumber: "+61 2 3456 7890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "PQR Solutions Pty Ltd.",
//             InternationalBankAccountNumber: "AU987654321",
//             BankAccountNumber: "987654321",
//             IFSCCode: "PQRS9876543",
//             Currency: "AUD",
//             BankAddress: "789 Bank Boulevard, Sydney, NSW, Australia",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "Yes",
//             Validity: "30-06-2025",
//             Bonded: "Yes",
//             Details: "Insured and bonded by PQR Insurance and Bonding",
//             "Licensed?": "Yes",
//             TurnOver: "$3,000,000",
//             TurnOverForm: "Annual",
//             Since: "2008",
//             Status: "Approved",
//           },
//         ],
//       },
//     },
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "EFG Enterprises",
//             Country: "Germany",
//             TypeOfFirm: "GmbH",
//             GeographicServiceArea: "Europe",
//             TypeOfBusiness: "Retail",
//             GSTNo: "EFG123456789",
//             PANNo: "EFGHI1234J",
//             "TypeOfItemInterestedForSupply/Service": "Consumer Electronics",
//             EstablishedYear: "2015",
//             BriefBusinessDescription: "EFG Enterprises operates retail stores specializing in consumer electronics.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Hans Müller",
//             CompanyAddress: "123 Rosenstrasse",
//             EmailOfContactPerson: "hans.mueller@example.com",
//             StreetAddress: "123 Rosenstrasse",
//             PhoneNumber: "+49 1234 567890",
//             DesignationOfContactPerson: "Sales Manager",
//             Country: "Germany",
//             Pin: "12345",
//             Email: "info@example.com",
//             State: "Bavaria",
//             City: "Munich",
//             LinkedIn: "https://www.linkedin.com/in/hansmueller",
//             STDCodeWithPhoneNumber: "49",
//             Twitter: "@hansmueller",
//             FaxNumber: "+49 1234 567890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "EFG Enterprises GmbH",
//             InternationalBankAccountNumber: "DE123456789",
//             BankAccountNumber: "123456789",
//             IFSCCode: "EFGH1234567",
//             Currency: "EUR",
//             BankAddress: "101 Bank Strasse, Munich, Bavaria, Germany",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "No",
//             Validity: "24-03-2024",
//             Bonded: "No",
//             Details: "",
//             "Licensed?": "Yes",
//             TurnOver: "€500,000",
//             TurnOverForm: "Annual",
//             Since: "2015",
//             Status: "Approved",
//           },
//         ],
//       },
//     },
//     {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "ITC Enterprises",
//             Country: "Germany",
//             TypeOfFirm: "GmbH",
//             GeographicServiceArea: "Europe",
//             TypeOfBusiness: "Retail",
//             GSTNo: "ITC123456789",
//             PANNo: "ITCHI1234J",
//             "TypeOfItemInterestedForSupply/Service": "Consumer Electronics",
//             EstablishedYear: "2015",
//             BriefBusinessDescription: "ITC Enterprises operates retail stores specializing in consumer electronics.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Hans Müller",
//             CompanyAddress: "123 Rosenstrasse",
//             EmailOfContactPerson: "hans.mueller@example.com",
//             StreetAddress: "123 Rosenstrasse",
//             PhoneNumber: "+49 1234 567890",
//             DesignationOfContactPerson: "Sales Manager",
//             Country: "Germany",
//             Pin: "12345",
//             Email: "info@example.com",
//             State: "Bavaria",
//             City: "Munich",
//             LinkedIn: "https://www.linkedin.com/in/hansmueller",
//             STDCodeWithPhoneNumber: "49",
//             Twitter: "@hansmueller",
//             FaxNumber: "+49 1234 567890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "ITC Enterprises GmbH",
//             InternationalBankAccountNumber: "DE123456789",
//             BankAccountNumber: "123456789",
//             IFSCCode: "ITCH1234567",
//             Currency: "EUR",
//             BankAddress: "101 Bank Strasse, Munich, Bavaria, Germany",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "No",
//             Validity: "24-03-2024",
//             Bonded: "No",
//             Details: "",
//             "Licensed?": "Yes",
//             TurnOver: "€500,000",
//             TurnOverForm: "Annual",
//             Since: "2015",
//             Status: "Rejected",
//           },
//         ],
//       },
//     },  {
//       data: {
//         BasicData: [
//           {
//             NameOfFirm: "GC Enterprises",
//             Country: "Germany",
//             TypeOfFirm: "GmbH",
//             GeographicServiceArea: "Europe",
//             TypeOfBusiness: "Retail",
//             GSTNo: "GC123456789",
//             PANNo: "GCHI1234J",
//             "TypeOfItemInterestedForSupply/Service": "Consumer Electronics",
//             EstablishedYear: "2015",
//             BriefBusinessDescription: "GC Enterprises operates retail stores specializing in consumer electronics.",
//           },
//         ],
//         VendorInformation: [
//           {
//             NameOfContactPerson: "Hans Müller",
//             CompanyAddress: "123 Rosenstrasse",
//             EmailOfContactPerson: "hans.mueller@example.com",
//             StreetAddress: "123 Rosenstrasse",
//             PhoneNumber: "+49 1234 567890",
//             DesignationOfContactPerson: "Sales Manager",
//             Country: "Germany",
//             Pin: "12345",
//             Email: "info@example.com",
//             State: "Bavaria",
//             City: "Munich",
//             LinkedIn: "https://www.linkedin.com/in/hansmueller",
//             STDCodeWithPhoneNumber: "49",
//             Twitter: "@hansmueller",
//             FaxNumber: "+49 1234 567890",
//             WebsiteAddress: "www.example.com",
//             Website: "www.example.com",
//           },
//         ],
//         BankInformation: [
//           {
//             BeneficiaryName: "GC Enterprises GmbH",
//             InternationalBankAccountNumber: "DE123456789",
//             BankAccountNumber: "123456789",
//             IFSCCode: "GCH1234567",
//             Currency: "EUR",
//             BankAddress: "101 Bank Strasse, Munich, Bavaria, Germany",
//           },
//         ],
//         AdditionalInformation: [
//           {
//             Insured: "No",
//             Validity: "24-03-2025",
//             Bonded: "No",
//             Details: "",
//             "Licensed?": "Yes",
//             TurnOver: "€500,000",
//             TurnOverForm: "Annual",
//             Since: "2015",
//             Status: "Approved",
//           },
//         ],
//       },
//     },
//   ],
// };

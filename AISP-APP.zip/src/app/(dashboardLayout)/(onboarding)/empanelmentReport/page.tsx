"use client";
import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Badge,
  Select,
  MenuItem,
  Button,
} from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import DescriptionIcon from "@mui/icons-material/Description";
import PendingActionsOutlinedIcon from "@mui/icons-material/PendingActionsOutlined";
import LoopOutlinedIcon from "@mui/icons-material/LoopOutlined";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import PersonSearchOutlinedIcon from "@mui/icons-material/PersonSearchOutlined";
import PersonRemoveOutlinedIcon from "@mui/icons-material/PersonRemoveOutlined";
import DynamicForm from "@/components/Dynamicform";
import DynamicDataGrid from "@/components/DynamicDataGrid";
import { DELETE_REQUEST, GET_REQUEST, POST_REQUEST } from "@/lib/api";
import InfoCard from "@/components/InfoCard";
import { addSpaceAfterCamelCase, formatDate } from "@/lib/helper";
import {
  useGridApiRef,
  useKeepGroupedColumnsHidden,
} from "@mui/x-data-grid-premium";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";
import DeleteDialogBox from "@/components/DeleteDialogBox";

const EmpanelmentReport = () => {
  const { mode } = useThemeContext();
  const apiRef = useGridApiRef();
  const [showEmpanelmentRequest, setShowEmpanelmentRequest] = useState(false);
  const [requestId, setRequestId] = useState("");
  const [action, setAction] = useState(false);
  const [value, setValue] = useState(0);
  const [source, setSource] = useState("supplier");
  const [pendingCount, setPendingCount] = useState(0);
  const [ongoingCount, setOngoingCount] = useState(0);
  const [totalRequests, setTotalRequests] = useState(0);
  const [inProcessRequests, setInProcessRequests] = useState(0);
  const [completedRequests, setCompletedRequests] = useState(0);
  const [rejectedRequests, setRejectedRequests] = useState(0);
  const [gridPendingData, setGridPendingData] = useState<any>([]);
  const [gridOngoingData, setGridOngoingData] = useState<any>([]);
  const [pendingLoading, setPendingLoading] = useState<any>(true);
  const [ongoingLoading, setOngoingLoading] = useState<any>(true);
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState(false);
  const [apiMessage, setApiMessage] = useState("");
  const [refetch, setRefetch] = useState<boolean>(false);
  const [openDelete, setOpenDelete] = React.useState(false);

  const handleDeleteDialogOpen = () => {
    setOpenDelete(true);
  };
  const handleDeleteDialogClose = () => {
    setOpenDelete(false);
  };

  useEffect(() => {
    async function fetchData() {
      try {
        const pendingRes = await GET_REQUEST(
          "buyer/getvobrequest?source=supplier&pageSize=1000"
        );
        const ongoingRes = await GET_REQUEST(
          "buyer/getvobrequest?source=buyer&pageSize=1000"
        );
        if (pendingRes.success) {
          const dataWithIds = pendingRes.data.map((row: any, index: any) => ({
            ...row,
            id: index,
          }));
          setGridPendingData(dataWithIds);
        }
        if (ongoingRes.success) {
          const dataWithIds = ongoingRes.data.map((row: any, index: any) => ({
            ...row,
            id: index,
          }));
          setGridOngoingData(dataWithIds);
        }
        if (pendingRes.success && ongoingRes.success) {
          const totalData = [...pendingRes.data, ...ongoingRes.data];
          const totalRequest = totalData.length;
          setPendingCount(pendingRes.data.length);
          setOngoingCount(ongoingRes.data.length);
          setTotalRequests(totalRequest);
          const inProcess = totalData.filter(
            (request) =>
              request.Status !== "Rejected" && request.Status !== "Completed"
          ).length;
          const completed = totalData.filter(
            (request) => request.Status === "Completed"
          ).length;
          const rejected = totalData.filter(
            (request) => request.Status === "Rejected"
          ).length;

          setInProcessRequests(inProcess);
          setCompletedRequests(completed);
          setRejectedRequests(rejected);
        }
        setPendingLoading(false);
        setOngoingLoading(false);
      } catch (error) {
        console.error("Error fetching counts:", error);
        setPendingLoading(false);
        setOngoingLoading(false);
      }
    }
    fetchData();
  }, [source, refetch, !showEmpanelmentRequest]);

  function handleEmpanelmentRequest(
    reqId: string,
    requestForm: boolean,
    isAction: boolean
  ) {
    setRequestId(reqId);
    setShowEmpanelmentRequest(requestForm);
    setAction(isAction);
  }

  function handleChange(event: React.SyntheticEvent, newValue: number) {
    setValue(newValue);
    setSource(newValue === 0 ? "supplier" : "buyer");
  }

  function handleView(id: any) {
    handleEmpanelmentRequest(id, true, false);
  }

  async function approveRejectRequest(id: any, action: any) {
    try {
      const res = {
        id,
        action,
      };
      console.log("approveRejectRequest", res);
      const response = await POST_REQUEST("buyer/sregaction", res);
      if (response.success) {
        showAlert(response.message, response.success);
      }else{
        showAlert(response.message, response.success);
      }
    } catch (error) {
      console.log(error);
    }
  }

  function handleEdit(id: any) {
    handleEmpanelmentRequest(id, true, true);
    setRefetch(true);
  }

  async function handleDelete() {
    try {
      const response = await DELETE_REQUEST(
        `buyer/deletevobrequest/${requestId}`
      );
      if (response.success) {
        showAlert(response.message, response.success);
        setRefetch(true); 
      }else{
        showAlert(response.message, response.success);
      }
      handleDeleteDialogClose();
    } catch (error) {
      console.log(error);
    }
  }

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }
  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  const initialState = useKeepGroupedColumnsHidden({
    apiRef,
    initialState: {
      rowGrouping: {
        model: ["commodity"],
      },
      sorting: {
        sortModel: [{ field: "__row_group_by_columns_group__", sort: "asc" }],
      },
      aggregation: {
        model: {
          quantity: "sum",
        },
      },
      columns: {
        columnVisibilityModel: {
          RequestId: true,
          SupplierName: true,
          SupplierEmail: true,
          CompanyWebsite: true,
          MobileNumber: false,
          Country: false,
          timestamp: true,
          CreatedBy: true,
          UpdatedOn: false,
          Status: true,
          Action: true,
        },
      },
      pagination: { paginationModel: { pageSize: 10 } },
    },
  });

  const columns = [
    {
      field: "RequestId",
      headerName: "Request Id",
      flex: 1,
      renderCell: (params: any) => (
        <Box
          sx={{ cursor: "pointer", color: "#8C57FF" }}
          onClick={() => handleView(params.row.RequestId)}
        >
          {params.value}
        </Box>
      ),
    },
    { field: "SupplierName", headerName: "Supplier Name", flex: 1 },
    { field: "SupplierEmail", headerName: "Email Id", flex: 1 },
    { field: "CompanyWebsite", headerName: "Company Website", flex: 1 },
    { field: "MobileNumber", headerName: "Mobile No", flex: 1 },
    { field: "Country", headerName: "Country", flex: 1 },
    {
      field: "timestamp",
      headerName: "Created On",
      flex: 1,
      renderCell: (params: any) => formatDate(params.value),
    },
    {
      field: "Status",
      headerName: "Status",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="inline-block">
          <p
            className={`flex items-center justify-center rounded-full h-[30px] px-2 font-normal text-[13px] leading-[18px] ${
              params.row.Status === "Completed"
                ? "bg-[#E9F7E9] text-[#25AB21]"
                : params.row.Status === "UnderReview" ||
                  params.row.Status === "VendorAcknowledged" ||
                  params.row.Status === "BuyerAcknowledged"
                ? "bg-[#FFF4E8] text-[#F79420]"
                : params.row.Status === "Rejected"
                ? "bg-[#F7E9E9] text-[#FF0000]"
                : params.row.Status === "Created"
                ? "bg-[#F7E9F5] text-[#FA3DDC]"
                : ""
            }`}
          >
            {addSpaceAfterCamelCase(params.row.Status)}
          </p>
        </Box>
      ),
    },
    {
      field: "Action",
      headerName: "Action",
      flex: 1,
      renderCell: (params: any) => (
        <Box>
          <Box className="py-2 flex items-center justify-center">
            {source === "supplier" ? (
              <>
                <Button
                  type="button"
                  variant="outlined"
                  color="success"
                  className="py-1 px-5 rounded-full"
                  onClick={() => {
                    approveRejectRequest(params.row.RequestId, "A");
                  }}
                >
                  <span className="text-[12px] normal-case">Approve</span>
                </Button>
                <Button
                  type="button"
                  className="py-1 px-5 ml-2 rounded-full"
                  variant="outlined"
                  color="error"
                  onClick={() => {
                    approveRejectRequest(params.row.RequestId, "R");
                  }}
                >
                  <span className="text-[12px] normal-case">Reject</span>
                </Button>
              </>
            ) : (
              <Box className="py-2 flex items-center  ">
                <EditIcon
                  className="cursor-pointer w-6 h-6"
                  onClick={() => {
                    handleEdit(params.row.RequestId);
                  }}
                />
                <DeleteOutlineIcon
                  onClick={() => {
                    if (params.row.Status === "Created") {
                      setRequestId(params.row.RequestId);
                      handleDeleteDialogOpen();
                    }
                  }}
                  sx={{
                    cursor:
                      params.row.Status === "Created" ? "pointer" : "default",
                    opacity: params.row.Status === "Created" ? 1 : 0.5,
                    pointerEvents:
                      params.row.Status === "Created" ? "auto" : "none",
                    width: "24px",
                    height: "24px",
                    marginLeft: "8px",
                  }}
                />
                <MoreVertIcon className="cursor-pointer w-6 h-6 ml-2" />
              </Box>
            )}
          </Box>
        </Box>
      ),
    },
  ];

  if (source === "buyer") {
    columns.splice(6, 0, {
      field: "CreatedBy",
      headerName: "Created By",
      flex: 1,
    });
    columns.splice(8, 0, {
      field: "UpdatedOn",
      headerName: "Updated On",
      flex: 1,
    });
  }

  return (
    <Box>
      {!showEmpanelmentRequest ? (
        <Box>
          <Typography
            variant="body1"
            align="left"
            fontWeight={500}
            className={`px-1 pb-4 flex items-center ${
              mode === "dark" ? "text-[#D5D1EA]" : "text-[#7B7A7A]"
            }`}
          >
            <DescriptionIcon sx={{ marginRight: 1 }} />
            Empanelment Report
          </Typography>
          <Box
            display="flex"
            flexDirection={{ xs: "column", md: "row" }}
            justifyContent="space-between"
            padding="0 0 20px 0"
          >
            <InfoCard
              title="Total Requests"
              count={totalRequests}
              description="Last week analytics"
              icon={
                <PeopleAltOutlinedIcon
                  fontSize="inherit"
                  sx={{ color: "#8C57FF" }}
                />
              }
              iconBackgroundColor="#F6E2FF"
            />
            <InfoCard
              title="In-Process Requests"
              count={inProcessRequests}
              description="Last week analytics"
              icon={
                <PersonSearchOutlinedIcon
                  fontSize="inherit"
                  sx={{ color: "#F79420" }}
                />
              }
              iconBackgroundColor="#FFF5E2"
            />
            <InfoCard
              title="Completed Requests"
              count={completedRequests}
              description="Last week analytics"
              icon={
                <PendingActionsOutlinedIcon
                  fontSize="inherit"
                  sx={{ color: "#65CF17" }}
                />
              }
              iconBackgroundColor="#E4F6D6"
            />
            <InfoCard
              title="Rejected Requests"
              count={rejectedRequests}
              description="Last week analytics"
              icon={
                <PersonRemoveOutlinedIcon
                  fontSize="inherit"
                  sx={{ color: "#FF4C51" }}
                />
              }
              iconBackgroundColor="#FFE2E3"
            />
          </Box>
          <Box
            className={`w-[100%] shadow-xl rounded-md py-5 px-6 ${
              mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
            }`}
          >
            <Tabs
              onChange={handleChange}
              value={value}
              aria-label="Tabs where each tab needs to be selected manually"
              sx={{
                height: { xs: "auto", md: "60px" },
              }}
            >
              <Tab
                sx={{
                  textTransform: "none",
                  paddingLeft: { xs: "5px", md: "20px" },
                  paddingRight: { xs: "5px", md: "50px" },
                }}
                icon={<PendingActionsOutlinedIcon />}
                iconPosition="start"
                label={
                  <Box
                    position="relative"
                    display="inline-flex"
                    alignItems="center"
                  >
                    <Typography>Pending for Review</Typography>
                    <Badge
                      badgeContent={pendingCount}
                      color="primary"
                      sx={{ position: "absolute", right: -15 }}
                    />
                  </Box>
                }
              />
              <Tab
                sx={{
                  textTransform: "none",
                  paddingLeft: { xs: "5px", md: "20px" },
                  paddingRight: { xs: "5px", md: "50px" },
                }}
                icon={<LoopOutlinedIcon />}
                iconPosition="start"
                label={
                  <Box
                    position="relative"
                    display="inline-flex"
                    alignItems="center"
                  >
                    <Typography>Ongoing</Typography>
                    <Badge
                      badgeContent={ongoingCount}
                      color="primary"
                      sx={{ position: "absolute", right: -15 }}
                    />
                  </Box>
                }
              />
            </Tabs>
            {value === 0 ? (
              <DynamicDataGrid
                tableName="EmpanelmentReport"
                initialState={initialState}
                columns={columns}
                apiRef={apiRef}
                gridData={gridPendingData}
                loading={pendingLoading}
              />
            ) : (
              <DynamicDataGrid
                tableName="EmpanelmentReport"
                initialState={initialState}
                columns={columns}
                apiRef={apiRef}
                gridData={gridOngoingData}
                loading={ongoingLoading}
              />
            )}
          </Box>
        </Box>
      ) : (
        <Box className="flex justify-center items-center">
          <DynamicForm
            requestId={requestId}
            setShowEmpanelmentRequest={setShowEmpanelmentRequest}
            action={action}
          />
        </Box>
      )}

      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
      {openDelete && (
        <DeleteDialogBox
          handleDelete={handleDelete}
          openDelete={openDelete}
          handleDeleteDialogClose={handleDeleteDialogClose}
          itemId={requestId}
        />
      )}
    </Box>
  );
};
export default EmpanelmentReport;

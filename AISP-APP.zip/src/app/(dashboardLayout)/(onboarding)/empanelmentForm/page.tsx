"use client";
import React, { useEffect, useState } from "react";
import { dropdownAPI, supplierEmpanelmentForm } from "@/lib/formdata";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import { PdfIcon } from "@/components/icons";
import { MdDeleteOutline } from "react-icons/md";
import { RiDownloadLine } from "react-icons/ri";
import { GET_REQUEST, PATCH_REQUEST, PUT_REQUEST } from "@/lib/api";
import { convertFormToObj } from "@/lib/helper";
import FileUploader from "@/components/FileUploder";
import { BeatLoader, MoonLoader } from "react-spinners";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  FormLabel,
  InputLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import HorizontalLinearAlternativeLabelStepper from "@/components/HorizontalLinearAlternativeLabelStepper";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";
// import { infoAlert, successAlert, warningAlert } from "@/components/Alerts";

const EmpanelmentForm = () => {
  const { mode } = useThemeContext();
  const [openIndex, setOpenIndex] = useState(0);
  const [formValues, setFormValues] = useState<any>({});
  const [originalFormValues, setOriginalFormValues] = useState<any>({});
  const [showFileUploader, setShowFileUploader] = useState(false);
  const [attachmentFile, setAttachmentFile] = useState("");
  const [isDraftDisable, setIsDraftDisable] = useState<any>(false);
  const [isSavedDisable, setIsSavedDisable] = useState<any>(false);
  const [dropdownLoaded, setDropdownLoaded] = useState(false);
  const [open, setOpen] = useState(false);
  const [apiSuccess, setApiSuccess] = useState(false);
  const [apiInfo, setApiInfo] = useState(false);
  const [apiMessage, setApiMessage] = useState("");

  const ITEM_HEIGHT = 40;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  async function getEmpanelmentMyRequest() {
    try {
      const response = await GET_REQUEST(`empanelment/myrequest`);
      if (response && response.data) {
        const responseData = response.data;
        setOriginalFormValues(responseData);
        for (const key in responseData) {
          supplierEmpanelmentForm.forEach((item) => {
            if (key.startsWith(`${item.dropdownValue}_`)) {
              item.fields.forEach((field: any) => {
                const formFieldKey = `${item.dropdownValue}_${field.label}`;
                if (field.fieldType === "select") {
                  setFormValues((prevValues: any) => ({
                    ...prevValues,
                    [formFieldKey]: {
                      value: responseData[formFieldKey],
                      label: responseData[formFieldKey],
                    },
                  }));
                }
                if (field.subfieldType === "select") {
                  setFormValues((prevValues: any) => ({
                    ...prevValues,
                    [formFieldKey]: {
                      value: responseData[formFieldKey],
                      label: responseData[formFieldKey],
                    },
                  }));
                } else {
                  setFormValues((prevFormValues: any) => ({
                    ...prevFormValues,
                    [formFieldKey]: responseData[formFieldKey],
                  }));
                }
              });
            }
          });
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    (async () => {
      try {
        await dropdownAPI();
        setDropdownLoaded(true);
      } catch (error) {
        console.error("Error:", error);
      }
    })();
  }, []);
  useEffect(() => {
    getEmpanelmentMyRequest();
  }, []);

  function toggleItem(index: number) {
    setOpenIndex((prevIndex) => (prevIndex === index ? -1 : index));
  }

  function handleChange(e: { target: { value: any } }, name: any) {
    const { value } = e.target;
    console.log({ name, value });
    setFormValues({ ...formValues, [name]: value });
  }

  async function handleFormSubmit(e: any) {
    e.preventDefault();
    try {
      setIsSavedDisable(true);
      await handleSaveAsDraft(false);
      const response = await PATCH_REQUEST(`empanelment/submit`);
      if (response.success) {
        showAlert(response.message, response.success);
        setIsDraftDisable(false);
        setIsSavedDisable(false);
        getEmpanelmentMyRequest();
      }
    } catch (error) {
      console.log(error);
      setIsSavedDisable(false);
    }
  }

  async function handleSaveAsDraft(isDraft: boolean) {
    try {
      setIsDraftDisable(isDraft);
      let data: any = convertFormToObj({ ...formValues });
      const originalValues = originalFormValues;
      const modifiedValues: any = {};
      Object.keys(data).forEach((key) => {
        if (originalValues[key] !== data[key] && data[key] !== "") {
          modifiedValues[key] = data[key];
        }
      });
      console.log("modifiedValues", modifiedValues);
      const response = await PUT_REQUEST(`empanelment/update`, modifiedValues);
      if (response.success && isDraft) {
        showAlert(response.message, response.success);
        setIsDraftDisable(false);
      }
   
    } catch (error) {
      setIsDraftDisable(false);
      console.log(error);
    }
  }

  function handleSetFileUploader(downloadLink: any) {
    setFormValues((prevFormValues: any) => ({
      ...prevFormValues,
      [attachmentFile]: downloadLink,
    }));
  }

  function handleRemoveFileUploader(attachmentFileName: any) {
    const updatedFormValues = { ...formValues };
    delete updatedFormValues[attachmentFileName];
    setFormValues(updatedFormValues);
  }

  function closeFileUploader(value: boolean) {
    setShowFileUploader(value);
  }

  const handleClose = (
    event?: React.SyntheticEvent | Event,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  return (
    <form className="m-auto pt-5 " onSubmit={handleFormSubmit}>
      <Typography
        variant="body1"
        align="center"
        fontWeight={600}
        className={`${mode === "dark" ? "text-[#D5D1EA]" : "text-[#1B1B1F]"}`}
      >
        Supplier Empanelment Form
      </Typography>
      {dropdownLoaded ? (
        <>
          <Box
            sx={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              marginTop: "20px",
              alignItems: "center",
            }}
          >
            <HorizontalLinearAlternativeLabelStepper
              data={supplierEmpanelmentForm}
              activeStepCount={openIndex}
            />
          </Box>
          {supplierEmpanelmentForm.map((item, index) => (
            <Box
              key={index}
              className={`my-4 rounded-md px-4 py-3 shadow-lg mt-5 ${
                mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
              }`}
            >
              <Box className="flex" onClick={() => toggleItem(index)}>
                <Box className="w-[95%]">
                  <Typography
                    variant="body1"
                    fontWeight={600}
                    className={` font-bold cursor-pointer pl-4 pb-2 ${
                      mode === "dark" ? "text-[#D5D1EA]" : "text-[#1B1B1F]"
                    }`}
                  >
                    {item?.dropdownName}
                  </Typography>
                </Box>
                <Box className="w-[5%]">
                  {openIndex === index ? <IoIosArrowUp /> : <IoIosArrowDown />}
                </Box>
              </Box>
              <Box className="grid grid-cols-12 gap-2 ">
                {openIndex === index &&
                  item?.fields?.map((field: any, fieldIndex: any) => (
                    <Box
                      key={fieldIndex}
                      className={`p-4 relative  ${
                        field.col === 12
                          ? "col-span-12"
                          : field.col === 6
                          ? "col-span-6"
                          : field.col === 4
                          ? "col-span-4"
                          : field.col === 3
                          ? "col-span-3"
                          : field.col === 2
                          ? "col-span-2"
                          : field.col === 1
                          ? "col-span-1"
                          : "col-span-12"
                      }`}
                    >
                      {field?.fieldType === "select" ? (
                        <Box>
                          <FormControl
                            fullWidth
                            variant="outlined"
                            required={field.required}
                          >
                            <InputLabel id={`${field.label}-label`} shrink>
                              {field.placeholder}
                            </InputLabel>
                            <Select
                              required={field.required}
                              labelId={`${field.label}-label`}
                              id={field.label}
                              value={
                                formValues[
                                  `${item?.dropdownValue}_${field.label}`
                                ] || ""
                              }
                              label={field.placeholder}
                              onChange={(e) =>
                                handleChange(
                                  e,
                                  `${item?.dropdownValue}_${field.label}`
                                )
                              }
                              MenuProps={MenuProps}
                              notched
                            >
                              {field?.options.map((option: any) => (
                                <MenuItem key={option} value={option.value}>
                                  {option.value}
                                </MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                        </Box>
                      ) : field?.fieldType === "radio" ? (
                        <Box>
                          <FormControl>
                            <FormLabel
                              id={`${field.label}-radio-buttons-group-label`}
                            >
                              {field.placeholder}
                            </FormLabel>
                            <RadioGroup
                              row
                              aria-labelledby={`${field.label}-radio-buttons-group-label`}
                              name={field.label}
                              value={
                                formValues[
                                  `${item?.dropdownValue}_${field.label}`
                                ] || ""
                              }
                              onChange={(e) =>
                                handleChange(
                                  e,
                                  `${item?.dropdownValue}_${field.label}`
                                )
                              }
                            >
                              <FormControlLabel
                                value="yes"
                                control={<Radio />}
                                label="Yes"
                              />
                              <FormControlLabel
                                value="no"
                                control={<Radio />}
                                label="No"
                              />
                            </RadioGroup>
                          </FormControl>
                        </Box>
                      ) : field?.fieldType === "textarea" ? (
                        <Box>
                          <TextField
                            required={field.required}
                            id={field.label}
                            multiline
                            rows={3}
                            label={field.placeholder}
                            defaultValue={
                              formValues[
                                `${item?.dropdownValue}_${field.label}`
                              ] || ""
                            }
                            fullWidth
                            InputLabelProps={{ shrink: true }}
                            onChange={(e) =>
                              handleChange(
                                e,
                                `${item?.dropdownValue}_${field.label}`
                              )
                            }
                          />
                        </Box>
                      ) : field?.fieldType === "file" ? (
                        <Box className="border-b-[1px] border-[#8C8C8C]-500 ">
                          <Box className="flex justify-between my-5">
                            <label className="text-[14px] font-semibold">
                              {field.placeholder}
                              <span className="text-[#FF0000]">* </span>
                            </label>
                            <Box className="flex text-[22px] font-semibold">
                              {/* <MdOutlineAddComment className="mr-10 cursor-pointer" /> */}
                              <AddCircleIcon
                                className="mr-10 cursor-pointer"
                                onClick={() => {
                                  setShowFileUploader(!showFileUploader),
                                    setAttachmentFile(
                                      `${item?.dropdownValue}_${field.label}`
                                    );
                                }}
                              />
                            </Box>
                          </Box>
                          <Box
                            className={`flex items-center ${
                              !formValues[
                                `${item?.dropdownValue}_${field.label}`
                              ] && "justify-center"
                            }`}
                          >
                            {formValues[
                              `${item?.dropdownValue}_${field.label}`
                            ] && (
                              <Box className="flex rounded-[4px]  bg-[#F0F0F0] p-3 w-[30%]  items-center my-5 mr-[200px]">
                                <PdfIcon className="mr-2 text-[40px]w-[20%] " />
                                <Box className="mr-2 w-[60%] text-center">
                                  <h2 className="text-[13px] font-semibold truncate px-2">
                                    {formValues[
                                      `${item?.dropdownValue}_${field.label}`
                                    ]
                                      ?.split("/")
                                      .pop() || ""}
                                  </h2>
                                  {/* <h2 className="text-[10px] text-center">1.1MB, 10/08.2023</h2> */}
                                </Box>
                                <RiDownloadLine className="mr-2 text-[20px]" />
                                {/* <FaEye className="mr-2 text-[20px] [10%]"  /> */}
                                <MdDeleteOutline
                                  className="mr-2 text-[20px] [10%] cursor-pointer"
                                  onClick={() =>
                                    handleRemoveFileUploader(
                                      `${item?.dropdownValue}_${field.label}`
                                    )
                                  }
                                />
                              </Box>
                            )}
                            <Box className="m-5">
                              {showFileUploader &&
                              `${item?.dropdownValue}_${field.label}` ===
                                attachmentFile ? (
                                <FileUploader
                                  handleClose={closeFileUploader}
                                  onSetFile={handleSetFileUploader}
                                />
                              ) : null}
                            </Box>
                          </Box>
                        </Box>
                      ) : field?.fieldType === "Questionnaire" ? (
                        <Box className="bg-white ">
                          {field.label === "1" && (
                            <Box className="flex py-2 my-2 bg-[#F6F7FB] text-center">
                              <Box className="w-[20%] font-semibold">Sr No</Box>
                              <Box className="w-[50%]  font-semibold">
                                Questions
                              </Box>
                              <Box className="w-[30%]  font-semibold">
                                Input
                              </Box>
                            </Box>
                          )}
                          <Box className="flex ">
                            <Box className="w-[20%] text-center">
                              {field.label}
                            </Box>
                            <Box className="w-[50%] text-center">
                              {field?.question}
                            </Box>
                            <Box className="w-[30%]">
                              <Box className="w-full">
                                {field?.subfieldType === "select" ? (
                                  <FormControl fullWidth variant="filled">
                                    <Select
                                      labelId={`${field.label}-label`}
                                      id={field.label}
                                      value={
                                        formValues[
                                          `${item?.dropdownValue}_${field.label}`
                                        ] || ""
                                      }
                                      onChange={(e) =>
                                        handleChange(
                                          e,
                                          `${item?.dropdownValue}_${field.label}`
                                        )
                                      }
                                      MenuProps={MenuProps}
                                      notched
                                    >
                                      {field?.options.map((option: any) => (
                                        <MenuItem
                                          key={option}
                                          value={option.value}
                                        >
                                          {option.value}
                                        </MenuItem>
                                      ))}
                                    </Select>
                                  </FormControl>
                                ) : (
                                  <Box>
                                    <TextField
                                      required={field.required}
                                      id={field.label}
                                      label={field.placeholder}
                                      defaultValue={
                                        formValues[
                                          `${item?.dropdownValue}_${field.label}`
                                        ] || ""
                                      }
                                      fullWidth
                                      type={
                                        field.fieldType === "number"
                                          ? "number"
                                          : "text"
                                      }
                                      InputLabelProps={{ shrink: true }}
                                      onChange={(e) =>
                                        handleChange(
                                          e,
                                          `${item?.dropdownValue}_${field.label}`
                                        )
                                      }
                                    />
                                  </Box>
                                )}
                              </Box>
                            </Box>
                          </Box>
                        </Box>
                      ) : (
                        <Box>
                          <TextField
                            required={field.required}
                            id={field.label}
                            label={field.placeholder}
                            defaultValue={
                              formValues[
                                `${item?.dropdownValue}_${field.label}`
                              ] || ""
                            }
                            fullWidth
                            type={
                              field.fieldType === "number" ? "number" : "text"
                            }
                            InputLabelProps={{ shrink: true }}
                            onChange={(e: any) =>
                              handleChange(
                                e,
                                `${item?.dropdownValue}_${field.label}`
                              )
                            }
                          />
                        </Box>
                      )}
                    </Box>
                  ))}
              </Box>
              {openIndex === index &&
                index !== supplierEmpanelmentForm.length - 1 && (
                  <Box className="flex w-[100%] justify-end p-3">
                    <Box>
                      <Button
                        type="button"
                        variant="contained"
                        className="rounded-md px-10 py-2"
                        onClick={() => toggleItem(index + 1)}
                      >
                        <span className="normal-case">Next</span>
                      </Button>
                    </Box>
                  </Box>
                )}
            </Box>
          ))}
          <Box className="flex justify-end py-5">
            <Button
              type="button"
              variant="outlined"
              className={`w-[15%] rounded-md  ${
                isDraftDisable && "cursor-not-allowed opacity-[0.6] "
              }`}
              disabled={isDraftDisable}
              onClick={() => handleSaveAsDraft(true)}
            >
              <span className="normal-case">
                {isDraftDisable ? (
                  <BeatLoader color="#8C57FF" size={10} />
                ) : (
                  `Save as Draft`
                )}
              </span>
            </Button>
            <Button
              type="button"
              variant="outlined"
              className="w-[15%] rounded-md  ml-5 "
              // disabled={isDraftDisable}
              // onClick={() => handleSaveAsDraft(true)}
            >
              <span className="normal-case">Preview</span>
            </Button>
            <Button
              type="submit"
              variant="contained"
              className={` w-[15%] rounded-md ml-5  ${
                isSavedDisable && "cursor-not-allowed opacity-[0.6]"
              }`}
              disabled={isSavedDisable}
              onClick={handleFormSubmit}
            >
              <span className="normal-case">
                {isSavedDisable ? (
                  <BeatLoader color="#FFFFFF" size={10} />
                ) : (
                  `Submit`
                )}
              </span>
            </Button>
          </Box>
        </>
      ) : (
        <Box className="flex justify-center h-[80vh] items-center">
          <MoonLoader />
        </Box>
      )}
       {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
    </form>
  );
};

export default EmpanelmentForm;

"use client"
import React from "react";
import DynamicForm from "@/components/Dynamicform";
import { Box, Typography } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
const EmpanelmentRequest = () => {
  const { mode } = useThemeContext();
  return (
    <Box>
      <Typography
        variant="body1"
        align="left"
        fontWeight={500}
        className={`px-1 pb-4 flex items-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#7B7A7A]"
        }`}
      >
         <InsertDriveFileIcon sx={{marginRight:1}}/>
        Empanelment Request 
      </Typography>
      <DynamicForm />
    </Box>
  );
};

export default EmpanelmentRequest;

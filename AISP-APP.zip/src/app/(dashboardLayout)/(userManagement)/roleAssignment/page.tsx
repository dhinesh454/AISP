"use client";
import React, { useState, useEffect } from "react";
import { Box, Typography, Button } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import DescriptionIcon from "@mui/icons-material/Description";
import DynamicDataGrid from "@/components/DynamicDataGrid";
import { GET_REQUEST, PATCH_REQUEST } from "@/lib/api";
import { addSpaceAfterCamelCase, formatDate } from "@/lib/helper";
import {
  useGridApiRef,
  useKeepGroupedColumnsHidden,
} from "@mui/x-data-grid-premium";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Slide from "@mui/material/Slide";
import { TransitionProps } from "@mui/material/transitions";
import CreateGroupRoleGrid from "@/components/GroupRole";
import RolesDetails from "@/components/RolesDetails";
import GroupsOutlinedIcon from "@mui/icons-material/GroupsOutlined";
import AssignmentIndOutlinedIcon from "@mui/icons-material/AssignmentIndOutlined";
import PersonRemoveOutlinedIcon from "@mui/icons-material/PersonRemoveOutlined";
import InfoCard from "@/components/InfoCard";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";
import RoleAssignmentGrid from "@/components/RoleAssignment";
import DeleteDialogBox from "@/components/DeleteDialogBox";

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement<any, any>;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const RoleAssignment = () => {
  const { mode } = useThemeContext();
  const apiRef = useGridApiRef();
  const [action, setAction] = useState(false);
  const [gridData, setGridData] = useState<any>([]);
  const [loading, setLoading] = useState<any>(true);
  const [openDialog, setOpenDialog] = React.useState(false);
  const [showRolesDetailGrid, setShowRolesDetailGrid] = React.useState(false);
  const [roleAssignmentData, setRoleAssignmentData] = useState<any>([]);
  const [partitionKey, setPartitionKey] = useState<any>("");
  const [rowKey, setRowKey] = useState<any>("");
  const [userName, setUserName] = useState<string>(""); // new state
  const [userId, setUserId] = useState<string>(""); // new state
  const [activeAssignments, setActiveAssignments] = useState(0);
  const [inActiveAssignments, setInActiveAssignments] = useState(0);
  const [usersCount, setUsersCount] = useState(0);
  const [rolesCount, setRolesCount] = useState(0);
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");
  const [usersList, setUserList] = useState<any[]>([]);
  const [openDelete, setOpenDelete] = React.useState(false);
  
  const handleDeleteDialogOpen = () => {
    setOpenDelete(true);
  };
  const handleDeleteDialogClose = () => {
    setOpenDelete(false);
  };

  const handleDialogOpen = () => {
    setOpenDialog(true);
  };
  const handleDialogClose = () => {
    setOpenDialog(false);
    fetchData();
  };
  const showRolesDetail = () => {
    setShowRolesDetailGrid(true);
  };
  const hideRolesDetail = () => {
    setShowRolesDetailGrid(false);
  };
  const handleRolesDetails = (data: any) => {
    setRoleAssignmentData(data);
  };
  const clearPartitionAndRowKey = () => {
    setPartitionKey("");
    setRowKey("");
  };

  useEffect(() => {
    fetchData();
    fetchUserData();
  }, []);

  async function fetchData() {
    try {
      const res = await GET_REQUEST("auth/getassignments?pageSize=1000");
      if (res.success) {
        const dataWithIds = res.data.map((row: any, index: any) => ({
          ...row,
          id: index,
          role_name: row.details.role_name,
          role_type: row.details.role_type,
        }));
        setGridData(dataWithIds);

        const activeAssignments = dataWithIds.filter(
          (request: any) => request.Status === "Active"
        ).length;

        const inActiveAssignments = dataWithIds.filter(
          (request: any) => request.Status === "Inactive"
        ).length;

        const uniqueUsers = new Set(
          dataWithIds.map((row: any) => row.partitionKey)
        );
        const usersCount = uniqueUsers.size;

        const activeRolesCount = dataWithIds.filter(
          (request: any) => request.Status === "Active"
        ).length;

        setActiveAssignments(activeAssignments);
        setInActiveAssignments(inActiveAssignments);
        setUsersCount(usersCount);
        setRolesCount(activeRolesCount);
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching counts:", error);
      setLoading(false);
    }
  }

  async function fetchUserData() {
    try {
      const res = await GET_REQUEST(
        "auth/getusers?status=Active&pageSize=1000&userType=buyer"
      );
      if (res.success) {
        const userData = res.data.map((item: any) => ({
          value: item.partitionKey,
          label: item.FullName + ` (${item.partitionKey})`,
        }));
        setUserList(userData);
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching counts:", error);
      setLoading(false);
    }
  }

  async function handleDelete() {
    try {
      const payload = { Status: "Inactive" };
      const response = await PATCH_REQUEST(
        `auth/updateassignments/${partitionKey}/${rowKey}`,
        payload
      );
      if (response.success) {
        showAlert(response.message, response.success);
        fetchData();
        handleDeleteDialogClose();
      }
    } catch (error) {
      console.log(error);
    }
  }

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  const initialState = useKeepGroupedColumnsHidden({
    apiRef,
    initialState: {
      rowGrouping: {
        model: ["commodity"],
      },
      sorting: {
        sortModel: [{ field: "__row_group_by_columns_group__", sort: "asc" }],
      },
      aggregation: {
        model: {
          quantity: "sum",
        },
      },
      columns: {
        columnVisibilityModel: {
          partitionKey: true,
          role_name: true,
          role_type: true,
          // valid_from: true,
          // valid_to: true,
          Status: true,
          timestamp: true,
        },
      },
      pagination: { paginationModel: { pageSize: 10 } },
    },
  });

  const columns = [
    {
      field: "partitionKey",
      headerName: "User Id",
      flex: 1,
      renderCell: (params: any) => (
        <Box
          sx={{ cursor: "pointer", color: "#8C57FF" }}
          onClick={() => {
            setPartitionKey(params.row.partitionKey),
              setRowKey(params.row.rowKey);
            handleDialogOpen(), setAction(false);
          }}
        >
          {params.value}
        </Box>
      ),
    },
    { field: "role_name", headerName: "Role Type", flex: 1 },
    { field: "role_type", headerName: "Role Name", flex: 1 },
    // {
    //   field: "timestamp",
    //   headerName: "Valid From",
    //   flex: 1,
    //   renderCell: (params: any) => formatDate(params.value),
    // },
    // {
    //   field: "timestamp",
    //   headerName: "Valid To",
    //   flex: 1,
    //   renderCell: (params: any) => formatDate(params.value),
    // },
    {
      field: "timestamp",
      headerName: "Created On",
      flex: 1,
      renderCell: (params: any) => formatDate(params.value),
    },
    {
      field: "Status",
      headerName: "Account status",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="inline-block">
          <p
            className={`flex items-center justify-center rounded-full h-[30px] w-20 font-normal text-[13px] leading-[18px] ${
              params.row.Status === "Active"
                ? "bg-[#E9F7E9] text-[#25AB21]"
                : "bg-[#FFF4E8] text-[#F79420]"
            }`}
          >
            {addSpaceAfterCamelCase(params.row.Status)}
          </p>
        </Box>
      ),
    },
    {
      field: "Action",
      headerName: "Action",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="py-2 flex items-center  ">
          <EditIcon
            className="cursor-pointer w-6 h-6"
            onClick={() => {
              setPartitionKey(params.row.partitionKey),
                setRowKey(params.row.rowKey);
              handleDialogOpen(), setAction(true);
            }}
          />
          <DeleteOutlineIcon
            onClick={() => {
              setPartitionKey(params.row.partitionKey),
              setRowKey(params.row.rowKey);
              handleDeleteDialogOpen();
            }}
            sx={{
              cursor:
                params.row.Status === "Active" ? "pointer" : "default",
              opacity: params.row.Status === "Active" ? 1 : 0.5,
              pointerEvents:
                params.row.Status === "Active" ? "auto" : "none",
              width: "24px",
              height: "24px",
              marginLeft: "8px",
            }}
          />
          <MoreVertIcon className="cursor-pointer w-6 h-6 ml-2" />
        </Box>
      ),
    },
  ];

  return (
    <Box>
      <Typography
        variant="body1"
        align="left"
        fontWeight={500}
        className={`px-1 pb-4 flex items-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#7B7A7A]"
        }`}
      >
        <DescriptionIcon sx={{ marginRight: 1 }} />
        Role Assignment
      </Typography>
      <Box
        display="flex"
        flexDirection={{ xs: "column", md: "row" }}
        justifyContent="space-between"
        padding="0 0 20px 0"
      >
        <InfoCard
          title="Users"
          count={usersCount}
          description="Last week analytics"
          icon={
            <GroupsOutlinedIcon fontSize="inherit" sx={{ color: "#8C57FF" }} />
          }
          iconBackgroundColor="#F6E2FF"
        />
        <InfoCard
          title="Roles"
          count={rolesCount}
          description="Last week analytics"
          icon={
            <PersonRemoveOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#F79420" }}
            />
          }
          iconBackgroundColor="#FFF5E2"
        />
        <InfoCard
          title="Active Assignments"
          count={activeAssignments}
          description="Last week analytics"
          icon={
            <AssignmentIndOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#65CF17" }}
            />
          }
          iconBackgroundColor="#E4F6D6"
        />
        <InfoCard
          title="In-Active Assignments"
          count={inActiveAssignments}
          description="Last week analytics"
          icon={
            <AssignmentIndOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#FFE2E3" }}
            />
          }
          iconBackgroundColor="#FF4C51"
        />
      </Box>
      <Box
        className={`w-[100%] shadow-xl rounded-md py-5 px-6 ${
          mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
        }`}
      >
        <Box className="flex justify-end w-[100]">
          <Button
            type="button"
            variant="contained"
            className=" px-4 py-2 ml-2 rounded-md"
            onClick={() => {
              setPartitionKey(""), handleDialogOpen(), setAction(true);
              setRoleAssignmentData([]);
            }}
          >
            <span className="normal-case">Assignment</span>
          </Button>
        </Box>
        <DynamicDataGrid
          tableName="RoleGroup"
          initialState={initialState}
          columns={columns}
          apiRef={apiRef}
          gridData={gridData}
          loading={loading}
        />
      </Box>
      <Dialog
        fullWidth={true}
        maxWidth="lg"
        open={openDialog}
        TransitionComponent={Transition}
        keepMounted
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogContent>
          {showRolesDetailGrid ? (
            <RolesDetails
              hideRoles={hideRolesDetail}
              handleRolesDetails={handleRolesDetails}
            />
          ) : (
            <RoleAssignmentGrid
              roleAssignmentData={roleAssignmentData}
              handleDialogClose={handleDialogClose}
              showRoles={showRolesDetail}
              partitionKey={partitionKey}
              rowKey={rowKey}
              clearPartitionAndRowKey={clearPartitionAndRowKey}
              action={action}
              userName={userName}
              setUserName={setUserName}
              userId={userId}
              setUserId={setUserId}
              usersList={usersList}
            />
          )}
        </DialogContent>
      </Dialog>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
      {openDelete && (
        <DeleteDialogBox
          handleDelete={handleDelete}
          openDelete={openDelete}
          handleDeleteDialogClose={handleDeleteDialogClose}
          itemId={partitionKey}
        />
      )}
    </Box>
  );
};
export default RoleAssignment;

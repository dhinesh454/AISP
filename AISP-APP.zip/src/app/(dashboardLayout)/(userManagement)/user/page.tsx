"use client";
import React, { useState, useEffect } from "react";
import { Box, Typography, Button } from "@mui/material";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import DescriptionIcon from "@mui/icons-material/Description";
import DynamicDataGrid from "@/components/DynamicDataGrid";
import { GET_REQUEST, PUT_REQUEST } from "@/lib/api";
import { addSpaceAfterCamelCase, formatDate } from "@/lib/helper";
import {
  useGridApiRef,
  useKeepGroupedColumnsHidden,
} from "@mui/x-data-grid-premium";
import { useRouter } from "next/navigation";
import CreateUserModal from "@/components/CreateUser";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import PersonSearchOutlinedIcon from "@mui/icons-material/PersonSearchOutlined";
import PersonRemoveOutlinedIcon from "@mui/icons-material/PersonRemoveOutlined";
import InfoCard from "@/components/InfoCard";
import { ErrorAlert, SuccessAlert } from "@/components/Alerts";
import DeleteDialogBox from "@/components/DeleteDialogBox";

const User = () => {
  const { mode } = useThemeContext();
  const apiRef = useGridApiRef();
  const router = useRouter();
  const [action, setAction] = useState(false);
  const [selectedActions, setSelectedActions] = useState<any>({});
  const [gridData, setGridData] = useState<any>([]);
  const [loading, setLoading] = useState<any>(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [partitionKey, setPartitionKey] = useState<any>();
  const [activeUsers, setActiveUsers] = useState(0);
  const [inActiveUsers, setInActiveUsers] = useState(0);
  const [activeSuppliers, setActiveSuppliers] = useState(0);
  const [activeInternalUsers, setActiveInternalUsers] = useState(0);
  const [open, setOpen] = useState<boolean>(false);
  const [apiSuccess, setApiSuccess] = useState<boolean>(false);
  const [apiMessage, setApiMessage] = useState<string>("");
  const [openDelete, setOpenDelete] = React.useState(false);
  
  const handleDeleteDialogOpen = () => {
    setOpenDelete(true);
  };
  const handleDeleteDialogClose = () => {
    setOpenDelete(false);
  };

  const openModal = () => {
    setIsModalOpen(true);
  };
  const closeModal = () => {
    setIsModalOpen(false);
    fetchData();
  };
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const res = await GET_REQUEST("auth/getusers?pageSize=1000");
      if (res.success) {
        const dataWithIds:any = res.data.map((row: any, index: any) => ({
          ...row,
          id: index,
        }));
        setGridData(dataWithIds);

        const activeUsers = dataWithIds.filter(
          (request:any) =>
            request.Status == "Active" 
        ).length;
        const inActiveUsers = dataWithIds.filter(
          (request:any) =>
            request.Status == "Inactive" 
        ).length;
        const activeSuppliers = dataWithIds.filter(
          (request: any) =>
            request.Status == "Active" && request.UserType == "supplier"
        ).length;
        const activeInternalUsers = dataWithIds.filter(
          (request: any) =>
            request.Status == "Active" && request.UserType == "internal"
        ).length;
      
        setActiveUsers(activeUsers);
        setInActiveUsers(inActiveUsers);
        setActiveSuppliers(activeSuppliers);
        setActiveInternalUsers(activeInternalUsers);
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching counts:", error);
      setLoading(false);
    }
  }

  async function handleDelete() {
    try {
      const updateData = { Status: "Inactive" };
      const response = await PUT_REQUEST(
        `auth/updateuser/${partitionKey}`,
        updateData
      );
      if(response.success){
        showAlert(response.message,response.success);
      }else{
        showAlert(response.message,response.success);
      }
      fetchData();
      handleDeleteDialogClose();
    } catch (error) {
      console.log(error);
    }
  }

  function showAlert(message: string, status: boolean) {
    status ? setApiSuccess(true) : setApiSuccess(false);
    setOpen(true);
    setApiMessage(message);
  }

  const handleClose = (event?: any, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };


  const initialState = useKeepGroupedColumnsHidden({
    apiRef,
    initialState: {
      rowGrouping: {
        model: ["commodity"],
      },
      sorting: {
        sortModel: [{ field: "__row_group_by_columns_group__", sort: "asc" }],
      },
      aggregation: {
        model: {
          quantity: "sum",
        },
      },
      columns: {
        columnVisibilityModel: {
          partitionKey: true,
          FullName: true,
          Email: true,
          ContactNumber: true,
          UserType: true,
          Status: true,
          Action: true,
        },
      },
      pagination: { paginationModel: { pageSize: 10 } },
    },
  });

  const columns = [
    {
      field: "partitionKey",
      headerName: "User Email",
      flex: 1,
      renderCell: (params: any) => (
        <Box
          sx={{ cursor: "pointer", color: "#8C57FF" }}
          onClick={() => {
            setPartitionKey(params.row.partitionKey),
              openModal(),
              setAction(false);
          }}
        >
          {params.value}
        </Box>
      ),
    },
    { field: "FullName", headerName: "User", flex: 1 },
    { field: "Email", headerName: "Email", flex: 1 },
    { field: "ContactNumber", headerName: "Mobile No", flex: 1 },
    { field: "UserType", headerName: "User Category", flex: 1 },
    {
      field: "Status",
      headerName: "Account status",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="inline-block">
          <p
            className={`flex items-center justify-center rounded-full h-[30px] w-20 font-normal text-[13px] leading-[18px] ${
              params.row.Status === "Active"
                ? "bg-[#E9F7E9] text-[#25AB21]"
                : "bg-[#FFF4E8] text-[#F79420]"
            }`}
          >
            {addSpaceAfterCamelCase(params.row.Status)}
          </p>
        </Box>
      ),
    },
    {
      field: "Action",
      headerName: "Action",
      flex: 1,
      renderCell: (params: any) => (
        <Box className="py-2 flex items-center  ">
          <EditIcon
            className="cursor-pointer w-6 h-6 text-[#595959]"
            onClick={() => {
              setPartitionKey(params.row.partitionKey),
                openModal(),
                setAction(true);
            }}
          />
          <DeleteOutlineIcon
            onClick={() => {
              setPartitionKey(params.row.partitionKey),
              handleDeleteDialogOpen();
            }}
            sx={{
              cursor:
                params.row.Status === "Active" ? "pointer" : "default",
              opacity: params.row.Status === "Active" ? 1 : 0.5,
              pointerEvents:
                params.row.Status === "Active" ? "auto" : "none",
              width: "24px",
              height: "24px",
              marginLeft: "8px",
            }}
          />
          <MoreVertIcon className="cursor-pointer w-6 h-6 ml-2 text-[#595959]" />
        </Box>
      ),
    },
  ];

  return (
    <Box>
      <Typography
        variant="body1"
        align="left"
        fontWeight={500}
        className={`px-1 pb-4 flex items-center ${
          mode === "dark" ? "text-[#D5D1EA]" : "text-[#7B7A7A]"
        }`}
      >
        <DescriptionIcon sx={{ marginRight: 1 }} />
        User
      </Typography>
      <Box
        display="flex"
        flexDirection={{ xs: "column", md: "row" }}
        justifyContent="space-between"
        padding="0 0 20px 0"
      >
        <InfoCard
          title="Active Users"
          count={activeUsers}
          description="Last week analytics"
          icon={
            <PersonOutlineIcon fontSize="inherit" sx={{ color: "#65CF17" }} />
          }
          iconBackgroundColor="#E4F6D6"
        />
        <InfoCard
          title="In-Active Users"
          count={inActiveUsers}
          description="Last week analytics"
          icon={
            <PersonRemoveOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#FF4C51" }}
            />
          }
          iconBackgroundColor="#FFE2E3"
        />
        <InfoCard
          title="Active Suppliers"
          count={activeSuppliers}
          description="Last week analytics"
          icon={
            <PeopleAltOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#8C57FF" }}
            />
          }
          iconBackgroundColor="#F6E2FF"
        />
        <InfoCard
          title="Active Internal Users"
          count={activeInternalUsers}
          description="Last week analytics"
          icon={
            <PersonSearchOutlinedIcon
              fontSize="inherit"
              sx={{ color: "#F79420" }}
            />
          }
          iconBackgroundColor="#FFF5E2"
        />
      </Box>
      <Box
        className={`w-[100%] shadow-xl rounded-md py-5 px-6 ${
          mode === "dark" ? "bg-[#312D4B]" : "bg-[#FFFFFF]"
        }`}
      >
        <Box className="flex justify-end w-[100]">
          <Button
            type="button"
            variant="contained"
            className=" px-4 py-2 ml-2 rounded-md"
            onClick={() => {
              setPartitionKey(null), openModal(), setAction(true);
            }}
          >
            <span className="normal-case">Add New User</span>
          </Button>
        </Box>
        <DynamicDataGrid
          tableName="User"
          initialState={initialState}
          columns={columns}
          apiRef={apiRef}
          gridData={gridData}
          loading={loading}
        />
        {isModalOpen && (
          <Box className="fixed inset-0 z-50 flex justify-center items-center bg-[#141414]/[.30] bg-opacity-30">
            <Box className="w-[19%] py-2">
              <CreateUserModal
                isOpen={isModalOpen}
                onClose={closeModal}
                partitionKey={partitionKey}
                action={action}
              />
            </Box>
          </Box>
        )}
      </Box>
      {apiSuccess ? (
        <SuccessAlert msg={apiMessage} onClose={handleClose} open={open} />
      ) : (
        <ErrorAlert msg={apiMessage} onClose={handleClose} open={open} />
      )}
      {openDelete && (
        <DeleteDialogBox
          handleDelete={handleDelete}
          openDelete={openDelete}
          handleDeleteDialogClose={handleDeleteDialogClose}
          itemId={partitionKey}
        />
      )}
    </Box>
  );
};
export default User;

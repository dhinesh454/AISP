"use client";
import React, { useEffect, useState } from "react";
import { BeatLoader } from "react-spinners";
import { GET_REQUEST, POST_REQUEST, PUT_REQUEST } from "@/lib/api";
import { convertFormToObj } from "@/lib/helper";
import {
  Box,
  Button,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";

const UserProfilePage = () => {
  const [isDisable, setIsDisable] = useState<any>(false);
  const [formValues, setFormValues] = useState({
    FirstName: "",
    LastName: "",
    EmailIDOfContactPerson: "",
    StreetAddress: "",
    MobileNumber: "",
    Country: null,
    Language: "",
    TimeZone: null,
  });
  const [originalFormValues, setOriginalFormValues] = useState<any>({});
  const ITEM_HEIGHT = 40;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const countryOptions: any[] = [];

  useEffect(() => {
    dropdownAPi();
  }, []);

  const dropdownAPi = async () => {
    try {
      const res = await GET_REQUEST(
        "/master/data/drop-downs?type=type_Country"
      );
      countryOptions.push(
        ...res?.data?.map((item: { rowKey: any; FIELD_DESCRIPTION: any }) => ({
          value: item.FIELD_DESCRIPTION,
          label: item.FIELD_DESCRIPTION,
        }))
      );
    } catch (error) {
      console.error("Error fetching dropdown options:", error);
    }
  };

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    setFormValues((prevFormValues) => ({
      ...prevFormValues,
      [name]: value,
    }));
  };

  const handleSelectChange = (selectedOption: any, fieldName: any) => {
    setFormValues((prevFormValues) => ({
      ...prevFormValues,
      [fieldName]: selectedOption,
    }));
  };

  const handleFormSubmit = async (e: any) => {
    try {
      e.preventDefault();
      setIsDisable(true);
      const formKeyValue = convertFormToObj({ ...formValues });
    } catch (error) {
      console.log(error);
      setIsDisable(false);
    }
  };

  return (
    <Box className="flex justify-center items-center mt-5">
      <Box className="w-[90%] shadow-2xl rounded-md py-5 px-6" color="primary">
        <Box className="py-5 mb-2">
          <Typography variant="h5" align="center" fontWeight={700}>
            User Profile
          </Typography>
        </Box>
        <Box className="modal-card-body  ml-2">
          <Grid container spacing={2} className="mt-2">
            <Grid item xs={6}>
              <TextField
                id="FirstName"
                label="First Name"
                defaultValue={formValues.FirstName || ""}
                fullWidth
                type="text"
                InputLabelProps={{ shrink: true }}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="LastName"
                label="Last Name"
                defaultValue={formValues.LastName || ""}
                fullWidth
                type="text"
                InputLabelProps={{ shrink: true }}
                onChange={handleInputChange}
              />
            </Grid>
          </Grid>
          <Grid container spacing={2} className="mt-4">
            <Grid item xs={6}>
              <TextField
                id="EmailIDOfContactPerson"
                label="Email ID Of Contact Person"
                defaultValue={formValues.EmailIDOfContactPerson || ""}
                fullWidth
                type="text"
                InputLabelProps={{ shrink: true }}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="StreetAddress"
                label="Street Address"
                defaultValue={formValues.StreetAddress || ""}
                fullWidth
                type="text"
                InputLabelProps={{ shrink: true }}
                onChange={handleInputChange}
              />
            </Grid>
          </Grid>
          <Grid container spacing={2} className="mt-4">
            <Grid item xs={6}>
              <TextField
                id="MobileNumber"
                label="Mobile Number"
                defaultValue={formValues.MobileNumber || ""}
                fullWidth
                type="number"
                InputLabelProps={{ shrink: true }}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth  variant="outlined">
                <InputLabel id={`Country-label`} shrink>
                  Country
                </InputLabel>
                <Select
                  labelId={`Country-label`}
                  id="Country"
                  value={formValues.Country || ""}
                  label="Country"
                  onChange={(selectedOption) =>
                    handleSelectChange(selectedOption, "Country")
                  }
                  MenuProps={MenuProps}
                  notched
                >
                  {countryOptions.map((option: any) => (
                    <MenuItem key={option} value={option.value}>
                      {option.value}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          <Grid container spacing={2} className="mt-4">
            <Grid item xs={6}>
              <FormControl fullWidth variant="outlined">
                <InputLabel id={`Language-label`} shrink>
                  Language
                </InputLabel>
                <Select
                  labelId={`Language-label`}
                  id="Language"
                  value={formValues.Language || ""}
                  label="Language"
                  onChange={(selectedOption) =>
                    handleSelectChange(selectedOption, "Language")
                  }
                  MenuProps={MenuProps}
                  notched
                >
                  {/* Language options */}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth  variant="outlined">
                <InputLabel id={`TimeZone-label`} shrink>
                  TimeZone
                </InputLabel>
                <Select
                  labelId={`TimeZone-label`}
                  id="TimeZone"
                  value={formValues.TimeZone || ""}
                  label="TimeZone"
                  onChange={(selectedOption) =>
                    handleSelectChange(selectedOption, "TimeZone")
                  }
                  MenuProps={MenuProps}
                  notched
                >
                  {/* TimeZone options */}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </Box>

        <Box className="flex justify-start ml-2 my-5">
            <Button
              type="submit"
              className={`w-[15%] rounded-md ${
                isDisable && "cursor-not-allowed opacity-[0.6]"
              }`}
              variant="contained"
              disabled={isDisable}
              onClick={handleFormSubmit}
            >
              {isDisable && <BeatLoader color="#FFFFFF" size={10} />}
              <span className="normal-case">Save changes</span>
            </Button>
          <Button className="w-[15%] ml-4 rounded-md" variant="outlined">
            <span className="normal-case">Reset</span>
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default UserProfilePage;

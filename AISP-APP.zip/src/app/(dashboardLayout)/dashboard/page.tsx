import Link from "next/link";

const DashboardPage = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h1 className="text-4xl font-bold mb-4">Welcome to Dashboard Page</h1>
      <p className="text-lg mb-8">
      Data loading soon. Thank you for your patience.
      </p>
      {/* <Link href="/about" className="text-blue-600 hover:underline">
        Go to About Page
      </Link> */}
    </div>
  );
};

export default DashboardPage;

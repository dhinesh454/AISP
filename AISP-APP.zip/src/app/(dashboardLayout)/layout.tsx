"use client";
import React, { useState } from "react";
import "react-toastify/dist/ReactToastify.css";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { getCookie, setCookie } from 'cookies-next'
import SessionExpire from "@/components/SessionExpire";
import { Box } from "@mui/material";
import SideBarNavigation from "@/components/SideBarNavigation";

const drawerWidth = 300;
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const token = getCookie("airditToken");
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleDrawerOpen = () => {
    setDrawerOpen(true);
  };

  const handleDrawerClose = () => {
    setDrawerOpen(false);
  };

  return (
    <html lang="en">
      <body>
        {/* {token ? ( */}
        <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Header
              drawerOpen={drawerOpen}
              handleDrawerOpen={handleDrawerOpen}
            />
            <Box sx={{ display: "flex", flexGrow: 1 }}>
              <SideBarNavigation
                open={drawerOpen}
                handleDrawerClose={handleDrawerClose}
              />
              <Box
                sx={{
                  padding: 2,
                  paddingTop:10,
                  width: `calc(100% - ${drawerOpen ? drawerWidth : 70}px)`,
                  // transition: "width 0.3s",
                }}
              >
                {children}
              </Box>
            </Box>
            {/* <Footer /> */}
          </Box>
        {/* ) : (
          <SessionExpire />
        )} */}
      </body>
    </html>
  );
}

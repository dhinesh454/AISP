"use client";
import { createContext } from "react";
import { MsalProvider } from "@azure/msal-react";
import { PublicClientApplication, EventType } from "@azure/msal-browser";
import { msalConfig } from "../../authConfig";
import { usePathname } from "next/navigation";
import { useThemeContext } from "@/theme/ThemeContextProvider";
import { CssBaseline, ThemeProvider } from "@mui/material";
const msalInstance = new PublicClientApplication(msalConfig);

if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
  msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
}

msalInstance.enableAccountStorageEvents();

msalInstance.addEventCallback((event: any) => {
  if (event.eventType === EventType.LOGIN_SUCCESS && event?.payload?.account) {
    const account = event?.payload?.account;
    msalInstance.setActiveAccount(account);
  }
});

export const MsalAuthContext = createContext({});

export const MsalAuthProvider = ({ children }: any) => {
  const { theme } = useThemeContext();
  const pathname = usePathname();
  if( pathname === "/login"){
    if (typeof window !== 'undefined') {
      localStorage.removeItem("msal.account.keys");
    }
  }
  return (
    <MsalAuthContext.Provider
      value={{
        val: "msal-auth-provider",
      }}
    >
        <ThemeProvider theme={theme}>
      <CssBaseline />
      <MsalProvider instance={msalInstance}>{children}</MsalProvider>
      </ThemeProvider>
    </MsalAuthContext.Provider>
  );
};

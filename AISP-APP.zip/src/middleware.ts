import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { lowercaseFirstLetter } from "./lib/helper";

export default function middleware(request: NextRequest) {
  const protectedRoutes: string[] = [
    "/empanelmentForm",
    "/empanelmentReport",
    "/empanelmentRequest",
    "/vendorApproval",
    "/roleAssignment",
    "/roleGroup",
    "/rolePerm",
    "/user",
    "/advancedAnalytics",
  ];
  const unprotectedRoutes: string[] = [
    "/settings",
    "/faq",
    "/userProfile",
    "/dashboard",
  ];

  const noTokenRoutes: string[] = [
    "/",
    "/login",
    "/redirect",
    "/selfRegistration",
  ];

  const path = request.nextUrl.pathname;
  const navigation = request.cookies.get("airditNavigation")?.value || "";
  const token = request.cookies.get("airditToken")?.value || "";
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-next-pathname", path);

  if (navigation) {
    const navigationData = JSON.parse(navigation);
    const userAccessRoutes: string[] = navigationData.reduce(
      (
        routes: string[],
        navigation: { code: string; values: { code: string }[] }
      ) => {
        if (Array.isArray(navigation.values)) {
          routes.push(
            ...navigation.values.map(
              (item) => "/" + lowercaseFirstLetter(item.code)
            )
          );
        } else {
          routes.push("/" + lowercaseFirstLetter(navigation.code));
        }
        return routes;
      },
      []
    );
    if (
      !token &&
      (unprotectedRoutes.includes(path) || userAccessRoutes.includes(path))
    ) {
      const sessionExpireURL = new URL(
        "/sessionExpire",
        request.nextUrl.origin
      );
      return NextResponse.rewrite(sessionExpireURL, {
        request: {
          headers: requestHeaders,
        },
      });
    } else if (
      unprotectedRoutes.includes(path) ||
      userAccessRoutes.includes(path) ||
      noTokenRoutes.includes(path)
    ) {
      return NextResponse.next({
        request: {
          headers: requestHeaders,
        },
      });
    } else if (
      protectedRoutes.includes(path) &&
      !userAccessRoutes.includes(path)
    ) {
      const accessDeniedURL = new URL("/accessDenied", request.nextUrl.origin);
      return NextResponse.rewrite(accessDeniedURL, {
        request: {
          headers: requestHeaders,
        },
      });
    }
  } else if (!navigation && token) {
    const sessionExpireURL = new URL("/sessionExpire", request.nextUrl.origin);
    return NextResponse.rewrite(sessionExpireURL, {
      request: {
        headers: requestHeaders,
      },
    });
  } else if (noTokenRoutes.includes(path) && !token && !navigation) {
    return NextResponse.next({
      request: {
        headers: requestHeaders,
      },
    });
  } else {
    const absoluteURL = new URL("/not-found", request.nextUrl.origin);
    return NextResponse.rewrite(absoluteURL, {
      request: {
        headers: requestHeaders,
      },
    });
  }
}

export const config = {
  matcher: "/((?!.*\\.).*)",
};

"use client";
import { LogLevel } from "@azure/msal-browser";
// import { PublicClientApplication, EventType } from "@azure/msal-browser";
export const msalConfig = {
  auth: {
    clientId: "b8eb4496-c5d6-496d-a0af-934ddd7a62f3", // This is the ONLY mandatory field that you need to supply.
    authority: "https://login.microsoftonline.com/3cfec137-8fe6-415d-866b-5a235391cacd", // Defaults to "https://login.microsoftonline.com/common"
    redirectUri: "/", // You must register this URI on Azure Portal/App Registration. Defaults to window.location.origin
    postLogoutRedirectUri: "/", // Indicates the page to navigate after logout.
    clientCapabilities: ["CP1"], // this lets the resource owner know that this client is capable of handling claims challenge.
  },
  cache: {
    cacheLocation: "localStorage", // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level: any, message: any, containsPii: any) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

export const protectedResources = {
  apiTodoList: {
    endpoint: "http://localhost:3001/api/todolist",
    scopes: {
      read: ["api://b473130b-b703-4ae4-b84b-ab71bc16ab37/Todolist.Read"],
      write: ["api://b473130b-b703-4ae4-b84b-ab71bc16ab37/Todolist.ReadWrite"],
    },
  },
};

export const loginRequest = {
  scopes: [...protectedResources.apiTodoList.scopes.read, ...protectedResources.apiTodoList.scopes.write, "user.read"],
};

// export const msalInstance = new PublicClientApplication(msalConfig);
// if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
//   msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
// }

// msalInstance.enableAccountStorageEvents();
// msalInstance.addEventCallback((event) => {
//   if (event.eventType === EventType.LOGIN_SUCCESS && event?.payload?.account) {
//     const account = event?.payload?.account;
//     msalInstance.setActiveAccount(account);
//   }
// });
